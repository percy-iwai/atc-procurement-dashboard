# セットアップ手順書（新環境用・ステップバイステップ）

各ステップは**1コマンド・冪等（何度実行しても安全）**です。
コマンドはすべて**キットを展開したディレクトリの直下**で実行してください。

> Windows で日本語が文字化けする場合は、先に `set PYTHONUTF8=1`（PowerShellは
> `$env:PYTHONUTF8="1"`）を実行してください。機械判定用の `SUMMARY` 行は常にASCIIです。

---

## Step 0. キットの入手と展開

zip を展開するだけ。DBは同梱済みなのでダウンロード工程はありません。

## Step 1. Python環境構築

```bash
bash kit_atc/setup_env.sh                                       # macOS / Linux
powershell -ExecutionPolicy Bypass -File kit_atc\setup_env.ps1   # Windows
```

- **期待される出力**: `SUMMARY setup=OK venv=... mode=online`
  （wheels同梱キットの場合は `mode=offline-wheels` — ネット不要で完了）
- **失敗時**: Python 3.10+ が無い → インストールして再実行。pip エラー → ネットワーク/プロキシを確認して再実行
- **ネットもwheelsも無い場合**: Step 3（ダッシュボード）は諦め、縮退モードへ →
  `python kit_atc/export_csv_xlsx.py --csv-only` は標準ライブラリのみで動く（Step 2'参照）
- 以後のコマンドは venv を activate してから実行
  （`source .venv/bin/activate` / `.venv\Scripts\Activate.ps1`）

## Step 2. 同梱DBの検証（数秒）

```bash
python kit_atc/verify_kit.py
```

- 同梱DB（atc_procurement.db ×2・atc_geps.db・atc_review.db）のテーブル件数・
  SHA256・FY別集計を `kit_atc/exports/expected_state.json` と突合します
- **期待される出力**: `SUMMARY result=PASS`
- **WARN**: sha256のみ不一致（件数は一致）→ 旧環境でDBが更新された後 expected を再生成し
  忘れたケース。実用上は続行可
- **FAIL**: zip展開不全・DB破損の可能性。zipを再展開してやり直す。
  詳細は `kit_atc/exports/verify_report.json`

## Step 2'. CSV / XLSX 吐き出し（任意・Streamlit不要）

```bash
python kit_atc/export_csv_xlsx.py             # 全DB・全テーブル → exports_data/
python kit_atc/export_csv_xlsx.py --csv-only  # pip install ゼロ（標準ライブラリのみ）
```

- **期待される出力**: `SUMMARY export_data=OK dbs=3 tables=... rows=...`
- CSVは utf-8-sig（BOM付き）なのでExcelでそのまま開ける
- 整形済みExcelが欲しい場合: `python create_atc_excel.py`（openpyxlのみで動作）
- Streamlit が入らない制約環境では、このステップが Step 3 の代替になる

## Step 3. ダッシュボード起動

```bash
python -m streamlit run deploy/app.py --server.port 8501
```

ブラウザで http://localhost:8501 を開き、ページが表示されれば完了。
（予算比較タブの元データは `deploy/data/output/budget_vs_db_5yr.json`。同梱済み）

---

## 増分更新（新月次・新年度データの追加）

確定分の移設とは別系統です。**マスターDB（`data/db/atc_procurement.db`）に書き込み →
`deploy/data/` へコピー → expected再生成**の3手が基本形。
ソースURL・ファイル命名規則の詳細はすべて `KNOWLEDGE.md` にあります。

### A. TCAB / WCAB 月次PDF（ライブサーバー）

```bash
# TCAB: https://www.cab.mlit.go.jp/tcab/files/r{YY}_{MM}_bid.pdf / _zui.pdf
# WCAB: https://www.cab.mlit.go.jp/wcab/file/{bk|bz|kk|kz}_{date}.pdf
python collect_atc_monthly.py        # 月次収集（対象月はスクリプト内指定を確認）
```

### B. 航空局本局XLSX（年度ファイル）

新年度の fileID を https://www.mlit.go.jp/koku/koku_tk1_000033.html で確認し、
`build_atc_db.py` 系の取込を実行（fileID一覧と取込済み状況は `KNOWLEDGE.md` の表参照）。

### C. 地方整備局PAS（ライブサーバー）

```bash
# https://www.pas.ysk.nilim.go.jp/contents/KekkaKohyo/{局名}/koji{YYYYMM}.xls
python collect_pas_airport_fy2025.py   # 新FY用は本スクリプトをコピーして年度を更新
```

### D. 予算比較JSONの更新

```bash
python generate_budget_5yr.py          # data/output/budget_vs_db_5yr.json を再生成
```

### 更新後の締め（必ず実行）

```bash
cp data/db/atc_procurement.db deploy/data/        # deployへ反映
cp data/output/budget_vs_db_5yr.json deploy/data/output/   # 予算JSONを更新した場合
python kit_atc/export_expected_state.py           # 検証基準を更新後の状態に合わせる
python kit_atc/verify_kit.py                      # PASS を確認
```

### 収集後の品質チェック（推奨）

`KNOWLEDGE.md` 末尾の「品質チェック時の確認項目」のSQLを実行
（vendor_nameへのヘッダー混入・bid_methodへの法人番号混入等の既知パターン検出）。

---

## キットzipの再生成（旧環境用）

```bash
python kit_atc/make_kit_zip.py               # → atc_dashboard_kit_<date>.zip
```

## トラブルシューティング早見表

| 症状 | 対処 |
|------|------|
| `ModuleNotFoundError` | venv を activate していない / Step 1 をやり直す |
| `database is locked` | 別プロセス（ダッシュボード等）がDBを開いている。閉じて再実行 |
| verify FAIL | zip再展開 → verify。直らなければ旧環境で `export_expected_state.py` → zip再生成 |
| ダッシュボードにデータが出ない | `deploy/data/atc_procurement.db` の有無を確認（zip展開漏れ） |
| WARP取得が極端に遅い | WARP側の混雑。礼儀的レート（2.5秒/件以上）を守って時間を置く |
| 文字化け | `PYTHONUTF8=1` を設定 |
