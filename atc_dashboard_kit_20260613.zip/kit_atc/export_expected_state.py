"""（旧環境用）検証基準 expected_state.json を生成する。

同梱DBごとに SHA256・サイズ・テーブル件数・FY別集計を記録し、
新環境の verify_kit.py がこれと突合する。

実行: python kit_atc/export_expected_state.py
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

KIT_DIR = Path(__file__).resolve().parent
ROOT = KIT_DIR.parent

# DBパス（キット展開ルートからの相対） → FY集計対象 {テーブル: 金額カラム}
DATABASES: dict[str, dict[str, str]] = {
    "deploy/data/atc_procurement.db": {
        "contracts": "contract_amount",
        "pas_airport_contracts": "award_amount",
    },
    "data/db/atc_procurement.db": {
        "contracts": "contract_amount",
        "pas_airport_contracts": "award_amount",
    },
    "data/db/atc_geps.db": {},
    "data/db/atc_review.db": {},
}


def describe_db(path: Path, fy_tables: dict[str, str]) -> dict:
    raw = path.read_bytes()
    con = sqlite3.connect(path)
    tables = [r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    info: dict = {
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "tables": {t: con.execute(f"SELECT COUNT(*) FROM [{t}]").fetchone()[0]
                   for t in tables},
        "fy_breakdown": {},
    }
    for table, amount_col in fy_tables.items():
        rows = con.execute(
            f"SELECT fiscal_year, COUNT(*), COALESCE(SUM({amount_col}),0) "
            f"FROM [{table}] GROUP BY fiscal_year ORDER BY fiscal_year").fetchall()
        info["fy_breakdown"][table] = {
            str(fy): {"count": n, "amount": int(amt)} for fy, n, amt in rows}
    con.close()
    return info


def main() -> None:
    state: dict = {"kit": KIT_DIR.name,
                   "generated_at": datetime.now().isoformat(timespec="seconds"),
                   "databases": {}}
    missing = []
    for rel, fy_tables in DATABASES.items():
        p = ROOT / rel
        if not p.exists():
            missing.append(rel)
            continue
        state["databases"][rel] = describe_db(p, fy_tables)
        print(f"  {rel}: {state['databases'][rel]['bytes']:,} bytes / "
              f"{sum(state['databases'][rel]['tables'].values()):,} rows")

    out = KIT_DIR / "exports" / "expected_state.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(state, ensure_ascii=False, indent=1),
                   encoding="utf-8")
    status = "OK" if not missing else "WARN"
    print(f"SUMMARY export={status} dbs={len(state['databases'])} "
          f"missing={len(missing)} out={out}")
    if missing:
        for m in missing:
            print(f"  MISSING: {m}")
        sys.exit(1)


if __name__ == "__main__":
    main()
