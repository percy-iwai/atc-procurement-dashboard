"""（旧環境用）オフラインinstall用 wheels を kit_atc/wheels/ にダウンロードする。

ネット接続の無い（PyPIに出られない）移植先でも Step 1 の環境構築が通るように、
依存パッケージ一式の wheel ファイルをキットに同梱するためのスクリプト。
wheels/ が存在すると setup_env が自動でオフラインinstall（--no-index）に切り替わる。

⚠️ バイナリwheelは **OS・CPUアーキ・Pythonマイナーバージョン依存**。
   移植先と同じ環境向けに落とすこと。
   - 移植先 = この環境と同じ（例: Windows→Windows, Python 3.12→3.12）: 引数なしでOK
   - 移植先が Linux サーバー等: --platform 等で指定（下の例）

実行:
  python kit_atc/download_wheels.py
  python kit_atc/download_wheels.py --platform manylinux2014_x86_64 --python-version 3.12
その後:
  python kit_atc/make_kit_zip.py --include-wheels   # wheels込みzip（+100MB前後）
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

KIT_DIR = Path(__file__).resolve().parent
WHEELS = KIT_DIR / "wheels"
REQS = KIT_DIR / "requirements.txt"


def main() -> None:
    parser = argparse.ArgumentParser(description="オフラインinstall用wheelsダウンロード")
    parser.add_argument("--platform", help="移植先プラットフォーム "
                        "(例: manylinux2014_x86_64, win_amd64, macosx_11_0_arm64)")
    parser.add_argument("--python-version", help="移植先Pythonバージョン (例: 3.12)")
    args = parser.parse_args()

    WHEELS.mkdir(exist_ok=True)
    cmd = [sys.executable, "-m", "pip", "download",
           "-r", str(REQS), "-d", str(WHEELS)]
    if args.platform or args.python_version:
        # クロスプラットフォーム指定時はバイナリwheelのみ許可（sdistはビルド不能）
        cmd += ["--only-binary=:all:"]
        if args.platform:
            cmd += ["--platform", args.platform]
        if args.python_version:
            cmd += ["--python-version", args.python_version]

    print("実行:", " ".join(cmd))
    rc = subprocess.call(cmd)
    if rc != 0:
        print("SUMMARY wheels=FAIL rc=%d" % rc)
        sys.exit(rc)

    files = list(WHEELS.glob("*"))
    total_mb = sum(f.stat().st_size for f in files) / 1e6
    print(f"SUMMARY wheels=OK files={len(files)} size={total_mb:.0f}MB out={WHEELS}")
    print("次: python kit_atc/make_kit_zip.py --include-wheels")


if __name__ == "__main__":
    main()
