# Python仮想環境ブートストラップ（Windows）
# 実行: powershell -ExecutionPolicy Bypass -File kit_atc\setup_env.ps1
# kit_atc\wheels\ が存在する場合は自動でオフラインinstall（ネット不要）に切り替わる
$ErrorActionPreference = "Stop"
$kitDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $kitDir
Set-Location $root

$py = Get-Command python -ErrorAction SilentlyContinue
if ($null -eq $py) {
    Write-Output "SUMMARY setup=FAIL reason=python_not_found"
    exit 1
}

if (-not (Test-Path (Join-Path $root ".venv"))) {
    python -m venv .venv
}
$venvPy = "$root\.venv\Scripts\python.exe"

$wheels = Join-Path $kitDir "wheels"
if (Test-Path $wheels) {
    # オフラインモード: 同梱wheelsからinstall（PyPIアクセス不要）
    & $venvPy -m pip install --no-index --find-links "$wheels" -r "$kitDir\requirements.txt" --quiet
    $mode = "offline-wheels"
} else {
    # オンラインモード: PyPIからinstall
    & $venvPy -m pip install --upgrade pip --quiet
    & $venvPy -m pip install -r "$kitDir\requirements.txt" --quiet
    $mode = "online"
}
if ($LASTEXITCODE -ne 0) {
    Write-Output "SUMMARY setup=FAIL reason=pip_install_error mode=$mode"
    Write-Output "HINT: ネットもwheelsも無い場合でも、CSV吐き出し（kit_atc\export_csv_xlsx.py --csv-only）は標準ライブラリのみで動く"
    exit 1
}
Write-Output "SUMMARY setup=OK venv=$root\.venv mode=$mode"
