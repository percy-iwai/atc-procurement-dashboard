# ドメイン知識（増分収集・改修時に必読）

旧環境の CLAUDE.md・メモリから、航空管制調達DBに関する部分を抜粋したもの。
収集ソースのURL・WARPスナップショット・パーサーの罠がすべてここにある。

---

## DB現況スナップショット（2026-06-13 キット作成時点）

| DB | テーブル | 件数 |
|----|---------|------|
| atc_procurement.db | contracts | 24,982 |
| atc_procurement.db | pas_airport_contracts | 5,134 |
| atc_geps.db | geps_contracts | 59,693 |
| atc_review.db | projects / expenditure_items / payees | 75 / 278 / 73 |

contracts は FY2011–2025 の航空局本局XLSX＋TCAB＋WCAB、
pas_airport_contracts は FY2011–2025 の地方整備局PAS。
FY2019 の PAS はアーカイブ不存在により**永久欠落**（正常）。

---

## 航空管制調達DB（atc_procurement.db）— データ収集・増補方法

> 対象: 国土交通省航空局・地方航空局・地方整備局の調達情報（FY2013〜FY2025）
> DB: `data/db/atc_procurement.db`

### 13年分拡張計画（2026-04-19着手）

**収集対象**: FY2013(H25) 〜 FY2025(R7) — 既存FY2020-2025に FY2013-2019を追加

#### 本局XLSXインデックスURL（年度別WARPスナップショット）

| 年度 | インデックスURL | 備考 |
|------|----------------|------|
| R4～R7 | https://www.mlit.go.jp/koku/koku_tk1_000033.html | ライブ |
| R2, R3, H30 | https://warp.ndl.go.jp/20241003/20241003183110id_/https://www.mlit.go.jp:8088/koku/koku_tk1_000033.html | coll=20241025 |
| R1 | https://warp.ndl.go.jp/20220108/20220108015825id_/https://www.mlit.go.jp/koku/koku_tk1_000033.html | coll=20220131 |
| H29 | https://warp.ndl.go.jp/20190208/20190208070518id_/https://www1.mlit.go.jp:8088/koku/koku_tk1_000033.html | coll=20190227 |
| H28 | https://warp.ndl.go.jp/20170903/20170903131716id_/https://www1.mlit.go.jp:8088/koku/koku_tk1_000033.html | coll=20170929 |
| H27 | https://warp.ndl.go.jp/20180705/20180705060145id_/http://www.mlit.go.jp/koku/koku_tk1_000033.html | coll=20180730 |
| H26, H25 | https://warp.ndl.go.jp/20150422/20150404001946id_/http://www.mlit.go.jp/koku/koku_tk1_000033.html | coll=20150422, :8088なし版 |

#### TCABインデックスURL

| 年度 | インデックスURL |
|------|----------------|
| H30～R7 | https://www.cab.mlit.go.jp/tcab/contract/results/procurement-summary.html |
| H24～R2 | https://warp.ndl.go.jp/20201001/20201001151609id_/https://www.cab.mlit.go.jp/tcab/contract/contract_04/post_271.html |

#### WCABインデックスURL

| 年度 | インデックスURL |
|------|----------------|
| R5～7 | https://www.cab.mlit.go.jp/wcab/contract/published.html |
| H29～R4 | https://warp.ndl.go.jp/20230601/20230601134447id_/https://www.cab.mlit.go.jp/wcab/contract/published.html |
| H27～R1 | https://warp.ndl.go.jp/20210301/20210301154504id_/https://www.cab.mlit.go.jp/wcab/contract/published.html |
| H26 | https://warp.ndl.go.jp/20150402/20150402070405id_/http://ocab.mlit.go.jp/contract/con_6/26/index.html |
| H25 | https://warp.ndl.go.jp/20150402/20150402070410id_/http://ocab.mlit.go.jp/contract/con_6/25/index.html |

#### PASインデックスURL

| 年度 | インデックスURL |
|------|----------------|
| R6～7 | https://www.pas.ysk.nilim.go.jp/contents/KekkaKohyo/KekkaKokusoken.html |
| R5 | https://warp.ndl.go.jp/20241201/20241201090404id_/https://www.pas.ysk.nilim.go.jp/contents/ChHKekkaKohyo.html |
| R3 | https://warp.ndl.go.jp/20220701/20220701182858id_/https://www.pas.ysk.nilim.go.jp/contents/ChHKekkaKohyo.html |
| R2 | https://warp.ndl.go.jp/20220401/20220401134543id_/https://www.pas.ysk.nilim.go.jp/contents/ChHKekkaKohyo.html |
| H25〜H30（FY2013〜2018） | 旧URLを直接 WARP で取得（インデックスページ不要）。XLSファイルを coll/ts を指定してダウンロード。`collect_pas_fy2013_2019.py` 参照 |

---

### テーブル構成

| テーブル | 説明 | FY2011 | FY2012 | FY2013〜2018 | FY2019 | FY2020 | FY2021 | FY2022 | FY2023 | FY2024 |
|---------|------|--------|--------|------------|--------|--------|--------|--------|--------|--------|
| `contracts` | 航空局本局XLSX + TCAB + WCAB | **1,374件/353億** ✅ | **1,491件/487億** ✅ | — | — | 1,366件/964億 | 1,996件/1,242億 | 1,997件/1,205億 | 1,935件/972億 | 1,935件/1,189億 |
| `pas_airport_contracts` | 地方整備局PAS Excel | **324件/594億** ✅ | **222件/544億** ✅ | **2,391件/5,381億** ✅ | 0件（永久欠落） | 394件/1,185億 | 489件/1,642億 | 380件/1,593億 | 559件/1,296億 | 418件/797億 |

※ PASは多年度契約が含まれるため調達母数比較には注意。FY2019はアーカイブなしで永久欠落。
FY2020/2021本局XLSXは2026-04-16 WARP :8088ポート経由で収録済み。
FY2013-2018 PASは2026-04-20 WARP旧URLスナップ経由で収録完了。
FY2011/2012 TCAB+WCAB+PASは2026-04-21 `collect_atc_fy2011_2012.py` で収録完了。

---

### ソース1: 航空局本局XLSX（NULL source）

- **URL**:
  ```
  https://www.mlit.go.jp/common/{fileID}.xlsx
  ```
  | FY | 年号 | fileID | WARP取得先 | 状態 |
  |----|------|--------|-----------|------|
  | FY2013 | H25 | 001057801 | coll=20150422, ts=20150404001946, domain=http://www.mlit.go.jp | 収集対象 |
  | FY2014 | H26 | 001082638 | coll=20150422, ts=20150404001946, domain=http://www.mlit.go.jp | 収集対象 |
  | FY2015 | H27 | 001133657 | coll=20190227, ts=20190208070518, domain=https://www.mlit.go.jp | 収集対象 |
  | FY2016 | H28 | 001190907 | coll=20190227, ts=20190208070518, domain=https://www1.mlit.go.jp | 収集対象 |
  | FY2017 | H29 | 001271137 | coll=20190227, ts=20190208070518, domain=https://www1.mlit.go.jp | 収集対象 |
  | FY2018 | H30 | 001382782 | coll=20241025, ts=20241003183110, domain=https://www1.mlit.go.jp | 収集対象 |
  | FY2019 | R1 | 001339479 | coll=20241025, ts=20241003183110, domain=https://www.mlit.go.jp | 収集対象 |
  | R2 (FY2020) | | 001403970 | **収録済み** (WARP :8088ポート経由 2026-04-16) — 536件/682億 |
  | R3 (FY2021) | | 001477645 | **収録済み** (WARP :8088ポート経由 2026-04-16) — 566件/754億 |
  | R4 (FY2022) | | 001614468 | 収録済み |
  | R5 (FY2023) | | 001746233 | 収録済み |
  | R6 (FY2024) | | 001974075 | 収録済み |
  | R6 partial | 001760596 | 4月分のみ（既存FY2024の部分集合）→ スキップ |
  | R7 (FY2025) | 001993986 | 収録済み |

- **FY2020/2021 本局XLSX**: 2026-04-16 WARP の **:8088ポートURL** で取得成功。
  - WARP URL形式: `https://warp.ndl.go.jp/20241025/20241003093110/https://www.mlit.go.jp:8088/common/{fileID}.xlsx`
  - インデックスページ: `https://warp.ndl.go.jp/20241003/20241003183110id_/https://www.mlit.go.jp:8088/koku/koku_tk1_000033.html`
  - **FY2021 fileID訂正**: 旧記録の001447274は誤り。正しくは **001477645**（インデックスHTMLで確認）
  - キャッシュ: `data/cache/honbu/001403970_fy2020.xlsx`, `data/cache/honbu/001477645_fy2021.xlsx`
  - 挿入スクリプト: `collect_honbu_xlsx_fy2020_2021.py`
  - fileIDはWARPの `koku_tk1_000033.html`（ts=20241003183110）で令和2〜6年度の8ファイルが確認可能。
- **収録組織**: 航空局本局 + ATMC3拠点 + 航空大学校（`source_file = 'fy{year}.xlsx'`）
- **パーサー注意**:
  - 月名行（「４月」等）は金額NULLのセパレータ行 → 削除済み（NULL件数=0を確認）
  - 組織名が多バイトで文字化けする場合あり → `text_factory = lambda b: b.decode('utf-8', errors='replace')` で読む
- **FY2022-2024 月名セパレータ**: 全FYで削除済み（確認済み）

---

### ソース2: 東京航空局（TCAB）月次PDF

- **URL パターン（FY2022以降、ライブ）**:
  ```
  https://www.cab.mlit.go.jp/tcab/files/r{YY}_{MM}_bid.pdf   # 一般競争
  https://www.cab.mlit.go.jp/tcab/files/r{YY}_{MM}_zui.pdf   # 随意契約
  ```
- **URL パターン（FY2013〜FY2020、WARP経由）**:
  ```
  # WARP ts=20201001151609, coll=20201031
  https://warp.ndl.go.jp/20201031/20201001151609id_/https://www.cab.mlit.go.jp/tcab/img/contract/06_kekka_pdf/{filename}
  ```
  filename = `{year}_{mm}_bid.pdf` / `{year}_{mm}_zui.pdf`
  year = h24〜h31, r01, r02 （h24_04 = 2012年4月 = FY2012 ← 対象外）
  - 注意: 一部に suffix付き版あり（`h25_04_bid2.pdf` など）
  - 欠落: `h28_09_bid.pdf`（9月2016一般競争のみ欠落）

| FY | 月ファイル群 | 状態 |
|----|------------|------|
| FY2011 (H23) | h23_04〜h24_03 | **収録済み** 748件 (WARP coll=20130610, ts=20130604044002) |
| FY2012 (H24) | h24_04〜h25_03 | **収録済み** 664件 (WARP coll=20201031, ts=20201001151609) |
| FY2013 (H25) | h25_04〜h26_03 | 収集対象 (WARP ts=20201001151609) |
| FY2014 (H26) | h26_04〜h27_03 | 収集対象 |
| FY2015 (H27) | h27_04〜h28_03 | 収集対象 |
| FY2016 (H28) | h28_04〜h29_03 (h28_09_bid欠落) | 収集対象 |
| FY2017 (H29) | h29_04〜h30_03 | 収集対象 |
| FY2018 (H30) | h30_04〜h31_03 | 収集対象 |
| FY2019 (R1) | h31_04, r01_05〜r02_03 | 収集対象 |
| FY2020 (R2) | r02_04〜r02_12, r03_01〜r03_03 | **収録済み** (733件/258億) |
| FY2021 (R3) | r03_04〜r03_12, r04_01〜r04_03 | **収録済み** (559件/172億) |
| FY2022 | r04_04〜r05_03 | **収録済み** |
| FY2023 | r05_04〜r06_03 | **収録済み** |
| FY2024 | r06_04〜r07_03 | **収録済み** |

- **パーサー注意**:
  - `date_x` 列境界バグ → `max(x_min)` で修正済み（`repair_tcab_wcab_v2.py`）
  - 法人番号（13桁）: H27以前（FY2015以前）は存在しない → legacyパーサーを使用
  - ファイル名convention: 現行 `/tcab/files/r{yy}_` vs 旧 `/tcab/img/contract/06_kekka_pdf/{hh}_{mm}_`

#### TCAB FY2020/2021 Legacy PDF形式（法人番号なし）

- **r02_*/r03_01〜09 のPDF**: 13桁法人番号が存在しない旧フォーマット
- **症状**: 通常パーサー（法人番号をアンカーとする）では0件が返る
- **対処**: `collect_atc_fy2020_2021.py` の `parse_tcab_pdf_legacy()` でブロック単位抽出
  - PyMuPDF `page.get_text('dict')` でブロック取得、金額（アラビア数字）をアンカーとして使用
  - 日付は `令和(\d{1,2})年(\d{1,2})月(\d{1,2})日` 正規表現で抽出
  - ファイル名からヒント（r02_04_ → 令和2年4月）でフォールバック
- **検出方法**: `re.findall(r'\b\d{13}\b', full_text)` → 0件なら旧フォーマット確定
- **注意**: Windowsターミナル(cp932)では日本語が文字化けして表示されるが、PDF内のUnicode自体は正常

---

### ソース3: 大阪航空局（WCAB）月次PDF

- **URL パターン**:
  ```
  https://www.cab.mlit.go.jp/wcab/file/{prefix}_{date}.pdf
  ```
  | prefix | 意味 |
  |--------|------|
  | `bk` | 一般競争（建設工事） |
  | `bz` | 随意契約（建設工事） |
  | `kk` | 一般競争（物品役務） |
  | `kz` | 随意契約（物品役務） |

  date形式: `20220701`（8桁）または `220809`（6桁）または `2412`（4桁）→ 年代が下がるほど短縮

- **FY2020**: WARP ts=20211201 スナップショット経由 → **97件/23.9億 収録済み**
- **FY2021**: WARP ts=20220601 スナップショット経由 → **870件/315.7億 収録済み**
- **FY2022**: 4月〜3月全月収録済み。`bk_20220701.pdf` が4〜6月の季報（363件）
- **FY2023**: 4月〜3月全月収録済み（13発行ファイル×4prefix）
- **FY2024**: 全月収録済み
- **WARPでのFY2020/2021データ発見方法**:
  ```
  # Wayback CDX は wcab/file/* をアーカイブしていない → 使用不可
  # WARP published.html スナップショットからURLを発見
  WARP ts=20220601134447: 82ファイル参照 (FY2021後半〜FY2022前半中心)
  WARP ts=20211201145310: 58ファイル参照 (FY2020後半〜FY2021前半中心)
  ```
  → `collect_atc_fy2020_2021.py` 内 `discover_wcab_urls_via_warp()` で実装
- **WARPでのFY2022過去データ回収**:
  ```
  # WARP published.html スナップショット（20230601134447）から追加ファイル発見
  https://warp.ndl.go.jp/web/20230601134447/https://www.cab.mlit.go.jp/wcab/contract/published.html
  ```
  → `collect_wcab_fy2022_warp.py` で67件追加（2026年3月実施）
- **WCAB FY2011/FY2012 旧ドメイン（ocab.mlit.go.jp）形式** — **収録済み** (2026-04-21):
  - URL: `http://ocab.mlit.go.jp/contract/con_6/{FY年度2桁}/{MM}/{kk|kz|bk|bz}.pdf`
  - FY2011 (H23): coll=20130610, ts=20130604044002 → 626件/142億
  - FY2012 (H24): coll=20140611, ts=20140601042445 → 827件/278億
  - 法人番号なし（2015年以前）、平成日付使用 → `collect_atc_fy2011_2012.py` の 平成対応パーサーで処理
  - kk=物品役務一般競争、kz=物品役務随意、bk=建設工事一般競争、bz=建設工事随意 (CLAUDE.md定義準拠)
- **WCAB FY2020/2021 Legacy PDF形式（法人番号なし）**:
  - 法人番号が存在しないため通常の corp_num アンカーパーサーでは0件
  - `parse_records_from_lines_date_anchor()` フォールバックで `令和` 日付行をアンカーとして使用
  - `collect_atc_fy2020_2021.py` の `parse_wcab_pdf()` が自動検出してフォールバック
- **パーサー注意**:
  - 法人番号結合問題（`RE_CORP_NUM_PREFIX`）: 法人番号13桁が前行と結合されるケース → 正規表現で分離
  - NULL contract_amount行: FY2022=3件, FY2023=3件, FY2024=1件（随意契約の特殊フォーマット行、削除推奨）

---

### ソース4: 地方整備局PAS（pas_airport_contracts）

#### URLパターンの変遷（重要）

PASサイトは2020年頃にURL構造が変わった。FY2013〜2019は**旧URL**、FY2020以降は**新URL**を使う。

| 期間 | URLパターン | 注意 |
|------|-----------|------|
| 〜2019年頃（旧） | `http://www.pas.ysk.nilim.go.jp/KekkaKohyo/{局名}/koji{YYYYMM}.xls` | HTTPのみ、/contentsなし |
| 2020年以降（新） | `https://www.pas.ysk.nilim.go.jp/contents/KekkaKohyo/{局名}/koji{YYYYMM}.xls` | HTTPSに変更 |

局名（**先頭大文字**）:
- 新URL（10局）: `Kanto`, `Hokkaido`, `Tohoku`, `Hokuriku`, `Chubu`, `Kinki`, `Chugoku`, `Shikoku`, `Kyushu`, `Okinawa`
- 旧URL（8局）: 上記のうち **Hokkaido・Okinawa は存在しない**（404）

#### FY別収集方法と状態

| FY | 件数 | 金額 | 収集方法 | カバレッジ |
|----|------|------|---------|----------|
| FY2011 | 324件 | 594億 | WARP旧URL coll=20130610 | 概ね完全（4失敗=404） |
| FY2012 | 222件 | 544億 | WARP旧URL coll=20130610 | 概ね完全（4失敗=404） |
| FY2013 | 454件 | 708億 | WARP旧URL coll=20140611 | 12/12ヶ月 完全 |
| FY2014 | 362件 | 488億 | WARP旧URL coll=20150622 | 12/12ヶ月 完全 |
| FY2015 | 424件 | 1,030億 | WARP旧URL coll=20160628 | 12/12ヶ月 完全 |
| FY2016 | 574件 | 1,890億 | WARP旧URL coll=20170629 | 11/12ヶ月（201610欠落） |
| FY2017 | 294件 | 800億 | WARP旧URL coll=20180629 | 12/12ヶ月 完全 |
| FY2018 | 283件 | 466億 | WARP旧URL coll=20190227 | 9/12ヶ月（Jan-Mar2019未アーカイブ） |
| FY2019 | 0件 | — | **永久欠落** | 0/12ヶ月（下記参照） |
| FY2020 | 394件 | 1,185億 | WARP新URL | 収録済み |
| FY2021 | 489件 | 1,642億 | WARP新URL | 収録済み |
| FY2022 | 380件 | 1,593億 | WARP新URL coll=20240601 | 収録済み |
| FY2023 | 559件 | 1,296億 | WARP新URL coll=20240601 | 収録済み |
| FY2024 | 418件 | 797億 | ライブサーバー直接 | 収録済み |
| FY2025 | 446件 | 746億 | ライブサーバー直接 | 収録済み（2026-04-21、〜2026-02月分） |

#### FY2019が永久欠落の理由

旧URL最終WARPスナップ: 2019年2月（koji201804〜201812まで）
新URL最初WARPスナップ: 2022年4月（koji202004から）
→ FY2019（2019年4月〜2020年3月）はどちらの形式でもアーカイブなし。回収不可。

#### FY2013-2018 WARP旧URL スナップショット詳細（確認済み）

```python
OLD_PAS_BASE = 'http://www.pas.ysk.nilim.go.jp'  # HTTPのみ、/contentsなし
WARP_BY_FY = {
    2013: [('20140611', '20140601042445'), ('20130610', '20130604044002')],
    2014: [('20150622', '20150601221742'), ('20140611', '20140601042445')],
    2015: [('20160628', '20160601162952'), ('20150622', '20150601221742')],
    2016: [('20170629', '20170601125730'), ('20160628', '20160601162952')],
    2017: [('20180629', '20180601092430'), ('20170629', '20170601125730')],
    2018: [('20190227', '20190201120557'), ('20180629', '20180601092430')],
}
# WARP URL形式: https://warp.ndl.go.jp/{coll}/{ts}id_/{orig_url}
# 例: https://warp.ndl.go.jp/20140611/20140601042445id_/http://www.pas.ysk.nilim.go.jp/KekkaKohyo/Kanto/koji201304.xls
```

各FYは2スナップを持ち（プライマリ→フォールバック順）で試行。coll=20140611スナップは
koji201304〜201503（FY2013-FY2014）を収録する等、複数年にまたがる。

#### FY2018 欠落詳細

- **201610（FY2016 October）**: 両スナップとも404 → 永久欠落
- **FY2018 Jan-Mar 2019**: coll=20190227は2019年2月クロール → 2019年1〜3月のXLSは未アーカイブ
- **FY2017 局別**: 九州178件/九州317億など、空港系案件が多い局で多くなる

#### スクリプト一覧

| スクリプト | 対象 | 状態 |
|-----------|------|------|
| `collect_atc_fy2011_2012.py` | FY2011/2012 TCAB+WCAB(ocab)+PAS | ✅ 収集完了（2026-04-21）|
| `collect_pas_fy2013_2019.py` | FY2013-2018（旧URL WARP） | ✅ 収集完了（2026-04-20） |
| `collect_pas_fy2020_2021.py` | FY2020-2021（新URL WARP） | ✅ 収集完了 |
| `collect_pas_fy2022_warp.py` | FY2022（新URL WARP） | ✅ 収集完了 |
| `collect_pas_fy2023_warp.py` | FY2023（新URL WARP） | ✅ 収集完了 |
| `collect_pas_airport_fy2024.py` | FY2024（ライブ） | ✅ 収集完了 |

- **収録局**: 旧URL(FY2013-2018): 東北・関東・北陸・中部・近畿・中国・四国・九州（8局）
  新URL(FY2020以降): 上記8局 + 北海道・沖縄（10局）
- **金額フィールド**: `award_amount`（落札額、NULLあり）
- **DLキャッシュ**: `data/raw/pas_kekka/old_{Bureau}_{ftype}{YYYYMM}.xls`（旧URL分、1933ファイル）

---

### ソース5: GEPSポータル（atc_geps.db）

- **URL**:
  ```
  https://api.p-portal.go.jp/pps-web-biz/UAB03/OAB0301?fileversion=v001&filename=successful_bid_record_info_all_{YYYY}.zip
  ```
  YYYY = 2022, 2023, 2024 → 各ZIPに CSVが1ファイル

- **DB**: `data/db/atc_geps.db` (テーブル: `geps_contracts`)
- **件数**:
  | FY | 件数 | 金額 | 備考 |
  |----|------|------|------|
  | FY2020 | 27,581件 | 9,468億 | **全航空局調達**（空港建設含む）— ATC絞り込みには追加フィルタ要 |
  | FY2021 | 29,883件 | 6,988億 | 同上 |
  | FY2022 | 631件 | 355億 | 事前フィルタ済みCSVから収録（ATC中心） |
  | FY2023 | 736件 | 325億 | 同上 |
  | FY2024 | 862件 | 286億 | 同上 |
- **活用**: 他ソースとの突合で取りこぼし特定に使用（`organization_id` 等でフィルタ必要）
- **FY2020/2021 の注意点**:
  - `successful_bid_record_info_all_{year}.zip` には**全航空局調達**が含まれる
  - officer_code `8002040` に 69,500,000,000円 (695億) 等の大型空港整備契約が含まれる
  - FY2022-2024（631-862件）との比較では桁違い → 同一基準での比較不可
  - `generate_budget_5yr.py` では `geps_reference` として参照用途に限定
- **注意**: 組織IDフィルタなしでは全省庁データが入っているため、航空局絞り込みが必要

---

### ソース6: 行政事業レビューDB（atc_review.db）

- **API**:
  ```
  https://rssystem.go.jp/api/projects/?organization_ids=59edd67a-3c2a-4e3a-9c12-35400beae35e
  ```
  → 航空局の25事業を取得（`build_rs_db.py`）

- **テーブル**: `projects`(75件), `expenditure_items`(278件), `payees`(73件)
- **用途**: 歳出目・支出先の確認、事業別の予算構造把握
- **重要な制約**: **支払ベース**（年度内支払額）のため、contracts/pasの**契約ベース**と直接比較不可
  - 多年度契約は契約締結年に全額計上されるが、支払は複数年に分散
  - カバレッジ計算の際は必ず「契約ベース vs 支払ベース」の差異に言及する

---

### 予算分母・カバレッジの定義

**空港整備勘定 歳出合計（概算）**:
| FY | 歳出合計 | 非調達経費 | 調達母数 | 備考 |
|----|---------|----------|---------|------|
| FY2020 (R2) | 3,836億 | 1,805億 | 2,031億 | 推計値 |
| FY2021 (R3) | 3,840億 | 1,805億 | 2,035億 | 推計値 |
| FY2022 (R4) | 3,942億 | 1,805億 | 2,137億 | 確定 |
| FY2023 (R5) | 3,959億 | 1,812億 | 2,147億 | 確定 |
| FY2024 (R6) | 3,959億 | 1,552億 | 2,407億 | 確定 |

**FY2024 歳出内訳（確定値）**:
- 人件費: 827億（航空管制官等職員給与）
- 財投借入金償還: 330億
- 非調達的経費: 395億（国際分担金・離島補助等）
- **調達母数**: 2,407億
  - うちDB収録（航空局本局+TCAB+WCAB）: 1,189億
  - うちDB収録（PAS地整）: 797億
  - **DB合計: 1,986億 / 網羅率 83%**

**出力ファイル**: 
- `data/output/budget_vs_db_5yr.json` （5年分比較データ、`generate_budget_5yr.py`）
- `data/output/budget_vs_db_3yr.json` （旧3年分）

---

### パーサー既知問題まとめ

| 問題 | 対象 | 修正ステータス |
|-----|------|--------------|
| WCAB法人番号結合（`RE_CORP_NUM_PREFIX`）| WCAB全PDF | ✅ `repair_wcab_failed.py` で修正済み |
| TCABの`date_x`列境界バグ | TCAB全PDF | ✅ `repair_tcab_wcab_v2.py` で修正済み |
| XLSXの月名セパレータ行（金額NULL）| 本局XLSX | ✅ 削除済み（3FY全て確認） |
| WCAB bz_*のNULL金額行 | WCAB随意 | ⚠️ FY2022=3件, FY2023=3件, FY2024=1件残存 |

---

---

## 既知のパーサーエラーパターン（要注意）

### WCAB PDFパーサー (collect_atc_monthly.py等)

1. **vendor_nameにPDFヘッダー文字列混入**: 列ずれにより「法人番号」「契約金額」「価）」「落札率」「予定価格」「備考」等のヘッダー文字列がvendor_nameフィールドに入る。随意契約(bz/kz)と建設工事(kk)ファイルで特に発生。
2. **vendor_nameに人物名混入**: 「分任支出負担行為担当官」「分任支出負担行為担当官代理」等の役職文字列がvendor_nameに入る。contracting_officerとvendor_nameのフィールドずれが原因。
3. **vendor_nameとcontract_nameの入れ替わり**: WCABの複数行セルのパースで、件名が業者名フィールドに、業者名が件名フィールドに入るケースあり。contract_name=NULLかつvendor_nameに「工事」「造成」「設置」等が含まれる場合は入れ替わりの強い疑い。
   - 確認済みパターン: `kk_240415.pdf`, `kk_240710.pdf`, `kz_2504.pdf`, `kk_240728.pdf`の計4件（2026-04-19修正済）
   - 注意: 「日本海上工事（株）」等、社名に「工事」を含む正当なベンダー名と混同しないこと
   - 2件は長い件名が折り返されてvendor_nameに流入したケース（`bz_202104.pdf` id=12042, `kk_202105.pdf` id=12295）→ contract_nameに結合済み
4. **bid_methodに法人番号が混入**: 法人番号と入札方式が同一テキスト要素に結合（例: "7490001000241 一般競争入札"）され、bid_methodフィールドに丸ごと入る。2件確認（2026-04-19修正済）。
5. **corporate_numberに改行区切りの複数法人番号が入る**: 1セルに複数行の法人番号が結合されるケース。

### TCAB PDFパーサー

1. **date_x列境界バグ**: 建設工事ページの工期開始日のx座標を契約日の列境界と誤認。`max(x_min)`で修正済みだが、旧フォーマット(r02/r03)では再発の可能性。
2. **旧フォーマット(FY2020以前)で法人番号なし**: r02/r03のPDFは法人番号フィールドが存在しない。レガシーパーサーで対応済みだがcontract_name/vendor_nameがNULLになるケース137-146件あり。

### 本局XLSX

1. **月名セパレータ行の誤取込**: 「５月」「６月」等の見出し行をレコードとして取り込む。contract_amount=NULLで判別可能。削除済みだが再投入時に再発注意。
2. **FY2019データ混入**: source_file=`001339479.xlsx`（R1年度ファイル）がFY2019として取り込まれるケースあり。2026-04-19に550件削除済み。

### PAS Excel

1. **中国局・北陸局のaward_amount NULL率が高い**: 中国FY2024=87%、北陸FY2023=65.7%。元XLS構造の問題ではなく、**落札しなかった入札者の行にaward_amountが存在しない**正常な仕様。planned_price・bid_amountは存在する。修正不要。

### 品質チェック時の確認項目

```sql
-- vendor_nameにヘッダー文字列が混入していないか
SELECT vendor_name, COUNT(*) FROM contracts
WHERE vendor_name IN ('法人番号', '価）', '契約金額', '落札率', '予定価格', '備考')
   OR (vendor_name LIKE '%法人番号%' AND LENGTH(vendor_name) < 10)
GROUP BY vendor_name;

-- vendor_nameに役職文字列が混入していないか
SELECT vendor_name, COUNT(*) FROM contracts
WHERE vendor_name LIKE '%支出負担行為担当官%' GROUP BY vendor_name;

-- bid_methodに法人番号が混入していないか
SELECT bid_method, COUNT(*) FROM contracts
WHERE bid_method GLOB '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9] *'
GROUP BY bid_method;

-- vendor_nameにcontract_nameが入れ替わった疑いがあるか
-- （vendor_nameに「工事」「造成」「設置」「保守」等があり contract_name IS NULLのもの）
SELECT id, vendor_name, contract_name, contract_amount, source_file FROM contracts
WHERE (vendor_name LIKE '%工事%' OR vendor_name LIKE '%造成%' OR vendor_name LIKE '%設置%' OR vendor_name LIKE '%保守%')
  AND contract_name IS NULL AND contract_amount >= 100000000;
```

---
