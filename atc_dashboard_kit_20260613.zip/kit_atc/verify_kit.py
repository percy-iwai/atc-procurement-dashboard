"""同梱DBの整合性検証（新環境用）。

kit_atc/exports/expected_state.json と実際のDBを突合し、
PASS / WARN / FAIL を判定する。

  PASS: 全DBでテーブル件数・FY別集計・SHA256が一致
  WARN: SHA256のみ不一致（件数・集計は一致）— DB更新後のexpected再生成忘れ等
  FAIL: DB欠落・テーブル件数不一致・FY集計不一致

実行: python kit_atc/verify_kit.py
詳細レポート: kit_atc/exports/verify_report.json
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

KIT_DIR = Path(__file__).resolve().parent
ROOT = KIT_DIR.parent
EXPECTED = KIT_DIR / "exports" / "expected_state.json"


def main() -> None:
    if not EXPECTED.exists():
        print(f"SUMMARY result=FAIL reason=expected_state_not_found path={EXPECTED}")
        sys.exit(1)
    expected = json.loads(EXPECTED.read_text(encoding="utf-8"))

    fails: list[str] = []
    warns: list[str] = []
    report: dict = {"checked_at": datetime.now().isoformat(timespec="seconds"),
                    "expected_generated_at": expected.get("generated_at"),
                    "databases": {}, "fails": [], "warns": []}

    for rel, exp in expected["databases"].items():
        p = ROOT / rel
        db_rep: dict = {"exists": p.exists()}
        report["databases"][rel] = db_rep
        if not p.exists():
            fails.append(f"{rel}: DBファイルが存在しない")
            continue

        raw = p.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        db_rep["sha256_match"] = (sha == exp["sha256"])

        con = sqlite3.connect(p)
        db_rep["tables"] = {}
        for t, exp_n in exp["tables"].items():
            try:
                n = con.execute(f"SELECT COUNT(*) FROM [{t}]").fetchone()[0]
            except sqlite3.Error as e:
                fails.append(f"{rel}.{t}: クエリ失敗 ({e})")
                db_rep["tables"][t] = {"expected": exp_n, "actual": None}
                continue
            db_rep["tables"][t] = {"expected": exp_n, "actual": n}
            if n != exp_n:
                fails.append(f"{rel}.{t}: 件数不一致 expected={exp_n} actual={n}")

        for table, fy_exp in exp.get("fy_breakdown", {}).items():
            amount_col = None
            # expectedに記録された集計を再現（カラム名はexport側CONFIGと同一前提:
            # contracts系は contract_amount / award_amount のどちらか）
            for cand in ("contract_amount", "award_amount"):
                try:
                    con.execute(f"SELECT {cand} FROM [{table}] LIMIT 1")
                    amount_col = cand
                    break
                except sqlite3.Error:
                    continue
            if amount_col is None:
                fails.append(f"{rel}.{table}: 金額カラムが見つからない")
                continue
            rows = con.execute(
                f"SELECT fiscal_year, COUNT(*), COALESCE(SUM({amount_col}),0) "
                f"FROM [{table}] GROUP BY fiscal_year").fetchall()
            actual = {str(fy): {"count": n, "amount": int(a)} for fy, n, a in rows}
            for fy, e in fy_exp.items():
                a = actual.get(fy)
                if a is None:
                    fails.append(f"{rel}.{table} FY{fy}: 行が存在しない")
                elif a != e:
                    fails.append(f"{rel}.{table} FY{fy}: 集計不一致 "
                                 f"expected={e} actual={a}")
            for fy in actual:
                if fy not in fy_exp:
                    warns.append(f"{rel}.{table} FY{fy}: expectedにないFYが存在"
                                 f"（増分収集後のexpected未更新?）")
        con.close()

        if not db_rep["sha256_match"]:
            # 件数・集計が全部一致していればWARN扱い（VACUUM等でもshaは変わる）
            warns.append(f"{rel}: sha256不一致（件数は一致）")

    report["fails"] = fails
    report["warns"] = warns
    out = KIT_DIR / "exports" / "verify_report.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=1),
                   encoding="utf-8")

    for f in fails:
        print(f"  [FAIL] {f}")
    for w in warns:
        print(f"  [WARN] {w}")
    result = "FAIL" if fails else ("WARN" if warns else "PASS")
    print(f"SUMMARY result={result} dbs={len(expected['databases'])} "
          f"fails={len(fails)} warns={len(warns)} report={out}")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
