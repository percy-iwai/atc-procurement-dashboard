"""自己完結の引っ越しキットzipを生成する（旧環境で実行）。

同梱物:
  ダッシュボード: deploy/（app.py・atc_procurement.db・予算JSON・.streamlit）
  マスターDB:    data/db/atc_procurement.db data/db/atc_geps.db data/db/atc_review.db
  増分収集:      collect_atc_*.py collect_pas_*.py collect_honbu_*.py collect_tcab_*.py
                 collect_wcab_*.py collect_geps_*.py build_*.py repair_*.py ほか
  キット:        kit_atc/（このフォルダ。exports/expected_state.json 含む）
  ※ data/raw/ の原本キャッシュ（XLS/PDF 1900ファイル超）は同梱しない —
    過去分の再収集はWARP経由で可能（kit_atc/KNOWLEDGE.md にURL全記録）

実行:
  python kit_atc/export_expected_state.py   # 先に検証基準を最新化
  python kit_atc/make_kit_zip.py            # → atc_dashboard_kit_<date>.zip
  python kit_atc/make_kit_zip.py --output D:/path/kit.zip
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from datetime import datetime
from pathlib import Path

KIT_DIR = Path(__file__).resolve().parent
ROOT = KIT_DIR.parent

INCLUDE_DIRS = [
    "kit_atc",
    "deploy",
]
INCLUDE_FILES = [
    "data/db/atc_procurement.db",
    "data/db/atc_geps.db",
    "data/db/atc_review.db",
]
# 収集・修復スクリプト（プロジェクトルート直下のホワイトリスト）
SCRIPT_WHITELIST = [
    # DB構築・基盤
    "build_atc_db.py",
    "build_rs_db.py",
    # 月次・増分収集（ライブサーバー）
    "collect_atc_monthly.py",
    "collect_atc_q4_fy2024.py",
    "collect_atc_wcab_q4_new_fmt.py",
    "collect_pas_airport_fy2024.py",
    "collect_pas_airport_fy2025.py",
    # 過去分収集（WARP/Wayback経由）
    "collect_atc_fy2011_2012.py",
    "collect_atc_fy2020_2021.py",
    "collect_honbu_xlsx_fy2013_2019.py",
    "collect_honbu_xlsx_fy2020_2021.py",
    "collect_tcab_fy2013_2019.py",
    "collect_wcab_fy2022.py",
    "collect_wcab_fy2022_warp.py",
    "collect_wcab_h25_h26.py",
    "collect_wcab_sequential.py",
    "collect_pas_fy2013_2019.py",
    "collect_pas_fy2020_2021.py",
    "collect_pas_fy2022_warp.py",
    "collect_pas_fy2022_wayback.py",
    "collect_pas_fy2023_warp.py",
    "collect_geps_fy2020_2021.py",
    # 修復・品質
    "repair_tcab_wcab_v2.py",
    "repair_wcab_failed.py",
    "fix_all_atc_v2.py",
    "analyze_atc_db.py",
    "analyze_atc_null_org.py",
    # 予算比較JSON生成
    "generate_budget_5yr.py",
    "gen_budget_json.py",
    "extract_airport_budget.py",
    # Excelエクスポート（openpyxlのみで動作・Streamlit不要）
    "create_atc_excel.py",
]

EXCLUDE_PARTS = {"__pycache__", ".venv", "node_modules", ".git"}
EXCLUDE_SUFFIXES = {".pyc", ".log", ".tmp"}
EXCLUDE_NAMES = {"secrets.toml", "verify_report.json", "kit_manifest.json"}


def _excluded(p: Path, include_wheels: bool) -> bool:
    if any(part in EXCLUDE_PARTS for part in p.parts):
        return True
    if not include_wheels and "wheels" in p.parts:
        return True
    if p.suffix.lower() in EXCLUDE_SUFFIXES:
        return True
    if p.name in EXCLUDE_NAMES:
        return True
    return False


def collect_files(include_wheels: bool) -> list[Path]:
    files: list[Path] = []
    for d in INCLUDE_DIRS:
        base = ROOT / d
        if not base.exists():
            print(f"  WARN: {d} が存在しません")
            continue
        for p in base.rglob("*"):
            if p.is_file() and not _excluded(p, include_wheels):
                files.append(p)
    for f in INCLUDE_FILES + SCRIPT_WHITELIST:
        p = ROOT / f
        if p.exists():
            files.append(p)
        else:
            print(f"  WARN: {f} が存在しません")
    return sorted(set(files))


def main() -> None:
    parser = argparse.ArgumentParser(description="航空管制ダッシュボード引っ越しキットzip生成")
    parser.add_argument("--output",
                        default=str(ROOT / f"atc_dashboard_kit_"
                                           f"{datetime.now():%Y%m%d}.zip"))
    parser.add_argument("--include-wheels", action="store_true",
                        help="kit_atc/wheels/（オフラインinstall用）も同梱する")
    args = parser.parse_args()

    expected = KIT_DIR / "exports" / "expected_state.json"
    if not expected.exists():
        print("SUMMARY zip=FAIL reason=expected_state_not_found "
              "(先に export_expected_state.py を実行)")
        sys.exit(1)
    if args.include_wheels and not (KIT_DIR / "wheels").exists():
        print("SUMMARY zip=FAIL reason=wheels_not_found "
              "(先に download_wheels.py を実行)")
        sys.exit(1)

    files = collect_files(args.include_wheels)
    out = Path(args.output)

    manifest: dict = {"created_at": datetime.now().isoformat(timespec="seconds"),
                      "kit": "atc", "files": {}}
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in files:
            rel = p.relative_to(ROOT).as_posix()
            zf.write(p, rel)
            manifest["files"][rel] = {
                "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()[:16],
            }
        zf.writestr("kit_manifest.json",
                    json.dumps(manifest, ensure_ascii=False, indent=1))

    total_mb = sum(v["bytes"] for v in manifest["files"].values()) / 1e6
    print(f"SUMMARY zip=OK files={len(files)} uncompressed={total_mb:.0f}MB "
          f"zip={out.stat().st_size / 1e6:.0f}MB")
    print(f"出力: {out}")


if __name__ == "__main__":
    main()
