# 航空管制調達ダッシュボード 引っ越しキット

国土交通省航空局の調達契約DB（contracts 24,982件＋PAS空港工事 5,134件 / FY2011–2025）と
Streamlit ダッシュボード（`deploy/app.py`）、参照用の GEPS・行政事業レビューDBを
別環境へ移設するためのキットです。

## 考え方 — 防衛キットとの違い（DB同梱型）

防衛調達キット（defense_procurement_2nd/kit）は DB 174MB＋原本キャッシュ10GB超のため
「URLリスト＋パーサーで再生成」方式でしたが、本キットの DB は**合計約45MBと小さい**ため、

- **DB本体をそのまま同梱**します。新環境でのダウンロード・再構築は不要（数分で起動可）
- 収集スクリプトは「ゼロから再構築するため」ではなく**増分更新（新月次・新年度の追加）用**に同梱
  （過去分の再収集はWARP/Waybackスナップショット依存で数日がかり。`KNOWLEDGE.md` に全URLあり）
- 検証は「再構築結果の突合」ではなく「**同梱DBが壊れず届いたかのチェックサム＋件数照合**」

## クイックスタート（3ステップ）

```bash
# 1. 環境構築（Python 3.10+ が必要）
bash kit_atc/setup_env.sh            # Windows: powershell -ExecutionPolicy Bypass -File kit_atc\setup_env.ps1

# 2. 同梱DBの検証（数秒）
python kit_atc/verify_kit.py

# 3. ダッシュボード起動
python -m streamlit run deploy/app.py
```

`verify_kit.py` が `SUMMARY result=PASS` を出せば移設完了。
ブラウザで http://localhost:8501 を開くとダッシュボードが表示されます。

## キットの中身

| パス | 内容 |
|------|------|
| `kit_atc/README_KIT.md` | このファイル（人間向け概要） |
| `kit_atc/SETUP.md` | ステップバイステップ手順書（増分更新手順つき） |
| `kit_atc/AGENT_INSTRUCTIONS.md` | **Claude Cowork 等のAIエージェント向け指示書**（最初に読ませる） |
| `kit_atc/KNOWLEDGE.md` | ドメイン知識（全ソースURL・WARPスナップショット・パーサーの罠） |
| `kit_atc/setup_env.ps1` / `.sh` | Python仮想環境ブートストラップ |
| `kit_atc/requirements.txt` | 依存パッケージ（ダッシュボード＋増分収集） |
| `kit_atc/verify_kit.py` | 同梱DBの整合性検証（PASS/WARN/FAIL） |
| `kit_atc/export_csv_xlsx.py` | **DB → CSV/XLSX 吐き出し**（CSVは標準ライブラリのみ＝pip不要で動く） |
| `kit_atc/download_wheels.py` | （旧環境用）オフラインinstall用wheelsのダウンロード |
| `kit_atc/export_expected_state.py` | （旧環境用）検証基準 expected_state.json の生成 |
| `kit_atc/make_kit_zip.py` | （旧環境用）このzip自体の生成スクリプト（`--include-wheels` でwheels同梱） |
| `kit_atc/exports/expected_state.json` | 検証基準（テーブル件数・SHA256・FY別集計） |
| `deploy/` | **ダッシュボード本体＋atc_procurement.db＋予算JSON**（自己完結） |
| `data/db/atc_procurement.db` | 収集スクリプトが書き込むマスターDB |
| `data/db/atc_geps.db` / `atc_review.db` | GEPSポータル・行政事業レビュー（突合・参照用） |
| `collect_*.py` / `build_*.py` / `repair_*.py` ほか | 収集・修復スクリプト一式（増分＋過去分再収集用） |

## データの中身（2026-06-13 キット作成時点）

| DB | テーブル | 件数 | 内容 |
|----|---------|------|------|
| `atc_procurement.db` | contracts | 24,982 | 航空局本局XLSX＋東京航空局(TCAB)＋大阪航空局(WCAB)、FY2011–2025 |
| `atc_procurement.db` | pas_airport_contracts | 5,134 | 地方整備局PAS空港工事Excel、FY2011–2025（FY2019は永久欠落） |
| `atc_geps.db` | geps_contracts | 59,693 | GEPSポータル落札情報（参照用。FY2020/2021は全省庁データ含む） |
| `atc_review.db` | projects ほか | 75/278/73 | 行政事業レビュー航空局25事業（支払ベース・直接比較不可） |

予算分母・カバレッジの定義（空港整備勘定の調達母数 約2,000〜2,400億/年、網羅率83%@FY2024）は
`KNOWLEDGE.md` 参照。`deploy/data/output/budget_vs_db_5yr.json` がダッシュボードの予算比較タブの元データ。

## 増分更新（新月次・新年度データの追加）

`kit_atc/SETUP.md` の「増分更新」参照。要点:
更新は**マスターDB（`data/db/atc_procurement.db`）に書き込み → `deploy/data/` へコピー → expected再生成**の3手。

## Streamlit と環境制約について（よくある質問）

**Q. Streamlit は移植先で入れ直しが必要？**
はい。仮想環境（.venv）はパス埋め込み＆OS依存のため持ち運べず、移植先で
`setup_env` が requirements.txt から入れ直します（全自動）。

**Q. どんな環境でも入る？**
必要条件は **Python 3.10+ と PyPIへのネット接続** の2つだけ。管理者権限は不要
（venvはユーザー権限で作れる）。プロキシ環境は `pip config` または
`HTTPS_PROXY` 環境変数で通せば可。

**Q. ネットに出られない環境では？**
2段構えで対応:
1. **wheels同梱**: 旧環境で `python kit_atc/download_wheels.py` →
   `python kit_atc/make_kit_zip.py --include-wheels`（zipは+100MB前後）。
   移植先の setup_env が wheels/ を検知して自動でオフラインinstallに切り替わる。
   ※ バイナリwheelのため**移植先とOS・Pythonマイナーバージョンの一致が必要**
   （Linux向けは `--platform manylinux2014_x86_64 --python-version 3.12` 等で指定DL）
2. **縮退モード**: Streamlit が入らなくても
   `python kit_atc/export_csv_xlsx.py --csv-only` は**Python標準ライブラリのみ**で
   全テーブルをCSV化できる（pip install ゼロ）。openpyxl だけ入ればXLSXも出る。
   つまり「収集 → DB → CSV/XLSX」のデータパイプラインはダッシュボード無しでも完結する。

## CSV / XLSX 吐き出し

```bash
python kit_atc/export_csv_xlsx.py            # 全DB・全テーブル → exports_data/
python kit_atc/export_csv_xlsx.py --csv-only # pip不要（標準ライブラリのみ）
python create_atc_excel.py                   # 整形済みExcel（openpyxlのみで動作）
```

## 再現の限界（正直な注意書き）

- DB同梱型のため「同梱DBが壊れていた」場合の復旧はzipの再取得が基本
- 過去分をゼロから再収集する場合はWARP（国立国会図書館）のスナップショットに依存し、
  礼儀的レート制限込みで数日がかり。スナップショットURLは `KNOWLEDGE.md` に全記録済み
- PAS FY2019・TCAB h28_09_bid.pdf 等は**アーカイブ不存在で永久欠落**（欠落＝エラーではない）
