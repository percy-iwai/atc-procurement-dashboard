#!/usr/bin/env python3
"""
3ヶ年予算 vs DB収録額 比較 JSON 生成スクリプト
出力: data/output/budget_vs_db_3yr.json
"""
import sqlite3, json, os

DB_PATH = 'data/db/atc_procurement.db'
OUT_PATH = 'data/output/budget_vs_db_3yr.json'

con = sqlite3.connect(DB_PATH)
con.text_factory = lambda b: b.decode('utf-8', errors='replace')
cur = con.cursor()

# DB実績値取得
db_data = {}
for fy in [2022, 2023, 2024]:
    cur.execute('SELECT COUNT(*), ROUND(SUM(contract_amount)/1e8,1) FROM contracts WHERE fiscal_year=?', (fy,))
    c = cur.fetchone()
    cur.execute('SELECT COUNT(*), ROUND(SUM(award_amount)/1e8,1) FROM pas_airport_contracts WHERE fiscal_year=?', (fy,))
    p = cur.fetchone()

    cur.execute(
        'SELECT source, COUNT(*), ROUND(SUM(contract_amount)/1e8,1) '
        'FROM contracts WHERE fiscal_year=? GROUP BY source ORDER BY source', (fy,))
    src = {}
    for r in cur.fetchall():
        key = r[0] if r[0] else 'mlit_main_xlsx'
        src[key] = {'count': r[1], 'amount_oku': r[2]}

    db_data[fy] = {
        'contracts': {'count': c[0], 'amount_oku': c[1], 'by_source': src},
        'pas': {'count': p[0], 'amount_oku': p[1]},
        'total_amount_oku': round((c[1] or 0) + (p[1] or 0), 1),
        'total_count': c[0] + (p[0] or 0),
    }

con.close()

# 予算パラメータ
# FY2024 各内訳はatc_budget_vs_db.pptx確定値
# FY2022/2023 は比例推計
budget_params = {
    2022: {'total': 3942, 'jinji': 820, 'kanjo': 360, 'hi_cho': 390, 'reiwa': 'R4',
           'note': 'R4年度予算（確定額）。内訳は推計（FY2024確定値から比例配分）。'},
    2023: {'total': 3959, 'jinji': 823, 'kanjo': 345, 'hi_cho': 393, 'reiwa': 'R5',
           'note': 'R5年度予算（確定額）。内訳は推計。'},
    2024: {'total': 3959, 'jinji': 827, 'kanjo': 330, 'hi_cho': 395, 'reiwa': 'R6',
           'note': 'R6年度予算。内訳はatc_budget_vs_db.pptx確定値（2026年4月）。'},
}

by_fy = {}
for fy, p in budget_params.items():
    choutatsu = p['total'] - p['jinji'] - p['kanjo'] - p['hi_cho']
    db_total = db_data[fy]['total_amount_oku']
    coverage = round(db_total / choutatsu * 100, 1)

    src = db_data[fy]['contracts']['by_source']
    by_fy[str(fy)] = {
        'fiscal_year': fy,
        'reiwa_year': p['reiwa'],
        'budget': {
            'koku_seichi_kanjo_total_oku': p['total'],
            'jinji_hi_oku': p['jinji'],
            'jinji_hi_note': '人件費（航空管制官等）' + ('・確定値' if fy == 2024 else '・推計'),
            'shakkin_kanjo_oku': p['kanjo'],
            'shakkin_kanjo_note': '財政投融資等借入金償還' + ('・確定値' if fy == 2024 else '・推計'),
            'hi_choutatsuteki_oku': p['hi_cho'],
            'hi_choutatsuteki_note': '非調達的経費（国際機関分担金・地方空港補助等）' + ('・確定値' if fy == 2024 else '・推計'),
            'choutatsu_boshi_oku': choutatsu,
        },
        'db': {
            'mlit_main_xlsx_oku': src.get('mlit_main_xlsx', {}).get('amount_oku', 0),
            'mlit_main_xlsx_count': src.get('mlit_main_xlsx', {}).get('count', 0),
            'tcab_oku': src.get('tcab', {}).get('amount_oku', 0),
            'tcab_count': src.get('tcab', {}).get('count', 0),
            'wcab_oku': src.get('wcab', {}).get('amount_oku', 0),
            'wcab_count': src.get('wcab', {}).get('count', 0),
            'pas_oku': db_data[fy]['pas']['amount_oku'],
            'pas_count': db_data[fy]['pas']['count'],
            'total_oku': db_total,
            'total_count': db_data[fy]['total_count'],
        },
        'coverage': {
            'rate_pct': coverage,
            'note': '調達母数（推計）に対するDB収録額の比率。契約ベース(DB) vs 支払ベース(予算) の差異あり。',
        },
        'notes': p['note'],
    }

final = {
    '_meta': {
        'generated': '2026-04-14',
        'description': '航空管制調達DB 3ヶ年予算 vs DB収録額 比較',
        'db_path': DB_PATH,
        'budget_source': '空港整備勘定（自動車安全特別会計）歳出合計 — 国土交通省航空局',
        'important_caveats': [
            '予算は「支払ベース」（当該年度の実支出）。DBは「契約ベース」（契約締結額の全額）。',
            'FY2022のDB収録額が調達母数を超える主因：関西空港(1082億)・羽田空港(447億)等の大型多年度建設契約が契約額全体で計上されているため。',
            'FY2024内訳（人件費827億・借入金償還330億・非調達395億）はPPTX確定値。FY2022/2023は比例推計。',
            '行政事業レビューDB(atc_review.db)の支出データも参照可能だが、同様に支払ベース。',
        ],
    },
    'summary': {
        'FY2022': {
            'budget_oku': 3942,
            'db_oku': db_data[2022]['total_amount_oku'],
            'coverage_pct': by_fy['2022']['coverage']['rate_pct'],
        },
        'FY2023': {
            'budget_oku': 3959,
            'db_oku': db_data[2023]['total_amount_oku'],
            'coverage_pct': by_fy['2023']['coverage']['rate_pct'],
        },
        'FY2024': {
            'budget_oku': 3959,
            'db_oku': db_data[2024]['total_amount_oku'],
            'coverage_pct': by_fy['2024']['coverage']['rate_pct'],
        },
    },
    'by_fiscal_year': by_fy,
}

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
with open(OUT_PATH, 'w', encoding='utf-8') as f:
    json.dump(final, f, ensure_ascii=False, indent=2)

print(f'Written: {OUT_PATH}')
print()
print('Summary:')
for fy_key, s in final['summary'].items():
    print(f'  {fy_key}: budget={s["budget_oku"]}億, DB={s["db_oku"]}億, coverage={s["coverage_pct"]}%')
