"""
rssystem.go.jp 行政事業レビュー DB構築スクリプト
航空局 FY2022/2023/2024 の全25事業データを SQLite に格納する。

テーブル:
  projects             - 事業サマリー（予算・執行額）
  expenditure_items    - 歳出目別内訳（費目×予算区分）
  payees               - 支出先（事業一覧ビューの payment_data）
"""

import json
import os
import sqlite3

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "data", "db", "atc_review.db")
LIST_FILES = {
    2022: os.path.join(BASE, "data", "rs_projects", "fy2022_project_list.json"),
    2023: os.path.join(BASE, "data", "rs_projects", "fy2023_project_list.json"),
    2024: os.path.join(BASE, "data", "rs_projects", "fy2024_project_list.json"),
}
DETAIL_DIR = os.path.join(BASE, "data", "rs_projects", "detail")


# ── helpers ───────────────────────────────────────────────────────────────────

def yen(v):
    """円 → 億円文字列（表示用）"""
    if v is None:
        return "N/A"
    return f"{v/1e8:.2f}億円"


def load_detail(project_id, fiscal_year):
    """詳細 JSON を返す。FY2024 は suffix なし, FY2022/2023 は _YYYY suffix。"""
    if fiscal_year == 2024:
        fn = os.path.join(DETAIL_DIR, f"{project_id}.json")
    else:
        fn = os.path.join(DETAIL_DIR, f"{project_id}_{fiscal_year}.json")
    if not os.path.exists(fn):
        # fallback: no suffix
        fn = os.path.join(DETAIL_DIR, f"{project_id}.json")
    if not os.path.exists(fn):
        return None
    with open(fn, "rb") as f:
        return json.loads(f.read().decode("utf-8"))


def extract_budget(detail):
    """
    sub_projects[0].expenditure_carts[0] から予算内訳と執行額を集計して返す。
    Returns:
        initial_budget   : 当初予算 合計
        supplementary    : 補正予算 合計
        carryover        : 繰越 合計
        budget_total     : 上記3者の合計
        executed_amount  : 執行額（execution_item.amount）
        items            : list of { purpose_name, budget_type, finalized_amount }
    """
    initial = supplementary = carryover = 0
    executed = None
    items = []

    subs = detail.get("sub_projects", []) or []
    for sub in subs:
        for cart in sub.get("expenditure_carts", []) or []:
            # 執行額
            exec_item = cart.get("execution_item") or {}
            if exec_item.get("amount") is not None:
                executed = (executed or 0) + exec_item["amount"]

            # 予算内訳
            for ei in cart.get("expenditure_items", []) or []:
                amt = ei.get("finalized_amount") or 0
                bt_type = (ei.get("budget_type") or {}).get("type", "")
                bt_name = (ei.get("budget_type") or {}).get("name", "")

                # 費目名
                ep = ei.get("expenditure_budget_purpose") or {}
                ep_purpose = ep.get("expenditure_purpose") or {}
                ep_upper = ep_purpose.get("upper") or {}
                purpose_name = ep_purpose.get("name") or ep_upper.get("name") or ""
                upper_name   = ep_upper.get("name") or ""

                if bt_type == "initial":
                    initial += amt
                elif bt_type == "supplementary":
                    supplementary += amt
                elif bt_type == "carried-forward":
                    carryover += amt

                items.append({
                    "purpose_name":  purpose_name,
                    "upper_name":    upper_name,
                    "budget_type":   bt_name,
                    "budget_type_code": bt_type,
                    "finalized_amount": amt if amt else None,
                    "requested_amount": ei.get("requested_amount"),
                    "expenditure_item_id": ei.get("id"),
                })

    budget_total = initial + supplementary + carryover
    return initial, supplementary, carryover, budget_total, executed, items


# ── DB 構築 ────────────────────────────────────────────────────────────────────

def build_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    # Drop & recreate
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    cur.executescript("""
    CREATE TABLE projects (
        id              TEXT PRIMARY KEY,
        fiscal_year     INTEGER,
        name            TEXT,
        organization    TEXT,
        org_full_path   TEXT,
        ministry_name   TEXT,
        initial_budget  INTEGER,
        supplementary   INTEGER,
        carryover       INTEGER,
        budget_total    INTEGER,
        executed_amount INTEGER,
        execution_rate  REAL,
        lineage_id      TEXT,
        overview        TEXT
    );

    CREATE TABLE expenditure_items (
        id              TEXT,
        project_id      TEXT,
        fiscal_year     INTEGER,
        purpose_name    TEXT,
        upper_name      TEXT,
        budget_type     TEXT,
        budget_type_code TEXT,
        requested_amount INTEGER,
        finalized_amount INTEGER,
        PRIMARY KEY (id),
        FOREIGN KEY (project_id) REFERENCES projects(id)
    );

    CREATE TABLE payees (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id      TEXT,
        fiscal_year     INTEGER,
        payee_name      TEXT,
        corporate_number TEXT,
        amount          INTEGER,
        FOREIGN KEY (project_id) REFERENCES projects(id)
    );
    """)

    total_inserted = {"projects": 0, "items": 0, "payees": 0}

    for fy, list_file in sorted(LIST_FILES.items()):
        if not os.path.exists(list_file):
            print(f"  [WARN] {list_file} not found, skip FY{fy}")
            continue

        with open(list_file, encoding="utf-8") as f:
            projects_list = json.load(f)

        print(f"\n=== FY{fy}: {len(projects_list)} projects ===")

        for p_list in projects_list:
            pid  = p_list["id"]
            name = p_list["name"]

            org  = p_list.get("organization") or {}
            flatten = org.get("flatten") or {}
            names = flatten.get("names") or []
            org_name = org.get("name", "")
            org_path = " > ".join(names) if names else org_name

            payment_data = p_list.get("payment_data") or {}

            # 詳細データ読み込み
            detail = load_detail(pid, fy)
            if detail is None:
                print(f"  [WARN] detail not found for {pid} FY{fy}")
                initial = supplementary = carryover = budget_total = executed = None
                items = []
            else:
                initial, supplementary, carryover, budget_total, executed, items = extract_budget(detail)
                ministry = detail.get("ministry_name", "")
                overview = detail.get("overview", "")
                lineage  = detail.get("lineage_id", "")

            exec_rate = None
            if budget_total and executed:
                exec_rate = round(executed / budget_total * 100, 2)

            cur.execute("""
                INSERT OR REPLACE INTO projects VALUES
                (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (pid, fy, name, org_name, org_path,
                  detail.get("ministry_name") if detail else None,
                  initial, supplementary, carryover, budget_total,
                  executed, exec_rate,
                  detail.get("lineage_id") if detail else None,
                  detail.get("overview") if detail else None))

            total_inserted["projects"] += 1

            # 歳出目別明細
            for ei in items:
                cur.execute("""
                    INSERT OR IGNORE INTO expenditure_items VALUES
                    (?,?,?,?,?,?,?,?,?)
                """, (ei["expenditure_item_id"], pid, fy,
                      ei["purpose_name"], ei["upper_name"],
                      ei["budget_type"], ei["budget_type_code"],
                      ei["requested_amount"], ei["finalized_amount"]))
                total_inserted["items"] += 1

            # 支出先（payment_data は1件のみ）
            if payment_data and payment_data.get("name"):
                cur.execute("""
                    INSERT INTO payees (project_id, fiscal_year, payee_name, corporate_number, amount)
                    VALUES (?,?,?,?,?)
                """, (pid, fy,
                      payment_data.get("name"),
                      payment_data.get("corporate_number"),
                      payment_data.get("amount")))
                total_inserted["payees"] += 1

            print(f"  [{fy}] {name[:40]!r}")
            print(f"         当初={yen(initial)} 補正={yen(supplementary)} 繰越={yen(carryover)}"
                  f" 計={yen(budget_total)} 執行={yen(executed)}"
                  f" 執行率={exec_rate}%")

    con.commit()
    con.close()

    print(f"\n=== DB構築完了 ===")
    print(f"  projects:          {total_inserted['projects']}")
    print(f"  expenditure_items: {total_inserted['items']}")
    print(f"  payees:            {total_inserted['payees']}")
    print(f"  DB path: {DB_PATH}")


if __name__ == "__main__":
    build_db()
