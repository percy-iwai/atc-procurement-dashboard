#!/usr/bin/env python3
"""
港湾・空港統合サービス (pas.ysk.nilim.go.jp) から
FY2024 空港関連工事・業務の入札結果データを収集

対象: 全8地方整備局 × 12ヶ月 × 工事(koji) + 業務(gyomu)
フィルタ: 空港/滑走路/誘導路/エプロン/航空/空港整備 を工事名・業務名に含むもの

結果: atc_procurement.db の pas_airport_contracts テーブルへ挿入
"""

import re
import time
import sqlite3
import urllib.request
from pathlib import Path
from datetime import datetime, timedelta

try:
    import xlrd
except ImportError:
    import subprocess, sys
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'xlrd==1.2.0'], check=True)
    import xlrd

PROJECT = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
DL_DIR   = PROJECT / 'data/raw/pas_kekka'
DL_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
BASE_URL = 'https://www.pas.ysk.nilim.go.jp/contents/KekkaKohyo/'

BUREAUS = ['Tohoku', 'Kanto', 'Hokuriku', 'Chubu', 'Kinki', 'Chugoku', 'Shikoku', 'Kyushu']

# FY2024 = 2024年4月 〜 2025年3月
FY2024_MONTHS = [
    202404, 202405, 202406, 202407, 202408, 202409,
    202410, 202411, 202412, 202501, 202502, 202503,
]

# 空港関連キーワード
AIRPORT_KW = ['空港', '滑走路', '誘導路', 'エプロン', '航空灯火', '航空保安', '空港整備',
               '空港護岸', '空港埋立', '着陸帯', '旅客搭乗橋', '除雪機庫', '航空局']

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS pas_airport_contracts (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    fiscal_year       INTEGER NOT NULL,
    bureau            TEXT NOT NULL,    -- 関東, 九州, etc.
    file_name         TEXT NOT NULL,    -- koji202404.xls etc.
    file_type         TEXT NOT NULL,    -- koji / gyomu
    contract_name     TEXT,             -- 工事名 / 業務名
    bid_date          TEXT,             -- 入札年月日 YYYYMMDD
    award_date        TEXT,             -- 落札年月日 YYYYMMDD
    work_type         TEXT,             -- 工事業種 / 業務業種
    bid_method        TEXT,             -- 入札方法
    vendor_name       TEXT,             -- 入札業者名
    planned_price     REAL,             -- 予定価格（円）
    bid_amount        REAL,             -- 入札金額
    award_amount      REAL,             -- 落札金額（当初）
    notes             TEXT
)
"""

BUREAU_JA = {
    'Tohoku':  '東北',
    'Kanto':   '関東',
    'Hokuriku': '北陸',
    'Chubu':   '中部',
    'Kinki':   '近畿',
    'Chugoku': '中国',
    'Shikoku': '四国',
    'Kyushu':  '九州',
}


# ============================================================
# Excel serial → YYYYMMDD
# ============================================================

def serial_to_ymd(serial, datemode=0):
    """xlrd が返す数値シリアル → YYYYMMDD 文字列"""
    try:
        v = float(serial)
        if v <= 0:
            return None
        # xlrd のシリアル変換
        t = xlrd.xldate_as_tuple(v, datemode)
        if t[0] == 0:
            return None
        return f'{t[0]:04d}{t[1]:02d}{t[2]:02d}'
    except Exception:
        return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


# ============================================================
# Download
# ============================================================

def download_xls(url, dest_path):
    if dest_path.exists() and dest_path.stat().st_size > 5000:
        return True
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        resp = urllib.request.urlopen(req, timeout=20)
        data = resp.read()
        with open(dest_path, 'wb') as f:
            f.write(data)
        return True
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return False
        return False
    except Exception:
        return False


# ============================================================
# Parse
# ============================================================

def is_airport_related(name):
    if not name:
        return False
    return any(kw in name for kw in AIRPORT_KW)


def parse_xls(fpath, file_type, bureau_en, yyyymm):
    """
    Returns list of dicts for airport-related rows.
    """
    try:
        wb = xlrd.open_workbook(str(fpath))
    except Exception as e:
        print(f"  ERROR opening {fpath.name}: {e}")
        return []

    ws = wb.sheet_by_index(0)
    datemode = wb.datemode

    records = []
    for r in range(ws.nrows):
        if r < 4:  # skip title + headers
            continue

        row = [ws.cell_value(r, c) if c < ws.ncols else '' for c in range(19)]

        # For gyomu files the col structure is slightly different but name is still col1
        name_raw = str(row[1]).strip()
        if not name_raw or name_raw in ('None', ''):
            continue

        if not is_airport_related(name_raw):
            continue

        bid_date   = serial_to_ymd(row[2], datemode)
        award_date = serial_to_ymd(row[3], datemode)

        # If bid_date not available, fall back to yyyymm
        if not bid_date:
            bid_date = f'{str(yyyymm)[:4]}{str(yyyymm)[4:]}01'

        fy = date_to_fy(bid_date) if bid_date else int(str(yyyymm)[:4]) if int(str(yyyymm)[4:]) >= 4 else int(str(yyyymm)[:4]) - 1

        # col8: 予定価格, col9: 入札金額, col11: 落札金額(当初/1回目)
        def safe_float(v):
            try:
                f = float(v)
                return f if f > 0 else None
            except Exception:
                return None

        records.append({
            'fiscal_year':   fy,
            'bureau':        BUREAU_JA.get(bureau_en, bureau_en),
            'file_name':     fpath.name,
            'file_type':     file_type,
            'contract_name': name_raw,
            'bid_date':      bid_date,
            'award_date':    award_date,
            'work_type':     str(row[4]).strip() or None,
            'bid_method':    str(row[5]).strip() or None,
            'vendor_name':   str(row[7]).strip() or None,
            'planned_price': safe_float(row[8]),
            'bid_amount':    safe_float(row[9]),
            'award_amount':  safe_float(row[11]),
            'notes':         str(row[18]).strip() or None,
        })

    return records


# ============================================================
# DB setup & insert
# ============================================================

def setup_db(conn):
    cur = conn.cursor()
    cur.execute(CREATE_TABLE)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_pas_fy ON pas_airport_contracts(fiscal_year)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_pas_bureau ON pas_airport_contracts(bureau)")
    conn.commit()


def get_existing_files(conn):
    cur = conn.cursor()
    try:
        cur.execute("SELECT DISTINCT bureau || '/' || file_name FROM pas_airport_contracts")
        return set(r[0] for r in cur.fetchall())
    except Exception:
        return set()


def insert_records(conn, records):
    if not records:
        return 0
    cur = conn.cursor()
    cur.executemany("""
        INSERT INTO pas_airport_contracts
          (fiscal_year, bureau, file_name, file_type, contract_name,
           bid_date, award_date, work_type, bid_method, vendor_name,
           planned_price, bid_amount, award_amount, notes)
        VALUES
          (:fiscal_year, :bureau, :file_name, :file_type, :contract_name,
           :bid_date, :award_date, :work_type, :bid_method, :vendor_name,
           :planned_price, :bid_amount, :award_amount, :notes)
    """, records)
    conn.commit()
    return len(records)


# ============================================================
# Main
# ============================================================

def main():
    conn = sqlite3.connect(str(DB_PATH))
    setup_db(conn)
    existing = get_existing_files(conn)

    total_dl = 0
    total_inserted = 0
    total_skipped = 0
    stats_by_bureau = {}

    for bureau in BUREAUS:
        bureau_ja = BUREAU_JA.get(bureau, bureau)
        bureau_inserted = 0

        for yyyymm in FY2024_MONTHS:
            for ftype in ['koji', 'gyomu']:
                fname = f'{ftype}{yyyymm}.xls'
                key = f'{bureau_ja}/{fname}'

                if key in existing:
                    total_skipped += 1
                    continue

                url = f'{BASE_URL}{bureau}/{fname}'
                fpath = DL_DIR / f'{bureau}_{fname}'

                ok = download_xls(url, fpath)
                if not ok:
                    continue
                total_dl += 1

                records = parse_xls(fpath, ftype, bureau, yyyymm)
                if records:
                    n = insert_records(conn, records)
                    bureau_inserted += n
                    total_inserted += n

                time.sleep(0.3)

        if bureau_inserted:
            print(f'  {bureau_ja}: {bureau_inserted}件')
        stats_by_bureau[bureau_ja] = bureau_inserted

    print(f'\n=== 収集完了 ===')
    print(f'ダウンロード: {total_dl}ファイル')
    print(f'挿入: {total_inserted}件')
    print(f'スキップ(既存): {total_skipped}件')

    # Summary
    cur = conn.cursor()
    print('\n=== FY2024 空港工事・業務 サマリ ===')
    cur.execute("""
        SELECT bureau, file_type,
               COUNT(*) as cnt,
               ROUND(SUM(COALESCE(award_amount,0))/1e8, 2) as amt
        FROM pas_airport_contracts
        WHERE fiscal_year = 2024
        GROUP BY bureau, file_type
        ORDER BY bureau, file_type
    """)
    print(f'{"局":<8} {"種別":<6} {"件数":>6} {"落札額(億)":>12}')
    print('-' * 36)
    total_cnt = total_amt = 0
    for row in cur.fetchall():
        bureau, ftype, cnt, amt = row
        print(f'{bureau:<8} {ftype:<6} {cnt:>6} {amt or 0:>12.2f}')
        total_cnt += cnt
        total_amt += (amt or 0)
    print('-' * 36)
    print(f'{"合計":<8} {"":6} {total_cnt:>6} {total_amt:>12.2f}')

    conn.close()


if __name__ == '__main__':
    main()
