# -*- coding: utf-8 -*-
"""
atc_procurement.db 分析スクリプト
"""
import sqlite3

DB_PATH = "C:/Users/Percy Iwai/Documents/JAXA_procurement/data/db/atc_procurement.db"

con = sqlite3.connect(DB_PATH)
cur = con.cursor()

print("=" * 60)
print("1. 全体件数・金額サマリー")
print("=" * 60)
cur.execute("SELECT COUNT(*), SUM(contract_amount)/1e8 FROM contracts")
total_cnt, total_amt = cur.fetchone()
print(f"  総件数: {total_cnt:,}件  総契約金額: {total_amt:.1f}億円")

print("\n" + "=" * 60)
print("2. 年度別 件数・金額サマリー")
print("=" * 60)
cur.execute("""
    SELECT fiscal_year,
           COUNT(*) as cnt,
           SUM(contract_amount)/1e8 as amt_oku,
           SUM(CASE WHEN procurement_type='物品役務' THEN 1 ELSE 0 END) as goods_cnt,
           SUM(CASE WHEN procurement_type='建設工事' THEN 1 ELSE 0 END) as works_cnt,
           SUM(CASE WHEN bid_method='一般競争入札' THEN 1 ELSE 0 END) as kyoso_cnt,
           SUM(CASE WHEN bid_method='随意契約' THEN 1 ELSE 0 END) as zuikei_cnt
    FROM contracts
    GROUP BY fiscal_year
    ORDER BY fiscal_year
""")
print(f"{'FY':<6} {'件数':>6} {'金額(億)':>10} {'物品役務':>8} {'建設工事':>8} {'競争':>6} {'随意':>6}")
print("-" * 60)
for row in cur.fetchall():
    fy, cnt, amt, g, w, k, z = row
    print(f"FY{fy}  {cnt:>6,}  {(amt or 0):>9.1f}  {g:>8,}  {w:>8,}  {k:>6,}  {z:>6,}")

print("\n" + "=" * 60)
print("3. 契約担当官（組織）別 集計 — 上位30")
print("=" * 60)

# 契約担当官フィールドから組織名を抽出して集計
cur.execute("""
    SELECT contracting_officer,
           COUNT(*) as cnt,
           ROUND(SUM(contract_amount)/1e8, 1) as amt_oku
    FROM contracts
    WHERE contracting_officer IS NOT NULL
    GROUP BY contracting_officer
    ORDER BY amt_oku DESC
    LIMIT 30
""")
print(f"{'組織名':<55} {'件数':>5} {'金額(億)':>9}")
print("-" * 72)
for row in cur.fetchall():
    officer, cnt, amt = row
    # 長い名前は切り詰め
    name = (officer[:52] + "...") if len(officer) > 55 else officer
    print(f"{name:<55} {cnt:>5,} {(amt or 0):>9.1f}")

print("\n" + "=" * 60)
print("4. 上位10 高額案件 (FY2024)")
print("=" * 60)
cur.execute("""
    SELECT contract_name, vendor_name,
           ROUND(contract_amount/1e8, 3) as amt_oku,
           bid_method, contracting_officer
    FROM contracts
    WHERE fiscal_year = 2024
    ORDER BY contract_amount DESC
    LIMIT 10
""")
for i, row in enumerate(cur.fetchall(), 1):
    name, vendor, amt, method, officer = row
    name = (name[:50] + "...") if name and len(name) > 53 else name
    vendor = (vendor[:20] + "...") if vendor and len(vendor) > 23 else vendor
    print(f"{i:>2}. {amt:>8.3f}億  {name}")
    print(f"       ベンダー: {vendor}  [{method}]")

print("\n" + "=" * 60)
print("5. 航空管制関連キーワードフィルタ")
print("=" * 60)

ATC_KEYWORDS = [
    "管制", "レーダー", "CADIN", "ILS", "VOR", "DME",
    "ASR", "ORSR", "ARSR", "通信", "監視", "航法",
    "CAD", "気象", "ATIS", "ACARS", "空域", "NDB",
    "TACAN", "SSR", "PSR", "MLAT", "ADS-B", "ATC",
]

like_clauses = " OR ".join([f"contract_name LIKE '%{kw}%'" for kw in ATC_KEYWORDS])

cur.execute(f"""
    SELECT fiscal_year,
           COUNT(*) as cnt,
           ROUND(SUM(contract_amount)/1e8, 1) as amt_oku
    FROM contracts
    WHERE {like_clauses}
    GROUP BY fiscal_year
    ORDER BY fiscal_year
""")
rows = cur.fetchall()
print("  年度別（管制関連キーワードにマッチ）:")
print(f"  {'FY':<6} {'件数':>6} {'金額(億)':>10}")
print("  " + "-" * 26)
for fy, cnt, amt in rows:
    print(f"  FY{fy}  {cnt:>6,}  {(amt or 0):>9.1f}")

cur.execute(f"""
    SELECT COUNT(*), ROUND(SUM(contract_amount)/1e8, 1)
    FROM contracts
    WHERE {like_clauses}
""")
atc_cnt, atc_amt = cur.fetchone()
print(f"\n  管制関連合計: {atc_cnt:,}件 / {(atc_amt or 0):.1f}億円")
print(f"  全体比率:    {atc_cnt/total_cnt*100:.1f}% (件数) / "
      f"{(atc_amt or 0)/(total_amt or 1)*100:.1f}% (金額)")

print("\n  キーワード別 上位10件（FY2022〜FY2025合計）:")
kw_results = []
for kw in ATC_KEYWORDS:
    cur.execute(f"""
        SELECT COUNT(*), ROUND(SUM(contract_amount)/1e8,1)
        FROM contracts WHERE contract_name LIKE '%{kw}%'
    """)
    c, a = cur.fetchone()
    if c > 0:
        kw_results.append((kw, c, a or 0))
kw_results.sort(key=lambda x: -x[2])
for kw, c, a in kw_results[:10]:
    print(f"    {kw:<12} {c:>5}件  {a:>7.1f}億")

print("\n" + "=" * 60)
print("6. 管制関連 主要案件一覧（金額上位20件, 全FY）")
print("=" * 60)
cur.execute(f"""
    SELECT fiscal_year, contract_name, vendor_name,
           ROUND(contract_amount/1e8, 3), bid_method
    FROM contracts
    WHERE {like_clauses}
    ORDER BY contract_amount DESC
    LIMIT 20
""")
for row in cur.fetchall():
    fy, name, vendor, amt, method = row
    name = (name[:48] + "...") if name and len(name) > 51 else name
    vendor = (vendor[:18] + "...") if vendor and len(vendor) > 21 else vendor
    print(f"  FY{fy} {amt:>8.3f}億  {name}")
    print(f"         ベンダー: {vendor}  [{method}]")

print("\n" + "=" * 60)
print("7. contract_date 充填率")
print("=" * 60)
cur.execute("""
    SELECT fiscal_year,
           COUNT(*) as total,
           SUM(CASE WHEN contract_date IS NOT NULL THEN 1 ELSE 0 END) as with_date,
           ROUND(100.0*SUM(CASE WHEN contract_date IS NOT NULL THEN 1 ELSE 0 END)/COUNT(*), 1) as pct
    FROM contracts
    GROUP BY fiscal_year
    ORDER BY fiscal_year
""")
for fy, total, with_date, pct in cur.fetchall():
    print(f"  FY{fy}: {with_date}/{total} = {pct}%")

con.close()
