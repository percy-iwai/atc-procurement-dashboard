#!/usr/bin/env python3
"""
PAS (港湾・空港統合サービス) FY2022 April データ Wayback補完

Wayback Machine に 2022-06-19 付でアーカイブされた
全8地方整備局 × 202204 × koji/gyomu の 16ファイルを取得・解析し
pas_airport_contracts テーブルへ挿入する。

確認済み Wayback タイムスタンプ（collapse=original で一意）:
  Chubu/gyomu202204:   20220619071001
  Chubu/koji202204:    20220619070959
  Chugoku/gyomu202204: 20220620203255
  Chugoku/koji202204:  20220620122120
  Hokuriku/gyomu202204:20220619070916
  Hokuriku/koji202204: 20220619070913
  Kanto/gyomu202204:   20220619070822
  Kanto/koji202204:    20220619070819
  Kinki/gyomu202204:   20220619071057
  Kinki/koji202204:    20220619071055
  Kyushu/gyomu202204:  20220622031707
  Kyushu/koji202204:   20220621191339
  Shikoku/gyomu202204: 20220620203341
  Shikoku/koji202204:  20220620203339
  Tohoku/gyomu202204:  20220618222258
  Tohoku/koji202204:   20220618222256

注意:
- Wayback の `if_` 形式で直接 XLS ファイルを取得
- 空港関連キーワードでフィルタリング
- 重複（bureau + file_name 組み合わせ）はスキップ
"""

import re
import time
import sqlite3
import urllib.request
import urllib.error
from pathlib import Path

try:
    import xlrd
except ImportError:
    import subprocess, sys
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'xlrd==1.2.0'], check=True)
    import xlrd

PROJECT = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH = PROJECT / 'data/db/atc_procurement.db'
DL_DIR  = PROJECT / 'data/raw/pas_kekka'
DL_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
PAS_BASE = 'https://www.pas.ysk.nilim.go.jp/contents/KekkaKohyo/'
WB_BASE  = 'https://web.archive.org/web/'

# All 8 bureaus × 2 types × 1 month (202204)
WAYBACK_FILES = [
    # (wayback_ts, bureau_en, bureau_ja, file_name)
    ('20220619071001', 'Chubu',    '中部', 'gyomu202204.xls'),
    ('20220619070959', 'Chubu',    '中部', 'koji202204.xls'),
    ('20220620203255', 'Chugoku',  '中国', 'gyomu202204.xls'),
    ('20220620122120', 'Chugoku',  '中国', 'koji202204.xls'),
    ('20220619070916', 'Hokuriku', '北陸', 'gyomu202204.xls'),
    ('20220619070913', 'Hokuriku', '北陸', 'koji202204.xls'),
    ('20220619070822', 'Kanto',    '関東', 'gyomu202204.xls'),
    ('20220619070819', 'Kanto',    '関東', 'koji202204.xls'),
    ('20220619071057', 'Kinki',    '近畿', 'gyomu202204.xls'),
    ('20220619071055', 'Kinki',    '近畿', 'koji202204.xls'),
    ('20220622031707', 'Kyushu',   '九州', 'gyomu202204.xls'),
    ('20220621191339', 'Kyushu',   '九州', 'koji202204.xls'),
    ('20220620203341', 'Shikoku',  '四国', 'gyomu202204.xls'),
    ('20220620203339', 'Shikoku',  '四国', 'koji202204.xls'),
    ('20220618222258', 'Tohoku',   '東北', 'gyomu202204.xls'),
    ('20220618222256', 'Tohoku',   '東北', 'koji202204.xls'),
]

AIRPORT_KW = [
    '空港', '滑走路', '誘導路', 'エプロン', '航空灯火', '航空保安', '空港整備',
    '空港護岸', '空港埋立', '着陸帯', '旅客搭乗橋', '除雪機庫', '航空局',
]


def is_airport_related(name):
    return bool(name) and any(kw in name for kw in AIRPORT_KW)


def serial_to_ymd(serial, datemode=0):
    try:
        v = float(serial)
        if v <= 0:
            return None
        t = xlrd.xldate_as_tuple(v, datemode)
        if t[0] == 0:
            return None
        return f'{t[0]:04d}{t[1]:02d}{t[2]:02d}'
    except Exception:
        return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def download_wayback(ts, bureau_en, fname, dest_path):
    if dest_path.exists() and dest_path.stat().st_size > 5000:
        return True
    orig_url = f'{PAS_BASE}{bureau_en}/{fname}'
    wb_url = f'{WB_BASE}{ts}if_/{orig_url}'
    req = urllib.request.Request(wb_url, headers=HEADERS)
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        data = resp.read()
        if len(data) < 1000:
            print(f"  WARN: too small ({len(data)} bytes) for {fname}")
            return False
        with open(dest_path, 'wb') as f:
            f.write(data)
        return True
    except urllib.error.HTTPError as e:
        print(f"  HTTP {e.code}: {fname}")
        return False
    except Exception as e:
        print(f"  ERR: {fname}: {e}")
        return False


def parse_xls(fpath, file_type, bureau_en, yyyymm):
    try:
        wb = xlrd.open_workbook(str(fpath))
    except Exception as e:
        print(f"  ERROR opening {fpath.name}: {e}")
        return []

    ws = wb.sheet_by_index(0)
    dm = wb.datemode
    records = []

    for r in range(4, ws.nrows):
        row = [ws.cell_value(r, c) if c < ws.ncols else '' for c in range(19)]
        name_raw = str(row[1]).strip()
        if not name_raw or name_raw in ('None', ''):
            continue
        if not is_airport_related(name_raw):
            continue

        bid_date   = serial_to_ymd(row[2], dm)
        award_date = serial_to_ymd(row[3], dm)

        if not bid_date:
            bid_date = f'{str(yyyymm)[:4]}{str(yyyymm)[4:]}01'

        fy = date_to_fy(bid_date)
        if fy is None:
            fy_from_mm = int(str(yyyymm)[:4]) if int(str(yyyymm)[4:]) >= 4 else int(str(yyyymm)[:4]) - 1
            fy = fy_from_mm

        def safe_float(v):
            try:
                f = float(v)
                return f if f > 0 else None
            except Exception:
                return None

        work_type  = str(row[4]).strip() if len(row) > 4 else None
        bid_method = str(row[5]).strip() if len(row) > 5 else None
        vendor_raw = str(row[7]).strip() if len(row) > 7 else None
        vendor_name = vendor_raw if vendor_raw and vendor_raw != 'None' else None

        planned_price = safe_float(row[8]) if len(row) > 8 else None
        bid_amount    = safe_float(row[9]) if len(row) > 9 else None
        award_amount  = safe_float(row[11]) if len(row) > 11 else None

        records.append({
            'fiscal_year':   fy,
            'bureau':        None,  # filled later
            'file_name':     fpath.name,
            'file_type':     file_type,
            'contract_name': name_raw,
            'bid_date':      bid_date,
            'award_date':    award_date,
            'work_type':     work_type if work_type and work_type != 'None' else None,
            'bid_method':    bid_method if bid_method and bid_method != 'None' else None,
            'vendor_name':   vendor_name,
            'planned_price': planned_price,
            'bid_amount':    bid_amount,
            'award_amount':  award_amount,
            'notes':         'wayback:' + fpath.name[:20],
        })
    return records


def get_existing_keys(conn):
    cur = conn.cursor()
    try:
        cur.execute("SELECT bureau || '/' || file_name FROM pas_airport_contracts")
        return set(r[0] for r in cur.fetchall())
    except Exception:
        return set()


def insert_records(conn, records):
    if not records:
        return 0
    cur = conn.cursor()
    cur.executemany("""
        INSERT INTO pas_airport_contracts
          (fiscal_year, bureau, file_name, file_type, contract_name,
           bid_date, award_date, work_type, bid_method, vendor_name,
           planned_price, bid_amount, award_amount, notes)
        VALUES
          (:fiscal_year, :bureau, :file_name, :file_type, :contract_name,
           :bid_date, :award_date, :work_type, :bid_method, :vendor_name,
           :planned_price, :bid_amount, :award_amount, :notes)
    """, records)
    conn.commit()
    return len(records)


def main():
    conn = sqlite3.connect(str(DB_PATH))
    existing = get_existing_keys(conn)
    print(f"既存レコードキー数: {len(existing)}")

    total_dl = total_ins = total_skip = total_404 = 0

    for ts, bureau_en, bureau_ja, fname in WAYBACK_FILES:
        key = f'{bureau_ja}/{fname}'
        if key in existing:
            print(f"  SKIP (already in DB): {bureau_ja}/{fname}")
            total_skip += 1
            continue

        ftype = 'gyomu' if fname.startswith('gyomu') else 'koji'
        yyyymm_str = re.search(r'(\d{6})', fname)
        yyyymm = int(yyyymm_str.group(1)) if yyyymm_str else 202204

        local_name = f'{bureau_en}_{fname}'
        dest_path = DL_DIR / local_name

        print(f"  Downloading [{ts}] {bureau_ja}/{fname} ...", end=' ')
        ok = download_wayback(ts, bureau_en, fname, dest_path)
        if not ok:
            total_404 += 1
            print("FAILED")
            continue
        total_dl += 1
        print(f"OK ({dest_path.stat().st_size:,} bytes)")

        recs = parse_xls(dest_path, ftype, bureau_en, yyyymm)
        for r in recs:
            r['bureau'] = bureau_ja

        if recs:
            n = insert_records(conn, recs)
            total_ins += n
            fy_counts = {}
            for r in recs:
                fy = r['fiscal_year']
                fy_counts[fy] = fy_counts.get(fy, 0) + 1
            fy_str = ', '.join(f'FY{fy}:{c}件' for fy, c in sorted(fy_counts.items()))
            print(f"    +{n}件新規  ({fy_str})")
        else:
            print(f"    空港関連レコードなし")

        time.sleep(1.0)  # Wayback polite rate limit

    conn.close()

    print(f"\n=== 完了 ===")
    print(f"  ダウンロード: {total_dl}ファイル")
    print(f"  新規挿入:     {total_ins}件")
    print(f"  スキップ:     {total_skip}件")
    print(f"  失敗:         {total_404}件")

    # Final summary
    conn2 = sqlite3.connect(str(DB_PATH))
    cur2 = conn2.cursor()
    print("\n=== pas_airport_contracts DB現状 ===")
    cur2.execute("SELECT fiscal_year, bureau, COUNT(*), SUM(bid_amount)/1e8 FROM pas_airport_contracts GROUP BY fiscal_year, bureau ORDER BY fiscal_year, bureau")
    for r in cur2.fetchall():
        print(f"  FY{r[0]} {r[1]}: {r[2]}件 / {(r[3] or 0):.1f}億")
    conn2.close()


if __name__ == '__main__':
    main()
