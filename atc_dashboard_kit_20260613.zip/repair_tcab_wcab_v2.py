#!/usr/bin/env python3
"""
適正化DB品質修正スクリプト v2
- 重複を避けるため、影響ファイルの全レコードを削除してから再挿入
"""
import sqlite3
import re
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent))
from collect_atc_monthly import (
    parse_tcab_pdf, parse_wcab_pdf, insert_records
)

DB_PATH  = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement/data/db/atc_procurement.db')
PDF_DIR  = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement/data/pdfs/atc')

def main():
    conn = sqlite3.connect(str(DB_PATH))

    # ----------------------------------------------------------------
    # 重複クリーンアップ: 影響を受けたファイルを全削除・再挿入
    # ----------------------------------------------------------------

    # TCAB: 問題ファイルの全レコードを削除してから再挿入
    bad_tcab_files = conn.execute(
        "SELECT DISTINCT source_file FROM contracts "
        "WHERE source='tcab' AND procurement_type='建設工事' "
        "ORDER BY source_file"
    ).fetchall()
    bad_tcab_files = [r[0] for r in bad_tcab_files]

    print(f"[TCAB] 対象ファイル: {len(bad_tcab_files)}件（全削除→再挿入）")
    tcab_total_del = 0
    tcab_total_ins = 0
    for fname in bad_tcab_files:
        # Count all records in this file
        cnt_all = conn.execute(
            "SELECT COUNT(*) FROM contracts WHERE source_file=? AND source='tcab'",
            (fname,)
        ).fetchone()[0]
        # Delete ALL records from this file
        conn.execute("DELETE FROM contracts WHERE source_file=? AND source='tcab'", (fname,))
        conn.commit()
        tcab_total_del += cnt_all

        pdf_path = PDF_DIR / fname
        if not pdf_path.exists():
            print(f"  SKIP (not cached): {fname}")
            continue

        bid_or_zui = 'zui' if '_zui' in fname else 'bid'
        records = parse_tcab_pdf(pdf_path, bid_or_zui)
        ins, skp = insert_records(conn, records, 'tcab', fname)
        tcab_total_ins += ins
        if ins != cnt_all:
            print(f"  {fname}: deleted={cnt_all}, re-inserted={ins} (delta={ins-cnt_all:+d})")

    print(f"[TCAB] 完了: 削除={tcab_total_del}, 挿入={tcab_total_ins}")

    # WCAB: 問題ファイルの全レコードを削除してから再挿入
    bad_wcab_files = [
        'kk_240115.pdf', 'kk_240924.pdf', 'kk_241018.pdf', 'kk_241129.pdf',
        'kk_2412.pdf',   'kk_250116.pdf', 'kk_2504.pdf',  'kk_2505.pdf',
        'kk_2506.pdf',   'kz_240115.pdf', 'kz_240924.pdf','kz_241018.pdf',
        'kz_2412.pdf',   'kz_250116.pdf',
    ]

    print(f"\n[WCAB] 対象ファイル: {len(bad_wcab_files)}件（全削除→再挿入）")
    wcab_total_del = 0
    wcab_total_ins = 0
    for fname in bad_wcab_files:
        cnt_all = conn.execute(
            "SELECT COUNT(*) FROM contracts WHERE source_file=? AND source='wcab'",
            (fname,)
        ).fetchone()[0]
        conn.execute("DELETE FROM contracts WHERE source_file=? AND source='wcab'", (fname,))
        conn.commit()
        wcab_total_del += cnt_all

        cached_fname = f'wcab_{fname}'
        pdf_path = PDF_DIR / cached_fname
        if not pdf_path.exists():
            print(f"  SKIP (not cached): {cached_fname}")
            continue

        m = re.match(r'^([a-z]{2})', fname.lower())
        prefix = m.group(1) if m else 'kk'
        records = parse_wcab_pdf(pdf_path, prefix)
        ins, skp = insert_records(conn, records, 'wcab', fname)
        wcab_total_ins += ins
        print(f"  {fname}: deleted={cnt_all}, re-inserted={ins} (skipped={skp})")
        wcab_total_del += 0  # already counted above

    print(f"[WCAB] 完了: 削除={wcab_total_del}, 挿入={wcab_total_ins}")

    # ----------------------------------------------------------------
    # 最終検証
    # ----------------------------------------------------------------
    print("\n" + "=" * 60)
    print("修正後 DB サマリー")
    print("=" * 60)

    rows = conn.execute("""
        SELECT fiscal_year, procurement_type, COUNT(*),
               ROUND(SUM(COALESCE(contract_amount,0))/1e8, 1)
        FROM contracts
        WHERE source IN ('tcab','wcab')
        GROUP BY fiscal_year, procurement_type
        ORDER BY fiscal_year, procurement_type
    """).fetchall()
    print(f"\n{'FY':<6} {'種別':<12} {'件数':>8} {'金額(億)':>10}")
    print("-" * 40)
    for fy, pt, cnt, amt in rows:
        print(f"{fy:<6} {pt:<12} {cnt:>8,} {amt or 0:>10,.1f}")

    total = conn.execute("""
        SELECT COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,1)
        FROM contracts WHERE source IN ('tcab','wcab')
    """).fetchone()
    print(f"{'合計':<20} {total[0]:>8,} {total[1] or 0:>10,.1f}")

    # Check remaining bad records
    bad_remain = conn.execute(
        "SELECT COUNT(*) FROM contracts WHERE vendor_name LIKE '%支出負担行為%' OR vendor_name LIKE '%石井%'"
    ).fetchone()[0]
    print(f"\n残存バッドレコード(支出負担行為/石井): {bad_remain}件")

    # Check duplicates
    dupes = conn.execute("""
        SELECT COUNT(*) FROM (
            SELECT source_file, corporate_number
            FROM contracts WHERE source IN ('tcab','wcab')
              AND corporate_number IS NOT NULL
            GROUP BY source_file, corporate_number
            HAVING COUNT(*) > 1
        )
    """).fetchone()[0]
    print(f"重複レコード(corp_num): {dupes}件")

    # Overall FY summary
    print(f"\n{'FY':<6} {'件数':>8} {'金額(億円)':>12}")
    print("-" * 28)
    rows2 = conn.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,1)
        FROM contracts GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall()
    for fy, cnt, amt in rows2:
        print(f"{fy:<6} {cnt:>8,} {amt or 0:>12,.1f}")
    total2 = conn.execute("SELECT COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,1) FROM contracts").fetchone()
    print(f"{'合計':<6} {total2[0]:>8,} {total2[1] or 0:>12,.1f}")

    conn.close()
    print("\n完了")

if __name__ == '__main__':
    main()
