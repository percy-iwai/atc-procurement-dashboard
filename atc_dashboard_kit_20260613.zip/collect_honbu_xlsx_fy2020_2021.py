"""
航空局本局 XLSX FY2020/2021 → atc_procurement.db 挿入スクリプト

ダウンロード済みファイル:
  data/cache/honbu/001403970_fy2020.xlsx  (令和2年度)
  data/cache/honbu/001477645_fy2021.xlsx  (令和3年度)

WARP :8088 ポート経由で取得（2026-04-16 発見）
"""

import sqlite3
import os
import re
import datetime
import sys
import warnings
import openpyxl
from openpyxl.utils.datetime import from_excel

warnings.filterwarnings("ignore")

DB_PATH = "C:/Users/Percy Iwai/Documents/JAXA_procurement/data/db/atc_procurement.db"

FILES = {
    2020: ("data/cache/honbu/001403970_fy2020.xlsx", "001403970.xlsx"),
    2021: ("data/cache/honbu/001477645_fy2021.xlsx", "001477645.xlsx"),
}

SHEET_MAP = {
    "物品役務調達（競争入札）": ("物品役務", "一般競争入札"),
    "物品役務調達（随意契約）": ("物品役務", "随意契約"),
    "公共工事調達（競争入札）": ("建設工事", "一般競争入札"),
    "公共工事調達（随意契約）": ("建設工事", "随意契約"),
}

HEADER_KEYWORDS = {
    "contract_name":        ["名称及び数量", "公共工事の名称"],
    "contracting_officer":  ["契約担当官", "氏名並びにその所属"],
    "contract_date":        ["締結した日", "契約日"],
    "vendor":               ["相手方の称号", "相手方の氏名"],
    "corporate_number":     ["法人番号"],
    "contract_basis":       ["随意契約の根拠", "競争入札", "競争種別", "一般競争"],
    "planned_price":        ["予定価格"],
    "contract_amount":      ["契約金額"],
    "award_rate":           ["落札率"],
    "notes":                ["備考"],
    "reemployed_officers":  ["再就職"],
}

# 月名セパレータ行パターン（全角数字・半角数字・漢数字 + 月）
MONTH_SEP_PAT = re.compile(r'^[１２３４５６７８９０一二三四五六七八九十\d]{1,2}月$')


def normalize_date(val) -> str | None:
    if val is None:
        return None
    if isinstance(val, (datetime.datetime, datetime.date)):
        return val.strftime("%Y%m%d")
    if isinstance(val, (int, float)):
        try:
            dt = from_excel(int(val))
            return dt.strftime("%Y%m%d")
        except Exception:
            return None
    s = str(val).strip()
    if not s:
        return None
    m = re.match(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        return f"{m.group(1)}{int(m.group(2)):02d}{int(m.group(3)):02d}"
    m = re.match(r"^[Rr]?(\d{1,2})\.(\d{1,2})\.(\d{1,2})$", s)
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f"{2018 + ry}{mo:02d}{dd:02d}"
    return None


def date_to_fy(ds: str) -> int | None:
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def normalize_amount(val) -> float | None:
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val) if val != 0 else None
    s = str(val).strip().replace(",", "").replace("円", "")
    if not s or s in ("-", "－", "―"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def split_vendor(cell_val) -> tuple[str, str]:
    if cell_val is None:
        return ("", "")
    s = str(cell_val).strip()
    if "\n" in s:
        parts = s.split("\n", 1)
        return (parts[0].strip(), parts[1].strip())
    return (s, "")


def build_col_map(headers: list) -> dict:
    col_map = {}
    for idx, h in enumerate(headers):
        if h is None:
            continue
        h_str = str(h)
        for field, keywords in HEADER_KEYWORDS.items():
            if field not in col_map and any(kw in h_str for kw in keywords):
                col_map[field] = idx
    return col_map


def parse_sheet(ws, fiscal_year_hint: int, procurement_type: str,
                bid_method: str, source_file: str) -> list[dict]:
    rows = list(ws.iter_rows(values_only=True))
    if len(rows) < 3:
        return []

    headers = [str(c) if c is not None else None for c in rows[0]]
    col_map = build_col_map(headers)

    if "contract_name" not in col_map or "contract_amount" not in col_map:
        print(f"  [WARN] 列マッピング失敗: {source_file}")
        print(f"  ヘッダー: {headers[:12]}")
        return []

    records = []
    skipped_sep = 0
    for row in rows[2:]:  # rows[1] は合計/月名行 → スキップ
        def cell(field):
            idx = col_map.get(field)
            return row[idx] if idx is not None and idx < len(row) else None

        contract_name = str(cell("contract_name") or "").strip()
        if not contract_name or contract_name in ("None", "合計", "小計"):
            continue
        # 月名セパレータ行スキップ（'５月'、'６月' 等）
        if MONTH_SEP_PAT.match(contract_name):
            skipped_sep += 1
            continue

        contract_date_raw = normalize_date(cell("contract_date"))
        vendor_raw = cell("vendor")
        vendor_name, vendor_address = split_vendor(vendor_raw)
        contracting_officer = str(cell("contracting_officer") or "").strip()
        corporate_number = str(cell("corporate_number") or "").strip()
        contract_basis = str(cell("contract_basis") or "").strip()
        planned_price = normalize_amount(cell("planned_price"))
        contract_amount = normalize_amount(cell("contract_amount"))
        award_rate = normalize_amount(cell("award_rate"))
        notes = str(cell("notes") or "").strip() or None
        reemployed = str(cell("reemployed_officers") or "").strip() or None

        if contract_date_raw:
            fy = date_to_fy(contract_date_raw)
            if fy is None:
                fy = fiscal_year_hint
        else:
            fy = fiscal_year_hint

        records.append({
            "fiscal_year":         fy,
            "procurement_type":    procurement_type,
            "bid_method":          bid_method,
            "contract_name":       contract_name or None,
            "contracting_officer": contracting_officer or None,
            "contract_date":       contract_date_raw,
            "vendor_name":         vendor_name or None,
            "vendor_address":      vendor_address or None,
            "corporate_number":    corporate_number or None,
            "contract_basis":      contract_basis or None,
            "planned_price":       planned_price,
            "contract_amount":     contract_amount,
            "award_rate":          award_rate,
            "notes":               notes,
            "reemployed_officers": reemployed,
            "source_file":         source_file,
            "source":              None,
            "organization":        None,
        })

    if skipped_sep:
        print(f"    月名セパレータ {skipped_sep}件スキップ")
    return records


INSERT_SQL = """
INSERT INTO contracts
  (fiscal_year, procurement_type, bid_method, contract_name,
   contracting_officer, contract_date, vendor_name, vendor_address,
   corporate_number, contract_basis, planned_price, contract_amount,
   award_rate, notes, reemployed_officers, source_file, source, organization)
VALUES
  (:fiscal_year, :procurement_type, :bid_method, :contract_name,
   :contracting_officer, :contract_date, :vendor_name, :vendor_address,
   :corporate_number, :contract_basis, :planned_price, :contract_amount,
   :award_rate, :notes, :reemployed_officers, :source_file, :source, :organization)
"""


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    total_inserted = 0

    for fy_hint, (path, source_file_id) in sorted(FILES.items()):
        if not os.path.exists(path):
            print(f"[SKIP] {path} not found")
            continue

        # 重複チェック: 同じsource_fileが既に入っていないか
        existing = cur.execute(
            "SELECT COUNT(*) FROM contracts WHERE source_file=?", (source_file_id,)
        ).fetchone()[0]
        if existing > 0:
            print(f"[SKIP] {source_file_id} already in DB ({existing}件)")
            continue

        wb = openpyxl.load_workbook(path, data_only=True)
        print(f"\n=== FY{fy_hint}: {source_file_id} ===")
        print(f"  シート: {wb.sheetnames}")

        file_records = []
        for sheet_name, (p_type, b_method) in SHEET_MAP.items():
            if sheet_name not in wb.sheetnames:
                print(f"  [MISSING] {sheet_name}")
                continue
            ws = wb[sheet_name]
            recs = parse_sheet(ws, fy_hint, p_type, b_method, source_file_id)
            amt = sum(r["contract_amount"] or 0 for r in recs)
            print(f"  {sheet_name}: {len(recs)}件  {amt/1e8:.1f}億")
            file_records.extend(recs)

        # FY汚染チェック: fy_hintと乖離したレコードを報告
        fy_dist = {}
        for r in file_records:
            fy = r["fiscal_year"]
            fy_dist[fy] = fy_dist.get(fy, 0) + 1
        print(f"  FY分布: {dict(sorted(fy_dist.items()))}")

        cur.executemany(INSERT_SQL, file_records)
        con.commit()
        total_inserted += len(file_records)
        print(f"  → {len(file_records)}件挿入完了")

    con.close()
    print(f"\n=== 合計挿入: {total_inserted}件 ===")

    # 結果確認
    con = sqlite3.connect(DB_PATH)
    rows = con.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(contract_amount)/1e8, 1)
        FROM contracts GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall()
    print("\n=== DB最終サマリー ===")
    for r in rows:
        print(f"  FY{r[0]}: {r[1]}件  {r[2]}億")
    con.close()


if __name__ == "__main__":
    main()
