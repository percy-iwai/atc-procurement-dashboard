#!/usr/bin/env python3
"""
GEPS FY2020/2021 収集スクリプト

API:
  https://api.p-portal.go.jp/pps-web-biz/UAB03/OAB0301
  ?fileversion=v001&filename=successful_bid_record_info_all_{YYYY}.zip

対象年: 2020, 2021
フィルタ: 組織コードが航空局関連のもののみ
出力: data/db/atc_geps.db → geps_contracts テーブル

既存データ: FY2022-2024 (2022.csv〜2024.csv) 収録済み
"""

import os
import re
import csv
import sys
import time
import zipfile
import sqlite3
import io
import urllib.request
import urllib.error
from pathlib import Path

PROJECT   = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH   = PROJECT / 'data/db/atc_geps.db'
GEPS_DIR  = PROJECT / 'data/geps'
GEPS_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

GEPS_API = (
    'https://api.p-portal.go.jp/pps-web-biz/UAB03/OAB0301'
    '?fileversion=v001&filename=successful_bid_record_info_all_{year}.zip'
)

# 航空局・地方航空局の組織コード（既存データから確認済みパターン）
# CSVの organization_id / 組織名で航空局を識別
AVIATION_ORG_KEYWORDS = [
    '航空局', '東京航空局', '大阪航空局',
    '地方航空局', '航空管制', '航空交通',
    '国土交通省航空局',
]

# 既知の航空局 organization_id プレフィックス（存在する場合）
AVIATION_ORG_PREFIXES = ['030125']  # 国土交通省航空局の省庁コード系


def is_aviation_org(row_dict):
    """行が航空局関連かチェック。"""
    # キーが列名に依存するため、複数のキーを試す
    for key in ('organization_name', 'org_name', '機関名', '組織名',
                'contracting_office_name', 'contracting_office'):
        v = row_dict.get(key, '')
        if v and any(kw in str(v) for kw in AVIATION_ORG_KEYWORDS):
            return True
    for key in ('organization_id', 'org_id', '機関コード', '組織コード',
                'contracting_office_id'):
        v = str(row_dict.get(key, ''))
        if any(v.startswith(pfx) for pfx in AVIATION_ORG_PREFIXES):
            return True
    return False


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    s = str(ds).replace('-', '').replace('/', '')
    if len(s) < 6:
        return None
    try:
        y, mo = int(s[:4]), int(s[4:6])
        return y if mo >= 4 else y - 1
    except Exception:
        return None


def normalize_date(s):
    if not s:
        return None
    s = str(s).strip()
    m = re.match(r'(\d{4})[-/](\d{1,2})[-/](\d{1,2})', s)
    if m:
        return f'{m.group(1)}{int(m.group(2)):02d}{int(m.group(3)):02d}'
    m = re.match(r'(\d{8})$', s)
    if m:
        return s
    return s[:8] if len(s) >= 8 else s


def normalize_amount(s):
    if not s:
        return None
    t = str(s).replace(',', '').replace('円', '').strip()
    try:
        v = float(t)
        return v if v > 0 else None
    except Exception:
        return None


def download_geps_zip(year):
    """Download GEPS ZIP for given year. Returns path or None."""
    dest = GEPS_DIR / f'successful_bid_record_info_all_{year}.zip'
    if dest.exists() and dest.stat().st_size > 10000:
        print(f"  {dest.name}: キャッシュ使用")
        return dest

    url = GEPS_API.format(year=year)
    print(f"  ダウンロード: {url}")
    try:
        req  = urllib.request.Request(url, headers=HEADERS)
        resp = urllib.request.urlopen(req, timeout=60)
        data = resp.read()
        if len(data) < 1000:
            print(f"  WARN: レスポンスが小さすぎます ({len(data)} bytes)")
            return None
        dest.write_bytes(data)
        print(f"  → {len(data):,} bytes 保存: {dest.name}")
        return dest
    except urllib.error.HTTPError as e:
        print(f"  HTTP {e.code}: {url}")
        return None
    except Exception as e:
        print(f"  ERROR: {e}")
        return None


def parse_geps_zip(zip_path, target_years):
    """
    ZIPを展開してCSVをパース。
    CSVはヘッダー行なし。列順序:
      0: procurement_id
      1: contract_name
      2: contract_date (YYYY-MM-DD)
      3: contract_amount
      4: bid_method_code
      5: officer_code  ← 航空局フィルタに使用
      6: vendor_name
      7: corporate_number
    航空局officer_code: 8002* (本局), 8011* (東京), 8001* (大阪)
    """
    # 既存DB (FY2022-2024) に存在する航空局officer_code（完全一致）
    AVIATION_OFFICER_CODES = {
        '8002010',  # 国土交通省 航空局
        '8002040',  # 国土交通省 航空局（別部門）
        '8011010',  # 東京航空局
        '8001010',  # 大阪航空局
        '8004025',
        '8004020',
        '8014025',
        '8002020',
        '8004030',
    }

    records = []
    try:
        with zipfile.ZipFile(str(zip_path), 'r') as zf:
            csv_names = [n for n in zf.namelist() if n.lower().endswith('.csv')]
            if not csv_names:
                print(f"  WARN: CSV not found in {zip_path.name}")
                return records
            print(f"  CSV files in ZIP: {csv_names}")

            for csv_name in csv_names:
                raw = zf.read(csv_name)
                # Try UTF-8 then Shift-JIS
                for enc in ('utf-8-sig', 'utf-8', 'shift_jis', 'cp932'):
                    try:
                        text = raw.decode(enc)
                        break
                    except Exception:
                        text = None
                if not text:
                    print(f"  WARN: Cannot decode {csv_name}")
                    continue

                # CSVはヘッダー行なし → positional読み込み
                reader = csv.reader(io.StringIO(text))
                rows_parsed = rows_kept = 0
                for row in reader:
                    rows_parsed += 1
                    if len(row) < 7:
                        continue

                    # Field positions (0-indexed)
                    procurement_id  = row[0].strip()
                    contract_name   = row[1].strip()
                    contract_date_r = row[2].strip()
                    amount_raw      = row[3].strip()
                    bid_method_code = row[4].strip() if len(row) > 4 else ''
                    officer_code    = row[5].strip() if len(row) > 5 else ''
                    vendor_name     = row[6].strip() if len(row) > 6 else ''
                    corp_number     = row[7].strip() if len(row) > 7 else ''

                    # Aviation org filter by exact officer_code
                    if officer_code not in AVIATION_OFFICER_CODES:
                        continue

                    contract_date = normalize_date(contract_date_r)
                    fy = date_to_fy(contract_date)
                    if fy not in target_years:
                        continue

                    rows_kept += 1
                    records.append({
                        'procurement_id':  procurement_id,
                        'contract_name':   contract_name,
                        'contract_date':   contract_date,
                        'contract_amount': normalize_amount(amount_raw),
                        'bid_method_code': bid_method_code,
                        'bid_method':      '一般競争入札' if bid_method_code.startswith('K') else
                                           '随意契約' if bid_method_code.startswith('S') else bid_method_code,
                        'officer_code':    officer_code,
                        'vendor_name':     vendor_name,
                        'corporate_number': corp_number,
                        'fiscal_year':     fy,
                        'source_file':     csv_name,
                    })
                print(f"  {csv_name}: {rows_parsed}行スキャン, {rows_kept}行保持")

    except zipfile.BadZipFile as e:
        print(f"  BadZipFile: {zip_path.name}: {e}")
    except Exception as e:
        print(f"  ERROR parsing {zip_path.name}: {e}")

    return records


def _parse_geps_zip_UNUSED(zip_path, target_years):
    """Old dict-reader version (unused)."""
    records = []
    try:
        with zipfile.ZipFile(str(zip_path), 'r') as zf:
            csv_names = [n for n in zf.namelist() if n.lower().endswith('.csv')]
            if not csv_names:
                return records
            for csv_name in csv_names:
                raw = zf.read(csv_name)
                for enc in ('utf-8-sig', 'utf-8', 'shift_jis', 'cp932'):
                    try:
                        text = raw.decode(enc)
                        break
                    except Exception:
                        text = None
                if not text:
                    continue
                reader = csv.DictReader(io.StringIO(text))
                rows_parsed = rows_kept = 0
                for row in reader:
                    rows_parsed += 1
                    # Date field candidates
                    contract_date_raw = (
                        row.get('contract_date') or
                        row.get('締結日') or
                        row.get('落札日') or
                        row.get('契約締結日') or
                        ''
                    )
                    contract_date = normalize_date(contract_date_raw)
                    fy = date_to_fy(contract_date)
                    if fy not in target_years:
                        continue
                    if not is_aviation_org(row):
                        continue
                    rows_kept += 1
                    records.append({
                        'procurement_id':  (row.get('procurement_id') or ''),
                        'contract_name':   (row.get('contract_name') or
                                            row.get('件名') or
                                            row.get('調達件名') or ''),
                        'contract_date':   contract_date,
                        'contract_amount': normalize_amount(
                            row.get('contract_amount') or
                            row.get('落札金額') or
                            row.get('契約金額') or ''
                        ),
                        'bid_method_code': (row.get('bid_method_code') or
                                            row.get('入札方式コード') or ''),
                        'bid_method':      (row.get('bid_method') or
                                            row.get('入札方式') or ''),
                        'officer_code':    (row.get('officer_code') or
                                            row.get('機関コード') or
                                            row.get('contracting_office_id') or ''),
                        'vendor_name':     (row.get('vendor_name') or
                                            row.get('落札者名') or
                                            row.get('契約相手方名') or ''),
                        'corporate_number': (row.get('corporate_number') or
                                             row.get('法人番号') or ''),
                        'fiscal_year':     fy,
                        'source_file':     csv_name,
                    })
                print(f"  {csv_name}: {rows_parsed}行スキャン, {rows_kept}行保持")

    except zipfile.BadZipFile as e:
        print(f"  BadZipFile: {zip_path.name}: {e}")
    except Exception as e:
        print(f"  ERROR parsing {zip_path.name}: {e}")

    return records


def setup_geps_db(conn):
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS geps_contracts (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            procurement_id   TEXT,
            contract_name    TEXT,
            contract_date    TEXT,
            contract_amount  REAL,
            bid_method_code  TEXT,
            bid_method       TEXT,
            officer_code     TEXT,
            vendor_name      TEXT,
            corporate_number TEXT,
            fiscal_year      INTEGER,
            source_file      TEXT
        )
    """)
    conn.commit()


def get_existing_source_files(conn):
    cur = conn.cursor()
    try:
        cur.execute("SELECT DISTINCT source_file FROM geps_contracts")
        return {r[0] for r in cur.fetchall()}
    except Exception:
        return set()


def insert_geps_records(conn, records):
    if not records:
        return 0
    cur = conn.cursor()
    cur.executemany("""
        INSERT INTO geps_contracts
          (procurement_id, contract_name, contract_date, contract_amount,
           bid_method_code, bid_method, officer_code, vendor_name,
           corporate_number, fiscal_year, source_file)
        VALUES
          (:procurement_id, :contract_name, :contract_date, :contract_amount,
           :bid_method_code, :bid_method, :officer_code, :vendor_name,
           :corporate_number, :fiscal_year, :source_file)
    """, records)
    conn.commit()
    return len(records)


def main():
    conn = sqlite3.connect(str(DB_PATH))
    setup_geps_db(conn)
    existing_files = get_existing_source_files(conn)
    print(f"既存ソースファイル: {existing_files}")

    target_years = {2020, 2021}
    total_ins = 0

    for year in [2020, 2021]:
        print(f"\n=== GEPS {year} (FY{year}) ===")
        zip_path = download_geps_zip(year)
        if not zip_path:
            print(f"  SKIP: ダウンロード失敗")
            continue
        time.sleep(1)

        records = parse_geps_zip(zip_path, target_years)
        if not records:
            print(f"  航空局関連レコードなし")
            continue

        # Dedup by source_file (skip if already loaded)
        new_records = [r for r in records if r['source_file'] not in existing_files]
        n = insert_geps_records(conn, new_records)
        total_ins += n
        print(f"  {n}件挿入 ({len(records) - n}件スキップ)")
        # Add source files to existing set
        for r in new_records:
            existing_files.add(r['source_file'])

    conn.close()

    print(f"\n=== GEPS FY2020/2021 収集完了: {total_ins}件挿入 ===")

    # Summary
    conn2 = sqlite3.connect(str(DB_PATH))
    cur2  = conn2.cursor()
    print('\n=== GEPS 全FY集計 ===')
    cur2.execute("""
        SELECT fiscal_year, COUNT(*),
               ROUND(SUM(COALESCE(contract_amount,0))/1e8, 2)
        FROM geps_contracts
        GROUP BY fiscal_year ORDER BY fiscal_year
    """)
    for row in cur2.fetchall():
        print(f'  FY{row[0]}: {row[1]}件 / {row[2]}億円')
    conn2.close()


if __name__ == '__main__':
    main()
