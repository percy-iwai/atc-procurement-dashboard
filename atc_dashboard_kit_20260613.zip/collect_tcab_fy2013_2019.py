#!/usr/bin/env python3
"""
TCAB PDF FY2013-2019 (平成25年〜令和元年) 収集・パーススクリプト

WARP経由でTCAB月次PDFをダウンロードし、atc_procurement.dbに挿入する。

WARP snapshot:
  coll = 20201031
  ts   = 20201001151609
  base = https://www.cab.mlit.go.jp/tcab/img/contract/06_kekka_pdf/

ファイル命名規則:
  h25_04_bid.pdf, h25_04_zui.pdf  ← FY2013 4月 (平成25年4月)
  ...
  h31_04_bid.pdf                  ← FY2019 4月 (平成31年4月)
  r01_05_bid.pdf                  ← FY2019 5月 (令和1年5月)
  ...
  r02_03_zui.pdf                  ← FY2019 3月末 (令和2年3月 = FY2019末)

Usage:
    python collect_tcab_fy2013_2019.py [--dry-run] [--fy 2013] [--skip-download]
"""

import re
import sys
import time
import sqlite3
import argparse
import urllib.request
import urllib.error
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    print("ERROR: PyMuPDF not installed. Run: pip install pymupdf")
    sys.exit(1)

# ============================================================
# Constants
# ============================================================
PROJECT  = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR  = PROJECT / 'data/pdfs/tcab_historical'
PDF_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

WARP_COLL     = '20201031'
WARP_TS       = '20201001151609'
TCAB_PDF_BASE = 'https://www.cab.mlit.go.jp/tcab/img/contract/06_kekka_pdf/'

HEISEI_BASE = 1988   # 平成N年 = 1988+N
REIWA_BASE  = 2018   # 令和N年 = 2018+N

TARGET_FY = set(range(2013, 2020))  # FY2013–FY2019

# Date patterns (both 平成 and 令和)
RE_HEISEI_DATE  = re.compile(r'平成(\d{1,2})年(\d{1,2})月(\d{1,2})日')
RE_REIWA_DATE   = re.compile(r'令和(\d{1,2})年(\d{1,2})月(\d{1,2})日')
RE_LARGE_AMOUNT = re.compile(r'^[\d,]{5,15}$')

# ============================================================
# Date/FY helpers
# ============================================================

def hm_date_to_ymd(text):
    """Convert 平成/令和 date string to YYYYMMDD, or None."""
    m = RE_HEISEI_DATE.search(text)
    if m:
        hy, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= hy <= 64 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{HEISEI_BASE + hy}{mo:02d}{dd:02d}'
    m = RE_REIWA_DATE.search(text)
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{REIWA_BASE + ry}{mo:02d}{dd:02d}'
    return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1

# ============================================================
# File list generation
# ============================================================

def cal_to_fname_prefix(cal_year, mo):
    """Convert calendar year + month to TCAB filename prefix (h25_04 or r01_05)."""
    if cal_year < 2019 or (cal_year == 2019 and mo <= 4):
        heisei_yr = cal_year - HEISEI_BASE
        return f'h{heisei_yr:02d}_{mo:02d}'
    else:
        reiwa_yr = cal_year - REIWA_BASE
        return f'r{reiwa_yr:02d}_{mo:02d}'


def generate_file_list():
    """
    Generate list of (filename, fy_hint, bid_or_zui) for FY2013-FY2019.
    Each FY = April of that year through March of next year.
    """
    files = []
    for fy in range(2013, 2020):
        # April–December: calendar year = fy
        for mo in range(4, 13):
            prefix = cal_to_fname_prefix(fy, mo)
            for sfx in ('bid', 'zui'):
                files.append((f'{prefix}_{sfx}.pdf', fy, sfx))
        # January–March: calendar year = fy + 1
        for mo in range(1, 4):
            prefix = cal_to_fname_prefix(fy + 1, mo)
            for sfx in ('bid', 'zui'):
                files.append((f'{prefix}_{sfx}.pdf', fy, sfx))
    return files

# ============================================================
# Download
# ============================================================

def download_from_warp(fname, dest_path):
    """Download a TCAB PDF from the WARP snapshot."""
    if dest_path.exists() and dest_path.stat().st_size > 500:
        return True

    orig_url = TCAB_PDF_BASE + fname
    warp_url = f'https://warp.ndl.go.jp/{WARP_COLL}/{WARP_TS}id_/{orig_url}'

    for attempt in range(3):
        try:
            req  = urllib.request.Request(warp_url, headers=HEADERS)
            resp = urllib.request.urlopen(req, timeout=30)
            data = resp.read()
            if len(data) < 500:
                return False
            if not data.startswith(b'%PDF'):
                # WARP may return an HTML error page
                return False
            dest_path.write_bytes(data)
            return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return False
            if attempt < 2:
                time.sleep(3)
        except Exception:
            if attempt < 2:
                time.sleep(3)
    return False

# ============================================================
# PDF parsing (平成 era block-based legacy parser)
# ============================================================

def _parse_amount(s):
    t = s.replace(',', '').strip()
    try:
        v = float(t)
        return v if v >= 1000 else None
    except Exception:
        return None


def _parse_rate(s):
    t = s.strip().rstrip('%')
    try:
        v = float(t)
        return v if 0 < v <= 100 else None
    except Exception:
        return None


def parse_tcab_pdf_heisei(pdf_path, bid_or_zui, fy_hint, month_hint):
    """
    Parse legacy TCAB PDFs (H25–H31/R01 era) using PyMuPDF block mode.
    PDFs have 平成/令和 date strings and no corporate numbers.
    """
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening {pdf_path.name}: {e}")
        return []

    bid_method_default = '随意契約' if bid_or_zui == 'zui' else '一般競争入札'
    records = []

    for page in doc:
        page_text = page.get_text()
        if not page_text.strip():
            continue

        # Detect procurement type from page header
        if '物品役務' in page_text:
            ptype = '物品役務'
        elif '公共工事' in page_text:
            ptype = '建設工事'
        else:
            ptype = '物品役務'

        d = page.get_text('dict')
        for block in d.get('blocks', []):
            spans = []
            for line in block.get('lines', []):
                for span in line.get('spans', []):
                    t = span.get('text', '').strip()
                    if t:
                        spans.append(t)
            if not spans:
                continue

            # Must contain at least 2 large monetary amounts to be a data record
            amounts_in_block = []
            for s in spans:
                v = _parse_amount(s)
                if v is not None and v > 100000:
                    amounts_in_block.append(v)
            if len(amounts_in_block) < 2:
                continue

            # Extract contract date
            contract_date = None
            for s in spans:
                d_str = hm_date_to_ymd(s)
                if d_str:
                    contract_date = d_str
                    break
            if not contract_date:
                # Fallback: use year/month from filename
                cal_year = fy_hint if month_hint >= 4 else fy_hint + 1
                contract_date = f'{cal_year}{month_hint:02d}01'

            # Amounts: largest = planned_price, 2nd = contract_amount
            amounts_in_block.sort(reverse=True)
            planned_price   = amounts_in_block[0]
            contract_amount = amounts_in_block[1] if len(amounts_in_block) > 1 else None
            # Sanity swap
            if planned_price and contract_amount and planned_price < contract_amount:
                planned_price, contract_amount = contract_amount, planned_price

            # Award rate: float between 50-100 with decimal point
            award_rate = None
            for s in spans:
                if RE_LARGE_AMOUNT.match(s.replace(',', '')):
                    continue
                v = _parse_rate(s)
                if v is not None and 50 < v <= 100 and '.' in s:
                    award_rate = v
                    break

            # Bid method
            bid_method = bid_method_default
            for s in spans:
                if '随意契約' in s and len(s) < 25:
                    bid_method = '随意契約'
                    break
                if '競争入札' in s or '指名競争' in s:
                    bid_method = '一般競争入札'
                    break

            # Contract name: first substantive non-date non-amount span
            contract_name = None
            for s in spans:
                if len(s) < 6:
                    continue
                if RE_HEISEI_DATE.search(s) or RE_REIWA_DATE.search(s):
                    continue
                if RE_LARGE_AMOUNT.match(s.replace(',', '')):
                    continue
                try:
                    float(s.replace(',', ''))
                    continue
                except ValueError:
                    pass
                # Skip page-header-like strings
                if len(s) > 80:
                    continue
                if any(kw in s for kw in ('公共調達', '契約担当官', '相手方の商号', '物品役務の名称',
                                           '公共工事の名称', '随意契約によることとした',
                                           '一般競争入札', '競争入札')):
                    continue
                contract_name = s
                break

            if contract_amount is None:
                continue

            records.append({
                'contract_name':       contract_name,
                'contracting_officer': None,
                'contract_date':       contract_date,
                'vendor_name':         None,
                'vendor_address':      None,
                'corporate_number':    None,
                'bid_method':          bid_method,
                'contract_basis':      None,
                'planned_price':       planned_price,
                'contract_amount':     contract_amount,
                'award_rate':          award_rate,
                'procurement_type':    ptype,
            })

    doc.close()
    return records

# ============================================================
# DB helpers
# ============================================================

def setup_db(conn):
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(contracts)")
    cols = [r[1] for r in cur.fetchall()]
    if 'source' not in cols:
        cur.execute("ALTER TABLE contracts ADD COLUMN source TEXT")
        conn.commit()


def get_existing_source_files(conn):
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT source_file FROM contracts WHERE source_file IS NOT NULL")
    return {r[0] for r in cur.fetchall()}


def insert_records(conn, records, source_file, target_fy, dry_run=False):
    cur  = conn.cursor()
    ins  = 0
    skip = 0
    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy != target_fy:
            skip += 1
            continue
        if dry_run:
            ins += 1
            continue
        try:
            cur.execute("""
                INSERT INTO contracts (
                    fiscal_year, procurement_type, bid_method,
                    contract_name, contracting_officer, contract_date,
                    vendor_name, vendor_address, corporate_number,
                    contract_basis, planned_price, contract_amount, award_rate,
                    notes, source_file, source
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                fy,
                rec.get('procurement_type', '物品役務'),
                rec.get('bid_method', ''),
                rec.get('contract_name'),
                rec.get('contracting_officer'),
                rec.get('contract_date'),
                rec.get('vendor_name'),
                rec.get('vendor_address'),
                rec.get('corporate_number'),
                rec.get('contract_basis'),
                rec.get('planned_price'),
                rec.get('contract_amount'),
                rec.get('award_rate'),
                None,
                source_file,
                'tcab',
            ))
            ins += 1
        except sqlite3.Error as e:
            print(f"  DB error: {e}")
            skip += 1
    if not dry_run:
        conn.commit()
    return ins, skip

# ============================================================
# Main
# ============================================================

def main():
    ap = argparse.ArgumentParser(description='TCAB PDF FY2013-2019 収集スクリプト')
    ap.add_argument('--dry-run',       action='store_true', help='DBには書き込まない')
    ap.add_argument('--fy',            type=int,            help='特定FYのみ処理 (例: 2013)')
    ap.add_argument('--skip-download', action='store_true', help='ダウンロードをスキップ (ローカル既存ファイルのみ処理)')
    args = ap.parse_args()

    sys.stdout.reconfigure(encoding='utf-8')

    conn = sqlite3.connect(str(DB_PATH))
    setup_db(conn)
    existing = get_existing_source_files(conn)

    file_list = generate_file_list()
    if args.fy:
        file_list = [(f, fy, sfx) for f, fy, sfx in file_list if fy == args.fy]

    total_dl = total_parsed = total_inserted = total_404 = total_skip_db = 0

    for fname, fy_hint, bid_or_zui in file_list:
        # Dedup check
        if fname in existing:
            total_skip_db += 1
            continue

        dest_path = PDF_DIR / fname

        if not args.skip_download:
            ok = download_from_warp(fname, dest_path)
            if not ok:
                # Try numbered suffix variant (e.g. h25_04_bid2.pdf)
                alt_fname = fname.replace('.pdf', '2.pdf')
                alt_path  = PDF_DIR / alt_fname
                ok = download_from_warp(alt_fname, alt_path)
                if ok:
                    dest_path = alt_path
                    fname     = alt_fname

            if not ok:
                print(f"  [404] {fname}")
                total_404 += 1
                continue
            total_dl += 1
            time.sleep(0.3)
        else:
            # --skip-download: use cached file if available
            if not dest_path.exists():
                alt_path = PDF_DIR / fname.replace('.pdf', '2.pdf')
                if alt_path.exists():
                    dest_path = alt_path
                else:
                    total_404 += 1
                    continue

        # Extract month hint from filename (h25_04 → 04, r01_05 → 05)
        m = re.match(r'[hr]\d{2}_(\d{2})_', fname)
        month_hint = int(m.group(1)) if m else 4

        records = parse_tcab_pdf_heisei(dest_path, bid_or_zui, fy_hint, month_hint)
        total_parsed += len(records)

        if not records:
            print(f"  [WARN] {fname} (FY{fy_hint}): 0件パース失敗")
            continue

        ins, skp = insert_records(conn, records, fname, fy_hint, args.dry_run)
        total_inserted += ins

        amt = sum(r.get('contract_amount', 0) or 0 for r in records if date_to_fy(r.get('contract_date')) == fy_hint)
        print(f"  {fname} (FY{fy_hint}): {len(records)}件パース  {amt/1e8:.2f}億  → inserted={ins}  fy_skip={skp}")

    conn.close()

    print(f"\n=== 完了 ===")
    print(f"  downloaded:  {total_dl}")
    print(f"  parsed:      {total_parsed}")
    print(f"  inserted:    {total_inserted}")
    print(f"  not_found:   {total_404}")
    print(f"  skipped_db:  {total_skip_db}")

    # Final DB summary
    conn = sqlite3.connect(str(DB_PATH))
    print("\n=== DB summary (TCAB source, FY2013-2019) ===")
    for row in conn.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,1)
        FROM contracts WHERE source='tcab' AND fiscal_year BETWEEN 2013 AND 2019
        GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall():
        print(f"  FY{row[0]}: {row[1]}件  {row[2]}億")
    print("\n=== DB全体 ===")
    for row in conn.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,1)
        FROM contracts GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall():
        print(f"  FY{row[0]}: {row[1]}件  {row[2]}億")
    conn.close()


if __name__ == '__main__':
    main()
