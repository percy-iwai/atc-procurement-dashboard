#!/usr/bin/env python3
"""
大阪航空局(WCAB) FY2022 データ補完スクリプト

FY2022（2022年4月〜2023年3月）のWCAB PDFはライブサーバーに存在するが、
published.html には古いファイルは掲載されていないため、直接URLでアクセスする。

既知ファイル一覧（エージェント調査 2026-04-06確認）:
  Apr 2022: kk_20220406, kk_20220427, bk_20220412, bk_20220427, bz_20220406, kz_20220406
  Jul 2022: kk_20220701, kk_20220705, bk_20220701, bk_20220705
  Aug 2022: kk_220809, bk_220809, kz_220809
  Sep 2022: kk_220909, bk_220909, kz_220909, bz_220909
  Oct 2022: kk_221011, bk_221011, kz_221011, bz_221011
  Nov 2022: kk_221111, bk_221111, kz_221111, bz_221111
  Dec 2022: bk_221212, kz_221212, bz_221212
  Jan 2023: kk_230106, kz_230106
  Feb 2023: kk_230201, bk_230201, kz_230201, bz_230201

  May/Jun 2022 + Mar 2023 はライブサーバーになし → Wayback/WARPで別途確認
"""

import re
import time
import sqlite3
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import fitz
except ImportError:
    print("ERROR: PyMuPDF not installed. Run: pip install pymupdf")
    import sys; sys.exit(1)

PROJECT = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR  = PROJECT / 'data/pdfs/atc'
PDF_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
WCAB_BASE = 'https://www.cab.mlit.go.jp/wcab/file/'
REIWA_BASE = 2018

# ============================================================
# Known FY2022 WCAB files (confirmed 200 on live server)
# prefix → (procurement_type, bid_or_zui)
#   kk = 建設工事 競争, kz = 建設工事 随意
#   bk = 物品役務 競争, bz = 物品役務 随意
# ============================================================
WCAB_FY2022_FILES = [
    # Apr 2022
    'kk_20220406.pdf', 'kk_20220427.pdf',
    'bk_20220412.pdf', 'bk_20220427.pdf',
    'bz_20220406.pdf', 'kz_20220406.pdf',
    # Jul 2022
    'kk_20220701.pdf', 'kk_20220705.pdf',
    'bk_20220701.pdf', 'bk_20220705.pdf',
    # Aug 2022
    'kk_220809.pdf', 'bk_220809.pdf', 'kz_220809.pdf',
    # Sep 2022
    'kk_220909.pdf', 'bk_220909.pdf', 'kz_220909.pdf', 'bz_220909.pdf',
    # Oct 2022
    'kk_221011.pdf', 'bk_221011.pdf', 'kz_221011.pdf', 'bz_221011.pdf',
    # Nov 2022
    'kk_221111.pdf', 'bk_221111.pdf', 'kz_221111.pdf', 'bz_221111.pdf',
    # Dec 2022
    'bk_221212.pdf', 'kz_221212.pdf', 'bz_221212.pdf',
    # Jan 2023
    'kk_230106.pdf', 'kz_230106.pdf',
    # Feb 2023
    'kk_230201.pdf', 'bk_230201.pdf', 'kz_230201.pdf', 'bz_230201.pdf',
]

# Additional early FY2023 files not linked from published.html
WCAB_FY2023_EXTRA_FILES = [
    'kk_230406.pdf', 'bk_230406.pdf', 'kz_230406.pdf', 'bz_230406.pdf',
    'kk_230425.pdf', 'bk_230425.pdf', 'kz_230425.pdf', 'bz_230425.pdf',
    'kk_230531.pdf',
]

def get_prefix(fname):
    """Extract 2-char prefix (kk/kz/bk/bz) from filename."""
    return re.match(r'^([a-z]{2})', fname.lower()).group(1)

def prefix_to_type(prefix):
    pt = '建設工事' if prefix in ('kk', 'kz') else '物品役務'
    bz = 'bid' if prefix in ('kk', 'bk') else 'zui'
    return pt, bz

# ============================================================
# Download
# ============================================================
def download_pdf(url, dest_path):
    if dest_path.exists() and dest_path.stat().st_size > 500:
        return True
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        resp = urllib.request.urlopen(req, timeout=20)
        data = resp.read()
        if len(data) < 500:
            return False
        with open(dest_path, 'wb') as f:
            f.write(data)
        return True
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return False
        return False
    except Exception:
        return False

# ============================================================
# PDF parsing (copied from collect_atc_monthly.py)
# ============================================================
RE_REIWA_DATE  = re.compile(r'^令和(\d+)年(\d+)月(\d+)日$')
RE_REIWA_PERIOD = re.compile(r'令和\d+年\d+月\d+日.*[～~]')
RE_CORP_NUM    = re.compile(r'^\d{13}$')
RE_AMOUNT_YEN  = re.compile(r'^[\d,]+円$')
RE_TWOAMOUNTS  = re.compile(r'^([\d,]+)\s+([\d,]+)$')
RE_RATE_PCT    = re.compile(r'^[\d.]+%$')
RE_PAGE_HEADER = re.compile(
    r'公共調達の適正化|契約の相手方の商号|公共工事の名称|物品役務の名称|'
    r'契約担当官|一般競争入札.*指名競争|又は名称及び住所|随意契約によることとした')
RE_DATE_PREFIX = re.compile(r'^(令和\d+年\d+月\d+日)(.+)$')

def is_page_header(text):
    return bool(RE_PAGE_HEADER.search(text)) or len(text) > 80

def _split_date_prefix(text, chars_list, x_min):
    m = RE_DATE_PREFIX.match(text)
    if not m:
        return [(text, x_min, x_min + len(text) * 8)]
    date_part = m.group(1)
    rest_part = m.group(2)
    date_len = len(date_part)
    if len(chars_list) >= date_len:
        split_x = chars_list[date_len][0]
        date_x_max = split_x - 1
    else:
        date_x_max = x_min + date_len * 8
    rest_x_min = date_x_max + 1
    rest_x_max = rest_x_min + len(rest_part) * 8
    return [(date_part, x_min, date_x_max), (rest_part, rest_x_min, rest_x_max)]

def extract_pdf_lines(pdf_path):
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening PDF: {e}")
        return []
    result = []
    for page_num, page in enumerate(doc):
        try:
            xml_str = page.get_text('xml')
            root = ET.fromstring(xml_str)
        except Exception:
            continue
        for line in root.findall('.//line'):
            chars_with_x = []
            for char in line.findall('.//char'):
                c = char.get('c', '')
                if not c:
                    continue
                try:
                    cx = float(char.get('x', '0'))
                    bbox = line.get('bbox', '')
                    parts = bbox.split()
                    if len(parts) >= 4:
                        y0, y1 = float(parts[1]), float(parts[3])
                    else:
                        y0 = y1 = 0.0
                    chars_with_x.append((cx, (y0 + y1) / 2, c))
                except Exception:
                    continue
            if not chars_with_x:
                text = line.get('text', '').strip() if hasattr(line, 'get') else ''
                if not text:
                    continue
                bbox = line.get('bbox', '')
                try:
                    x0, y0, x1, y1 = [float(v) for v in bbox.split()]
                except Exception:
                    continue
                y_center = (y0 + y1) / 2
                result.append({
                    'page': page_num, 'x_min': x0, 'x_max': x1,
                    'y_page': y_center, 'y_global': page_num * 1000 + y_center,
                    'text': text,
                })
                continue
            COL_GAP = 12.0
            segments = []
            seg_chars = [chars_with_x[0]]
            for i in range(1, len(chars_with_x)):
                if chars_with_x[i][0] - chars_with_x[i-1][0] > COL_GAP:
                    segments.append(seg_chars)
                    seg_chars = [chars_with_x[i]]
                else:
                    seg_chars.append(chars_with_x[i])
            segments.append(seg_chars)
            y_center = chars_with_x[0][1]
            for seg in segments:
                seg_text = ''.join(c for _, _, c in seg).strip()
                if not seg_text:
                    continue
                x_min = seg[0][0]
                x_max = seg[-1][0] + 8
                sub_segs = _split_date_prefix(seg_text, seg, x_min)
                for sub_text, sub_x_min, sub_x_max in sub_segs:
                    result.append({
                        'page': page_num, 'x_min': sub_x_min, 'x_max': sub_x_max,
                        'y_page': y_center, 'y_global': page_num * 1000 + y_center,
                        'text': sub_text,
                    })
    doc.close()
    return result

def classify_line(text):
    if RE_REIWA_DATE.match(text): return 'date'
    if RE_REIWA_PERIOD.search(text): return 'period'
    if RE_CORP_NUM.match(text): return 'corp_num'
    if RE_AMOUNT_YEN.match(text): return 'amount_yen'
    if RE_TWOAMOUNTS.match(text.replace(',', '')): return 'two_amounts'
    t_clean = text.replace(',', '').replace('円', '').strip()
    if re.match(r'^\d+$', t_clean) and len(t_clean) >= 4:
        try:
            if float(t_clean) >= 100: return 'amount_plain'
        except: pass
    if RE_RATE_PCT.match(text): return 'rate'
    try:
        v = float(text)
        if 0.0 <= v <= 100.0 and '.' in text: return 'rate'
    except: pass
    if '競争入札' in text or '指名競争' in text: return 'bid_kw'
    if '随意契約' in text and len(text) < 30: return 'bid_kw'
    if '会計法' in text or '規定を適用' in text or '随意契約を締結' in text: return 'basis_kw'
    if is_page_header(text): return 'header'
    return 'other'

def parse_records_from_lines(lines, procurement_type, bid_or_zui):
    data_lines = [ln for ln in lines if ln['y_page'] > 95 and not is_page_header(ln['text'])]
    if not data_lines: return []
    corp_lines = [ln for ln in data_lines if classify_line(ln['text']) == 'corp_num']
    if not corp_lines: return []
    corp_lines_sorted = sorted(corp_lines, key=lambda l: l['y_global'])
    records = []
    for idx, corp_ln in enumerate(corp_lines_sorted):
        y_low = (min(l['y_global'] for l in data_lines) - 1) if idx == 0 \
            else (corp_lines_sorted[idx-1]['y_global'] + corp_ln['y_global']) / 2
        y_high = (max(l['y_global'] for l in data_lines) + 1) if idx == len(corp_lines_sorted)-1 \
            else (corp_ln['y_global'] + corp_lines_sorted[idx+1]['y_global']) / 2
        rec_lines = sorted(
            [ln for ln in data_lines if y_low <= ln['y_global'] <= y_high],
            key=lambda l: (l['x_min'], l['y_global'])
        )
        if not rec_lines: continue
        rec = extract_fields(rec_lines, corp_ln, procurement_type, bid_or_zui)
        if rec: records.append(rec)
    return records

def extract_fields(rec_lines, corp_ln, procurement_type, bid_or_zui):
    corp_x = corp_ln['x_min']
    classified = [(ln, classify_line(ln['text'])) for ln in rec_lines]
    corporate_number = corp_ln['text'].strip()
    contract_name = contracting_officer = contract_date = None
    vendor_name = vendor_address = contract_basis = None
    planned_price = contract_amount = award_rate = None
    bid_method = None
    amounts = []

    text_lines_left = [(ln, t) for ln, t in classified if ln['x_min'] < corp_x - 10 and t == 'other']
    text_lines_right = [(ln, t) for ln, t in classified if ln['x_min'] >= corp_x - 10 and t == 'other']

    for ln, t in classified:
        if t == 'date':
            v = RE_REIWA_DATE.match(ln['text'])
            if v:
                ry, mo, dd = int(v.group(1)), int(v.group(2)), int(v.group(3))
                if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
                    contract_date = f'{REIWA_BASE+ry}{mo:02d}{dd:02d}'
        elif t in ('amount_yen', 'amount_plain'):
            try:
                v = float(ln['text'].replace(',','').replace('円',''))
                if v >= 100: amounts.append((v, ln['x_min']))
            except: pass
        elif t == 'rate':
            try: award_rate = float(ln['text'].replace('%',''))
            except: pass
        elif t == 'bid_kw':
            if '随意' in ln['text']: bid_method = '随意契約'
            else: bid_method = '一般競争入札'
        elif t == 'basis_kw':
            contract_basis = ln['text']
        elif t == 'two_amounts':
            parts = ln['text'].replace(',','').split()
            try:
                amounts.extend([(float(p), ln['x_min']) for p in parts if float(p) >= 100])
            except: pass
        elif t == 'corp_num':
            pass
        elif t == 'other':
            txt = ln['text'].strip()
            if not txt: continue
            if ln['x_min'] < corp_x - 10:
                if contract_name is None:
                    contract_name = txt
                elif contracting_officer is None:
                    contracting_officer = txt
            else:
                if vendor_name is None:
                    vendor_name = txt
                elif vendor_address is None:
                    vendor_address = txt

    # Assign amounts: typically [planned_price, contract_amount] ordered by x
    if amounts:
        amounts_sorted = sorted(amounts, key=lambda x: x[1])
        vals = [a for a, _ in amounts_sorted]
        if len(vals) >= 2:
            planned_price, contract_amount = vals[0], vals[1]
        elif len(vals) == 1:
            contract_amount = vals[0]

    if bid_method is None and contract_basis:
        bid_method = '随意契約'
    if contract_name is None and contract_amount is None:
        return None
    return {
        'contract_name': contract_name,
        'contracting_officer': contracting_officer,
        'contract_date': contract_date,
        'vendor_name': vendor_name,
        'vendor_address': vendor_address,
        'corporate_number': corporate_number,
        'bid_method': bid_method or ('随意契約' if bid_or_zui == 'zui' else '一般競争入札'),
        'contract_basis': contract_basis,
        'planned_price': planned_price,
        'contract_amount': contract_amount,
        'award_rate': award_rate,
        'procurement_type': procurement_type or '物品役務',
    }

def date_to_fy(ds):
    if not ds or len(ds) < 6: return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1

# ============================================================
# DB
# ============================================================
def already_exists(cur, rec, fy):
    """Check if a record is already in DB (by corp_num + contract_date + contract_amount)."""
    corp = rec.get('corporate_number')
    dt   = rec.get('contract_date')
    amt  = rec.get('contract_amount')
    if corp and dt and amt:
        cur.execute("""
            SELECT 1 FROM contracts
            WHERE corporate_number=? AND contract_date=? AND contract_amount=? AND fiscal_year=?
        """, (corp, dt, amt, fy))
        return cur.fetchone() is not None
    return False

def insert_records(conn, records, source_file):
    cur = conn.cursor()
    inserted = skipped_dup = skipped_nodate = 0
    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy is None:
            skipped_nodate += 1
            continue
        if already_exists(cur, rec, fy):
            skipped_dup += 1
            continue
        cur.execute("""
            INSERT INTO contracts (
                fiscal_year, procurement_type, bid_method,
                contract_name, contracting_officer, contract_date,
                vendor_name, vendor_address, corporate_number,
                contract_basis, planned_price, contract_amount, award_rate,
                notes, source_file, source
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            fy, rec.get('procurement_type','物品役務'), rec.get('bid_method',''),
            rec.get('contract_name'), rec.get('contracting_officer'),
            rec.get('contract_date'), rec.get('vendor_name'), rec.get('vendor_address'),
            rec.get('corporate_number'), rec.get('contract_basis'),
            rec.get('planned_price'), rec.get('contract_amount'), rec.get('award_rate'),
            None, source_file, 'wcab',
        ))
        inserted += 1
    conn.commit()
    return inserted, skipped_dup, skipped_nodate

# ============================================================
# Main
# ============================================================
def process_file_list(file_list, label):
    conn = sqlite3.connect(DB_PATH)
    total_ins = total_dup = total_nodate = total_404 = 0
    fy_counts = {}

    for fname in file_list:
        url = WCAB_BASE + fname
        fpath = PDF_DIR / fname
        prefix = get_prefix(fname)
        procurement_type, bid_or_zui = prefix_to_type(prefix)

        ok = download_pdf(url, fpath)
        if not ok:
            print(f"  404/err: {fname}")
            total_404 += 1
            continue

        # Parse PDF
        lines = extract_pdf_lines(fpath)
        pages = {}
        for ln in lines:
            pages.setdefault(ln['page'], []).append(ln)
        recs = []
        for page_num in sorted(pages.keys()):
            page_lines = sorted(pages[page_num], key=lambda l: l['y_global'])
            recs.extend(parse_records_from_lines(page_lines, procurement_type, bid_or_zui))

        ins, dup, nd = insert_records(conn, recs, fname)
        total_ins += ins; total_dup += dup; total_nodate += nd

        # Track FY breakdown
        for rec in recs:
            fy = date_to_fy(rec.get('contract_date'))
            if fy:
                fy_counts[fy] = fy_counts.get(fy, 0) + 1

        status = f"+{ins}件" if ins > 0 else f"dup={dup}"
        print(f"  {fname:<30} recs={len(recs):>3}  {status}")
        time.sleep(0.3)

    conn.close()
    print(f"\n[{label}] 計: +{total_ins}件新規  重複スキップ={total_dup}  日付なし={total_nodate}  404={total_404}")
    if fy_counts:
        for fy in sorted(fy_counts):
            print(f"  FY{fy}: {fy_counts[fy]}件")
    return total_ins

if __name__ == '__main__':
    print("=== WCAB FY2022 補完 ===")
    ins1 = process_file_list(WCAB_FY2022_FILES, "FY2022 files")

    print("\n=== WCAB FY2023 追加分（公表ページ未掲載） ===")
    ins2 = process_file_list(WCAB_FY2023_EXTRA_FILES, "FY2023 extra files")

    # Final summary
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    print("\n=== DB現状（wcab） ===")
    c.execute("SELECT fiscal_year, COUNT(*), SUM(contract_amount)/1e8 FROM contracts WHERE source='wcab' GROUP BY fiscal_year ORDER BY fiscal_year")
    for r in c.fetchall():
        print(f"  FY{r[0]}: {r[1]:>4}件  {(r[2] or 0):.1f}億円")
    conn.close()
