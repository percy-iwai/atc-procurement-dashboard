"""
fix_all_atc_v2.py — ATC調達DB 全件整備スクリプト

作業1: FY2011-2012 データ削除
作業2: ベンダー名寄せ再実行（NFKC正規化・法人番号ベース最頻値・NTTデータ統一・ゴミNULL）
作業3: category / mega_category / area_type / system_name / work_type / organization 全件付与

実行: python fix_all_atc_v2.py
"""

import re
import sys
import sqlite3
import unicodedata
from collections import Counter
from pathlib import Path

sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='utf-8', buffering=1)

DB_PATH = Path("data/db/atc_procurement.db")

# ═══════════════════════════════════════════════════════════════════════════════
# 共通ヘルパー
# ═══════════════════════════════════════════════════════════════════════════════

def nfkc(s: str | None) -> str | None:
    if s is None:
        return None
    s = unicodedata.normalize("NFKC", s).strip()
    return s if s else None


def normalize_vendor_name(raw: str | None) -> str | None:
    """基本正規化（NFKC + （株）→株式会社）"""
    if not raw:
        return None
    s = unicodedata.normalize("NFKC", raw).strip()
    if not s:
        return None
    # （株）・(株) → 株式会社
    s = re.sub(r"[（(]株[)）]", "株式会社", s)
    # （有）→有限会社
    s = re.sub(r"[（(]有[)）]", "有限会社", s)
    # （一財）→一般財団法人 等
    s = re.sub(r"[（(]一財[)）]", "一般財団法人", s)
    s = re.sub(r"[（(]公財[)）]", "公益財団法人", s)
    s = re.sub(r"[（(]一社[)）]", "一般社団法人", s)
    s = re.sub(r"[（(]公社[)）]", "公益社団法人", s)
    return s.strip() or None


# 人名・ゴミ判定
CORPORATE_MARKERS = [
    "株式会社", "有限会社", "合同会社", "合資会社", "一般財団法人", "公益財団法人",
    "一般社団法人", "公益社団法人", "独立行政法人", "国立研究開発法人",
    "協会", "機構", "組合", "公社", "事業団", "連合", "学会", "センター",
    "CENTER", "CORP", "Inc", "Ltd", "Co.", "工業", "電機", "電気", "工務",
    "システム", "サービス", "ソリューション", "コンサルタント", "テクノ",
    "エンジニア", "インフォ", "テック", "ソフト", "ウェア", "通信",
]

JUNK_PATTERNS = [
    "担当官", "支出負担", "契約を締結", "所属する部局",
    "分任支出", "総合評価", "評価委員",
    "予算決算及び会計令", "会計法第", "随意契約理由",
]

PERSON_NAME_OVERRIDES = [
    "甲田\u3000俊博", "甲田 俊博", "甲田俊博",
    "村田\u3000有", "村田 有", "村田有",
    "村田\u3000俊満", "村田 俊満", "村田俊満",
    "伊藤\u3000正", "伊藤 正",
    "小池\u3000慎一郎", "小池 慎一郎",
    "干山\u3000善幸", "干山 善幸",
]

JUNK_PREFIX = ["空港用地に供する"]  # 用地取得契約 = ベンダー名ではない


def is_junk_vendor(name: str | None) -> bool:
    if name is None:
        return False
    s = name.strip()
    if not s:
        return True
    # 13桁数字のみ
    if re.fullmatch(r"\d{13}", s):
        return True
    # ゴミパターン
    for pat in JUNK_PATTERNS:
        if pat in s:
            return True
    # ゴミプレフィックス
    for pat in JUNK_PREFIX:
        if s.startswith(pat):
            return True
    # 人名オーバーライド（全角スペース・半角スペース・スペースなし）
    for pn in PERSON_NAME_OVERRIDES:
        if s.startswith(pn) or pn in s:
            return True
    # スペース（全角or半角）区切りの短い2部分 → 人名
    for sep in ("\u3000", " "):
        if sep in s:
            parts = s.split(sep)
            if len(parts) == 2:
                p1, p2 = parts[0].strip(), parts[1].strip()
                # 漢字2〜4文字 + 漢字1〜4文字 かつ法人マーカーなし
                if (1 <= len(p1) <= 4 and 1 <= len(p2) <= 4
                        and re.fullmatch(r"[\u4e00-\u9fff\u30a0-\u30ff]+", p1)
                        and re.fullmatch(r"[\u4e00-\u9fff\u30a0-\u30ff]+", p2)
                        and not any(m in s for m in CORPORATE_MARKERS)):
                    return True
    # 住所末尾
    if re.search(r"[丁目番地号]$", s) and len(s) < 25:
        return True
    # 数字・記号のみ
    if re.fullmatch(r"[\d\s,，\-－]+", s):
        return True
    return False


# ═══════════════════════════════════════════════════════════════════════════════
# 作業1: FY2011-2012 削除
# ═══════════════════════════════════════════════════════════════════════════════

def delete_fy2011_2012(cur: sqlite3.Cursor) -> dict:
    stats = {}
    cur.execute("SELECT COUNT(*) FROM contracts WHERE fiscal_year IN (2011,2012)")
    stats["contracts_before"] = cur.fetchone()[0]
    cur.execute("DELETE FROM contracts WHERE fiscal_year IN (2011,2012)")
    stats["contracts_deleted"] = cur.rowcount

    cur.execute("SELECT COUNT(*) FROM pas_airport_contracts WHERE fiscal_year IN (2011,2012)")
    stats["pas_before"] = cur.fetchone()[0]
    cur.execute("DELETE FROM pas_airport_contracts WHERE fiscal_year IN (2011,2012)")
    stats["pas_deleted"] = cur.rowcount
    return stats


# ═══════════════════════════════════════════════════════════════════════════════
# 作業2: ベンダー名寄せ
# ═══════════════════════════════════════════════════════════════════════════════

# NTTデータ統一ルール（法人番号 → 正式名称）
# 9010601021385: 株式会社NTTデータ (旧社名)
# 6010601062093: 株式会社NTTデータ (旧社名, 別番号)
# どちらも正式名称は「株式会社エヌ・ティ・ティ・データ」に統一
NTT_DATA_CORP_NUMS = {"9010601021385", "6010601062093"}
NTT_DATA_CANONICAL = "株式会社エヌ・ティ・ティ・データ"


def build_vendor_normalization(cur: sqlite3.Cursor) -> dict[str, str]:
    """法人番号 → 正規化ベンダー名 のマッピングを構築"""
    # 全レコードの (corp_num, vendor_name) を取得
    cur.execute("""
        SELECT corporate_number, vendor_name
        FROM contracts
        WHERE corporate_number IS NOT NULL AND corporate_number != ''
          AND vendor_name IS NOT NULL AND vendor_name != ''
    """)
    rows = cur.fetchall()

    # corp_num ごとに正規化後の最頻値を計算
    corp_counter: dict[str, Counter] = {}
    for corp, raw_name in rows:
        corp = corp.strip()
        if not corp:
            continue
        norm = normalize_vendor_name(raw_name)
        if norm and not is_junk_vendor(norm):
            corp_counter.setdefault(corp, Counter())[norm] += 1

    # NTTデータ上書き
    for cn in NTT_DATA_CORP_NUMS:
        if cn in corp_counter:
            corp_counter[cn] = Counter({NTT_DATA_CANONICAL: 9999})

    # 最頻値を選択
    corp_to_best: dict[str, str] = {
        corp: counts.most_common(1)[0][0]
        for corp, counts in corp_counter.items()
        if counts
    }
    return corp_to_best


def apply_vendor_normalization(cur: sqlite3.Cursor) -> int:
    """contracts テーブルの vendor_normalized を全件更新"""
    corp_to_best = build_vendor_normalization(cur)

    cur.execute("SELECT id, corporate_number, vendor_name FROM contracts")
    rows = cur.fetchall()
    updates = []
    for row_id, corp, raw_name in rows:
        norm_from_corp = None
        if corp and corp.strip() in corp_to_best:
            norm_from_corp = corp_to_best[corp.strip()]

        if norm_from_corp and not is_junk_vendor(norm_from_corp):
            normalized = norm_from_corp
        else:
            candidate = normalize_vendor_name(raw_name)
            normalized = None if is_junk_vendor(candidate) else candidate

        updates.append((normalized, row_id))

    cur.executemany("UPDATE contracts SET vendor_normalized=? WHERE id=?", updates)
    return len(updates)


def apply_pas_vendor_normalization(cur: sqlite3.Cursor) -> int:
    """pas_airport_contracts: vendor_name → vendor_normalized（NFKC正規化のみ）"""
    cur.execute("SELECT id, vendor_name FROM pas_airport_contracts")
    rows = cur.fetchall()
    updates = []
    for row_id, raw_name in rows:
        candidate = normalize_vendor_name(raw_name)
        normalized = None if is_junk_vendor(candidate) else candidate
        updates.append((normalized, row_id))
    cur.executemany(
        "UPDATE pas_airport_contracts SET vendor_normalized=? WHERE id=?", updates
    )
    return len(updates)


# ═══════════════════════════════════════════════════════════════════════════════
# 作業3: category / mega_category / area_type / system_name / work_type / organization
# ═══════════════════════════════════════════════════════════════════════════════

# ── category キーワードルール（優先度順）───────────────────────────────────────
CATEGORY_RULES = [
    ("管制処理システム", [
        "TEPS", "TAPS", "TOPS", "TEAM", "FACE", "HARP", "ICAP", "ARTS", "RDPS",
        "FDPS", "VSCS", "ADCU", "CCX", "ATMS", "SWIM",
        "管制処理", "管制支援処理", "管制情報処理", "航空路管制処理",
        "洋上管制処理", "空港管制処理", "航空交通管理処理", "飛行情報管理処理",
        "航空交通管理システム", "管制処理システム",
    ]),
    ("航法援助施設", [
        "ILS", "VOR/DME", "VOR ", "DME", "ASR", "ARSR", "ARTR", "MLAT", "SSR",
        "SBAS", "GBAS", "NDB", "DVOR", "CVOR", "LOC ", "G/S",
        "レーダー", "無線局", "航法援助", "進入管制レーダー", "マルチラテレーション",
        "計器着陸", "全方向", "測距", "滑走路視程", "RVR", "PEMS", "ATIS",
        "FVDライセンス", "FVD用航法", "衛星航法予測", "GPM-2", "GPM－2",
    ]),
    ("管制通信設備", [
        "CPDLC", "ADS-B", "ADSB", "データリンク", "通信制御装置", "CCS-", "CCS－",
        "DLCS", "音声通信", "管制通信", "ATN", "ACARS",
        "通信設備", "通信装置", "通信制御", "回線", "無線電話装置", "無線電信",
    ]),
    ("情報ネットワーク", ["ネットワーク"]),
    ("訓練システム", ["訓練", "シミュレーター", "シミュレータ"]),
    ("IT・情報システム", [
        "クラウド", "サイバー", "情報システム", "基盤システム", "情報処理システム",
        "CRMS", "ADEX",
    ]),
    ("飛行検査業務", ["飛行検査"]),
    ("ドローン・UAV", ["ドローン", "UAV", "UAS", "無人航空機"]),
    ("空港灯火設備", [
        "灯火", "PAPI", "VASIS", "ALSF", "MALSR", "REILS", "航空灯",
        "照明器具", "誘導灯", "滑走路灯", "標識灯",
    ]),
    ("電源・非常用設備", [
        "発電設備", "発電機", "UPS", "CVCF", "無停電電源", "受配電", "電源設備",
        "非常電源", "蓄電池", "変圧器", "変電設備",
    ]),
    ("装置製造", ["の製造", "装置製造", "機器製造", "装置の製作", "装置一式"]),
    ("新築工事", ["新築"]),
    ("維持修繕工事", ["維持修繕", "改修工事", "修繕工事"]),
    ("設備工事", [
        "電気設備保全", "機械設備保全", "設備工事", "設備改修",
        "空調設備", "エレベーター", "給排水", "消火設備",
    ]),
    ("土木・建築", [
        "建築工事", "局舎", "護岸", "舗装工事", "建設工事", "改良工事",
        "改築工事", "鉄塔工事", "土木工事", "造成工事", "管制塔",
    ]),
    ("土木・工事", ["工事"]),  # 上記に該当しない「工事」
    ("消防・警備業務", ["消防", "警備"]),
    ("医療・健康管理", ["医療", "健康", "定期検診", "診断"]),
    ("燃料・油脂", ["燃料", "油脂", "軽油"]),
    ("用地・賃借", ["賃借", "賃貸", "用地", "借料"]),
    ("設計業務", ["設計", "コンサルタント"]),
    ("調査・設計・計画", ["調査", "計画策定", "実施計画", "可能性調査"]),
    ("保守・調整作業", ["調整作業", "調整その他", "整備作業", "整備その他"]),
    ("維持管理委託", [
        "保全業務", "保守", "維持管理", "点検整備", "点検作業", "清掃",
        "保全作業", "管理業務", "保守点検",
    ]),
    ("業務委託", ["業務"]),
    ("物品購入", ["購入", "調達", "部品", "消耗品"]),
    ("その他", [""]),  # デフォルト
]


def classify_category(contract_name: str | None) -> str:
    if not contract_name:
        return "その他"
    n = unicodedata.normalize("NFKC", contract_name).upper()
    for cat, keywords in CATEGORY_RULES:
        if cat == "その他":
            return "その他"
        for kw in keywords:
            if kw.upper() in n or kw in contract_name:
                return cat
    return "その他"


# ── area_type ─────────────────────────────────────────────────────────────────
OCEANIC_KEYWORDS = [
    "衛星航法予測", "SBAS", "GBAS", "CPDLC", "洋上管制", "TOPS", "衛星通信",
    "陸域CPDLC", "衛星電話", "GPM-2", "GPM－2", "衛星機器",
    "準天頂衛星", "LPV",
]
ENROUTE_KEYWORDS = [
    "航空路管制", "TEPS", "航空路", "航空交通管理", "TEAM", "ARTS", "RDPS",
    "FACE", "飛行情報管理", "HARP", "ICAP", "ATMS",
]
AIRPORT_KEYWORDS = ["空港", "PAPI", "灯火", "滑走路", "エプロン", "TAPS"]


def classify_area_type(contracting_officer: str | None, contract_name: str | None,
                       source: str | None) -> str:
    co = contracting_officer or ""
    cn = contract_name or ""
    cn_norm = unicodedata.normalize("NFKC", cn).upper()

    # 洋上系（衛星航法・SBAS等）
    for kw in OCEANIC_KEYWORDS:
        if kw.upper() in cn_norm or kw in cn:
            return "洋上系"

    # 航空路系（管制部 or en-route keywords）
    if "航空交通管制部" in co:
        return "航空路系"
    for kw in ENROUTE_KEYWORDS:
        if kw.upper() in cn_norm or kw in cn:
            return "航空路系"

    # 空港系（WCAB、空港事務所、東京航空局等）
    if source == "wcab":
        return "空港系"
    if "空港事務所" in co or "東京航空局" in co or "大阪航空局" in co:
        return "空港系"
    for kw in AIRPORT_KEYWORDS:
        if kw in cn:
            return "空港系"

    return "不明"


# ── system_name ───────────────────────────────────────────────────────────────
KNOWN_SYSTEMS = [
    "TEPS", "TAPS", "TOPS", "TEAM", "FACE", "HARP", "ICAP", "ARTS", "RDPS",
    "CCX", "CCS", "FDPS", "VSCS", "ADCU", "ATMS", "SWIM",
    "ILS", "VOR", "DME", "ASR", "ARSR", "ARTR", "MLAT", "SSR",
    "SBAS", "GBAS", "NDB", "DVOR", "CVOR", "RVR",
    "CPDLC", "DLCS", "ACARS", "ATN", "ADS-B",
    "PAPI", "VASIS", "UPS", "CVCF",
    "CRMS", "ADEX",
]

# パターン例: （TEPS）、(TAPS)、「TEAM」
SYSTEM_PAREN_RE = re.compile(
    r"[（(「]([A-Z]{2,6}(?:-\d+[A-Z]?)?)[)）」]"
)


def classify_system_name(contract_name: str | None) -> str | None:
    if not contract_name:
        return None
    n_upper = unicodedata.normalize("NFKC", contract_name).upper()
    # 括弧内のアクロニム（最初にマッチしたものを採用）
    for m in SYSTEM_PAREN_RE.finditer(n_upper):
        acr = m.group(1)
        if acr in KNOWN_SYSTEMS:
            return acr
    # 括弧なしの先頭一致
    for sys_name in KNOWN_SYSTEMS:
        if sys_name in n_upper:
            return sys_name
    return None


# ── organization ───────────────────────────────────────────────────────────────
def classify_organization(contracting_officer: str | None, source: str | None) -> str | None:
    if not contracting_officer:
        if source == "tcab":
            return "東京航空局"
        if source == "wcab":
            return "大阪航空局"
        return None
    co = contracting_officer

    if "東京航空交通管制部" in co:
        return "ATMC東京（東京ACC）"
    if "神戸航空交通管制部" in co:
        return "ATMC神戸（神戸ACC）"
    if "福岡航空交通管制部" in co:
        return "ATMC福岡（福岡ACC）"
    if "札幌航空交通管制部" in co:
        return "ATMC札幌（札幌ACC）"
    if "那覇航空交通管制部" in co:
        return "ATMC那覇（那覇ACC）"
    if "航空保安大学校" in co:
        return "航空保安大学校"
    if "東京航空局" in co:
        return "東京航空局"
    if "大阪航空局" in co:
        return "大阪航空局"
    if "航空局" in co or "霞が関" in co or "九段南" in co:
        return "航空局本局"

    # 空港事務所
    airport_offices = [
        "新千歳空港事務所", "仙台空港事務所", "成田空港事務所", "東京空港事務所",
        "新潟空港事務所", "中部空港事務所", "関西空港事務所", "大阪空港事務所",
        "福岡空港事務所", "熊本空港事務所", "長崎空港事務所", "那覇空港事務所",
        "鹿児島空港事務所",
    ]
    for ao in airport_offices:
        if ao in co:
            return f"空港事務所（{ao}）"

    return "その他/不明"


# ── mega_category（update_mega_category.py のロジックを移植）──────────────────

CATEGORY_MEGA_MAP = {
    "管制処理システム":    "管制システム",
    "情報ネットワーク":    "管制システム",
    "訓練システム":        "管制システム",
    "IT・情報システム":    "管制システム",
    "航法援助施設":        "無線・レーダー",
    "管制通信設備":        "通信設備",
    "空港灯火設備":        "灯火・標識",
    "電源・非常用設備":    "電源・電気設備",
    "新築工事":            "土木・建築",
    "維持修繕工事":        "土木・建築",
    "土木・工事":          "土木・建築",
    "土木・建築":          "土木・建築",
    "設備工事":            "電源・電気設備",
    "飛行検査業務":        "航空機・検査",
    "ドローン・UAV":       "航空機・検査",
    "物品購入":            "一般物品・庁費",
    "用地・賃借":          "一般物品・庁費",
    "消防・警備業務":      "一般物品・庁費",
    "医療・健康管理":      "一般物品・庁費",
    "燃料・油脂":          "一般物品・庁費",
    "業務委託":            "一般物品・庁費",
    "装置製造":            "通信設備",
    "設計業務":            "一般物品・庁費",
    "調査・設計・計画":    "一般物品・庁費",
    "調査・検査":          "一般物品・庁費",
    "保守・調整作業":      "役務・保守系",
    "維持管理委託":        "役務・保守系",
    "その他":              "一般物品・庁費",
    "不明":                "一般物品・庁費",
}

MEGA_KEYWORD_RULES = [
    ("管制システム",     ["TEPS", "TAPS", "TOPS", "TEAM", "FACE", "HARP", "ICAP",
                          "CCX", "CCS", "ADCU", "RDPS", "ARTS", "ATMS",
                          "管制処理", "航空交通管理", "情報処理システム",
                          "管制情報", "SWIM", "FDPS", "VSCS"]),
    ("無線・レーダー",   ["ILS", "VOR", "DME", "ASR", "ARSR", "ARTR", "MLAT", "SSR",
                          "SBAS", "GBAS", "NDB", "RVR", "DVOR", "CVOR", "LOC",
                          "GLIDEPATH", "G/S", "ATC RADAR",
                          "レーダー", "無線局", "無線電話", "無線電信",
                          "航法援助", "進入管制レーダー"]),
    ("通信設備",         ["CPDLC", "ADS-B", "ADSB", "VHF", "HF ",
                          "データリンク", "データ通信", "通信制御", "通信網",
                          "音声通信", "管制通信", "ATN", "ACARS",
                          "通信設備", "通信装置"]),
    ("灯火・標識",       ["PAPI", "VASIS", "灯火", "進入灯", "誘導灯",
                          "滑走路灯", "航空灯", "灯器", "照明設備", "標識灯",
                          "ALSF", "MALSR", "REILS"]),
    ("電源・電気設備",   ["UPS", "CVCF", "受配電", "変電", "変圧",
                          "発電機", "非常電源", "蓄電池", "無停電",
                          "空気調和", "空調", "冷暖房", "熱源",
                          "電気設備", "電源設備", "機械設備保全",
                          "エレベーター", "給排水", "消火設備", "防火"]),
    ("土木・建築",       ["滑走路", "誘導路", "エプロン", "地盤", "舗装",
                          "建物", "建築", "鉄塔", "管制塔", "局舎建設", "局舎新築",
                          "護岸", "土工", "造成", "改築", "新築", "増築",
                          "橋梁", "道路", "擁壁"]),
    ("航空機・検査",     ["飛行検査", "検査機", "ドローン", "UAV", "UAS",
                          "無人航空機", "無人機", "飛行機器"]),
    ("役務・保守系",     ["保守", "維持管理", "点検", "整備", "清掃", "警備",
                          "管理業務", "保全業務", "保全作業"]),
    ("一般物品・庁費",   ["消火薬剤", "消防車", "除雪", "除草", "草刈",
                          "清掃", "警備", "防除", "駆除",
                          "賃借", "賃貸", "借料",
                          "事務用", "消耗品", "燃料", "車両",
                          "研修", "訓練委託", "調査研究",
                          "広報", "印刷", "翻訳"]),
]


def classify_mega_category(category: str | None, contract_name: str | None) -> str:
    if category and category in CATEGORY_MEGA_MAP:
        return CATEGORY_MEGA_MAP[category]

    name = contract_name or ""
    hw = unicodedata.normalize("NFKC", name).upper()

    if category == "設備工事":
        for kw in ["空調", "冷暖房", "空気調和", "受配電", "電気設備",
                   "エレベーター", "給排水", "消火", "機械設備"]:
            if kw in name:
                return "電源・電気設備"
        return "土木・建築"

    for mega, keywords in MEGA_KEYWORD_RULES:
        for kw in keywords:
            if kw.upper() in hw or kw in name:
                return mega

    return "一般物品・庁費"


# ── work_type ─────────────────────────────────────────────────────────────────
WORK_TYPE_RULES = [
    ("設計・調査", ["設計", "調査", "検討", "コンサルタント", "コンサル",
                    "計画策定", "基本計画", "実施計画", "可能性調査", "診断"]),
    ("製造・納入", ["の製造", "の製作", "の納入", "の購入", "製造据付",
                    "機器製造", "装置製造", "整備品購入"]),
    ("工事・設置", ["工事", "設置工事", "新設", "改修", "撤去", "移設",
                    "据付", "取替", "更新工事", "施工"]),
    ("保守・運用", ["保守", "点検", "整備", "定期点検", "予防保全",
                    "運用支援", "運用管理", "技術管理", "監視業務",
                    "調整作業", "作業", "管理業務", "保全業務",
                    "請負"]),
]


def classify_work_type(contract_name: str | None) -> str:
    name = contract_name or ""
    for wt, keywords in WORK_TYPE_RULES:
        for kw in keywords:
            if kw in name:
                return wt
    return "その他"


# ═══════════════════════════════════════════════════════════════════════════════
# タグ付け適用
# ═══════════════════════════════════════════════════════════════════════════════

def apply_tags_contracts(cur: sqlite3.Cursor) -> int:
    cur.execute("""
        SELECT id, contract_name, contracting_officer, source, organization
        FROM contracts
    """)
    rows = cur.fetchall()
    updates = []
    for row_id, cname, cofficer, source, org_current in rows:
        cat    = classify_category(cname)
        mega   = classify_mega_category(cat, cname)
        area   = classify_area_type(cofficer, cname, source)
        sname  = classify_system_name(cname)
        wt     = classify_work_type(cname)
        org    = classify_organization(cofficer, source)
        updates.append((cat, mega, area, sname, wt, org, row_id))

    cur.executemany("""
        UPDATE contracts
        SET category=?, mega_category=?, area_type=?, system_name=?, work_type=?, organization=?
        WHERE id=?
    """, updates)
    return len(updates)


def apply_tags_pas(cur: sqlite3.Cursor) -> int:
    cur.execute("""
        SELECT id, contract_name, category
        FROM pas_airport_contracts
    """)
    rows = cur.fetchall()
    updates = []
    for row_id, cname, cat_current in rows:
        cat  = classify_category(cname) if not cat_current else cat_current
        mega = classify_mega_category(cat, cname)
        updates.append((cat, mega, row_id))

    cur.executemany("""
        UPDATE pas_airport_contracts
        SET category=?, mega_category=?
        WHERE id=?
    """, updates)
    return len(updates)


# ═══════════════════════════════════════════════════════════════════════════════
# カラム追加
# ═══════════════════════════════════════════════════════════════════════════════

def ensure_columns(cur: sqlite3.Cursor):
    for table, col, col_type in [
        ("contracts", "vendor_normalized", "TEXT"),
        ("contracts", "mega_category",     "TEXT"),
        ("contracts", "work_type",         "TEXT"),
        ("contracts", "category",          "TEXT"),
        ("contracts", "area_type",         "TEXT"),
        ("contracts", "system_name",       "TEXT"),
        ("contracts", "organization",      "TEXT"),
        ("pas_airport_contracts", "vendor_normalized", "TEXT"),
        ("pas_airport_contracts", "mega_category",     "TEXT"),
        ("pas_airport_contracts", "category",          "TEXT"),
    ]:
        cur.execute(f"PRAGMA table_info({table})")
        existing = {r[1] for r in cur.fetchall()}
        if col not in existing:
            cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {col_type}")
            print(f"  → {table}.{col} カラム追加")


# ═══════════════════════════════════════════════════════════════════════════════
# サマリーレポート
# ═══════════════════════════════════════════════════════════════════════════════

def report(cur: sqlite3.Cursor) -> str:
    lines = []

    lines.append("\n══════════════════════════════════════════════════════")
    lines.append(" 全FY サマリー（contracts）")
    lines.append("══════════════════════════════════════════════════════")
    for r in cur.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(contract_amount)/1e8,1)
        FROM contracts GROUP BY fiscal_year ORDER BY fiscal_year
    """):
        lines.append(f"  FY{r[0]}: {r[1]:6d}件  {(r[2] or 0):8.1f}億円")

    lines.append("\n══════════════════════════════════════════════════════")
    lines.append(" 全FY サマリー（pas_airport_contracts）")
    lines.append("══════════════════════════════════════════════════════")
    for r in cur.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(award_amount)/1e8,1)
        FROM pas_airport_contracts GROUP BY fiscal_year ORDER BY fiscal_year
    """):
        lines.append(f"  FY{r[0]}: {r[1]:6d}件  {(r[2] or 0):8.1f}億円（落札額）")

    lines.append("\n══════════════════════════════════════════════════════")
    lines.append(" ベンダー上位20社（contracts、vendor_normalized別）")
    lines.append("══════════════════════════════════════════════════════")
    for i, r in enumerate(cur.execute("""
        SELECT vendor_normalized, COUNT(*) AS cnt,
               ROUND(SUM(contract_amount)/1e8,1) AS oku
        FROM contracts
        WHERE vendor_normalized IS NOT NULL AND contract_amount IS NOT NULL
        GROUP BY vendor_normalized
        ORDER BY SUM(contract_amount) DESC LIMIT 20
    """), 1):
        vn = (r[0] or "")[:42]
        lines.append(f"  {i:2d}. {vn:<42s} {r[1]:5d}件  {(r[2] or 0):8.1f}億円")

    lines.append("\n══════════════════════════════════════════════════════")
    lines.append(" mega_category 別（contracts）")
    lines.append("══════════════════════════════════════════════════════")
    for r in cur.execute("""
        SELECT mega_category, COUNT(*) AS cnt,
               ROUND(SUM(COALESCE(contract_amount,0))/1e8,1) AS oku
        FROM contracts GROUP BY mega_category ORDER BY oku DESC
    """):
        lines.append(f"  {(r[0] or '未分類'):<20s}: {r[1]:6d}件  {(r[2] or 0):8.1f}億円")

    lines.append("\n══════════════════════════════════════════════════════")
    lines.append(" mega_category 別（pas_airport_contracts）")
    lines.append("══════════════════════════════════════════════════════")
    for r in cur.execute("""
        SELECT mega_category, COUNT(*) AS cnt,
               ROUND(SUM(COALESCE(award_amount,0))/1e8,1) AS oku
        FROM pas_airport_contracts GROUP BY mega_category ORDER BY oku DESC
    """):
        lines.append(f"  {(r[0] or '未分類'):<20s}: {r[1]:6d}件  {(r[2] or 0):8.1f}億円")

    lines.append("\n══════════════════════════════════════════════════════")
    lines.append(" vendor_normalized 統計")
    lines.append("══════════════════════════════════════════════════════")
    c_ok = cur.execute("SELECT COUNT(*) FROM contracts WHERE vendor_normalized IS NOT NULL").fetchone()[0]
    c_null = cur.execute("SELECT COUNT(*) FROM contracts WHERE vendor_normalized IS NULL AND vendor_name IS NOT NULL").fetchone()[0]
    c_uniq_raw = cur.execute("SELECT COUNT(DISTINCT vendor_name) FROM contracts WHERE vendor_name IS NOT NULL").fetchone()[0]
    c_uniq = cur.execute("SELECT COUNT(DISTINCT vendor_normalized) FROM contracts WHERE vendor_normalized IS NOT NULL").fetchone()[0]
    lines.append(f"  contracts: {c_ok}件 正規化 / {c_null}件 NULL（ゴミ）")
    lines.append(f"  vendor_nameユニーク: {c_uniq_raw} → vendor_normalized: {c_uniq}（-{c_uniq_raw-c_uniq}統合）")

    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# メイン
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    print(f"DB: {DB_PATH}")
    con = sqlite3.connect(str(DB_PATH))
    con.text_factory = lambda b: b.decode("utf-8", errors="replace")
    cur = con.cursor()

    print("\n[0] カラム追加チェック")
    ensure_columns(cur)
    con.commit()

    print("\n[1] FY2011-2012 削除")
    st = delete_fy2011_2012(cur)
    con.commit()
    print(f"  contracts: {st['contracts_deleted']}件削除 ({st['contracts_before']}件→削除後)")
    print(f"  pas_airport_contracts: {st['pas_deleted']}件削除 ({st['pas_before']}件→削除後)")

    print("\n[2] vendor_normalized 全件更新")
    n = apply_vendor_normalization(cur)
    print(f"  contracts: {n}件")
    n = apply_pas_vendor_normalization(cur)
    print(f"  pas_airport_contracts: {n}件")
    con.commit()

    print("\n[3] category / mega_category / area_type / system_name / work_type / organization 全件付与")
    n = apply_tags_contracts(cur)
    print(f"  contracts: {n}件")
    n = apply_tags_pas(cur)
    print(f"  pas_airport_contracts: {n}件")
    con.commit()

    print("\n[4] レポート")
    result = report(cur)
    print(result)

    # ファイル出力
    out_path = Path("data/output/vendor_top20_final.txt")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(result, encoding="utf-8")
    print(f"\n出力: {out_path}")

    con.close()
    print("\n完了")


if __name__ == "__main__":
    main()
