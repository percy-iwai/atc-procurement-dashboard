"""
国土交通省航空局 調達データ → atc_procurement.db 構築スクリプト

シート構成:
  物品役務調達（競争入札）
  物品役務調達（随意契約）
  公共工事調達（競争入札）
  公共工事調達（随意契約）

ヘッダー行: row 0
合計行:     row 1  ← スキップ
データ行:   row 2〜

日付: datetime 型 or Excel シリアル値（工事系に多い）
"""

import sqlite3
import os
import re
import datetime
import openpyxl
from openpyxl.utils.datetime import from_excel

DB_PATH = "C:/Users/Percy Iwai/Documents/JAXA_procurement/data/db/atc_procurement.db"
RAW_DIR = "C:/Users/Percy Iwai/Documents/JAXA_procurement/data/raw/atc"

FILES = {
    2022: "fy2022.xlsx",
    2023: "fy2023.xlsx",
    2024: "fy2024.xlsx",
    2025: "fy2025.xlsx",
}

# シート名 → (procurement_type, bid_method)
SHEET_MAP = {
    "物品役務調達（競争入札）": ("物品役務", "一般競争入札"),
    "物品役務調達（随意契約）": ("物品役務", "随意契約"),
    "公共工事調達（競争入札）": ("建設工事", "一般競争入札"),
    "公共工事調達（随意契約）": ("建設工事", "随意契約"),
}

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS contracts (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    fiscal_year         INTEGER NOT NULL,
    procurement_type    TEXT NOT NULL,   -- 物品役務 / 建設工事
    bid_method          TEXT NOT NULL,   -- 一般競争入札 / 随意契約
    contract_name       TEXT,
    contracting_officer TEXT,
    contract_date       TEXT,            -- YYYYMMDD
    vendor_name         TEXT,
    vendor_address      TEXT,
    corporate_number    TEXT,
    contract_basis      TEXT,            -- 随意契約根拠 or 競争種別
    planned_price       REAL,
    contract_amount     REAL,
    award_rate          REAL,
    notes               TEXT,
    reemployed_officers TEXT,            -- 随意契約シートのみ
    source_file         TEXT
)
"""

CREATE_INDEX = """
CREATE INDEX IF NOT EXISTS idx_fy ON contracts(fiscal_year);
CREATE INDEX IF NOT EXISTS idx_type ON contracts(procurement_type, bid_method);
CREATE INDEX IF NOT EXISTS idx_name ON contracts(contract_name);
"""


# ---- 日付正規化 ----

def normalize_date(val) -> str | None:
    """Excel セル値 → YYYYMMDD 文字列"""
    if val is None:
        return None
    # datetime / date オブジェクト
    if isinstance(val, (datetime.datetime, datetime.date)):
        return val.strftime("%Y%m%d")
    # Excel シリアル値（数値）
    if isinstance(val, (int, float)):
        try:
            dt = from_excel(int(val))
            return dt.strftime("%Y%m%d")
        except Exception:
            return None
    s = str(val).strip()
    if not s:
        return None
    # YYYY-MM-DD or YYYY/MM/DD
    m = re.match(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        return f"{m.group(1)}{int(m.group(2)):02d}{int(m.group(3)):02d}"
    # 令和短縮形 N.M.D or RN.M.D
    m = re.match(r"^[Rr]?(\d{1,2})\.(\d{1,2})\.(\d{1,2})$", s)
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f"{2018 + ry}{mo:02d}{dd:02d}"
    return None


def date_to_fy(ds: str) -> int | None:
    """YYYYMMDD → 会計年度"""
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


# ---- 金額正規化 ----

def normalize_amount(val) -> float | None:
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val) if val != 0 else None
    s = str(val).strip().replace(",", "").replace("円", "")
    if not s or s in ("-", "－", "―"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


# ---- ベンダー名・住所の分離 ----

def split_vendor(cell_val) -> tuple[str, str]:
    """「法人名\n住所」形式を分割。改行がなければ全体を名称として返す"""
    if cell_val is None:
        return ("", "")
    s = str(cell_val).strip()
    if "\n" in s:
        parts = s.split("\n", 1)
        return (parts[0].strip(), parts[1].strip())
    return (s, "")


# ---- ヘッダー → 列インデックスマップ ----

HEADER_KEYWORDS = {
    "contract_name":        ["名称及び数量", "公共工事の名称"],
    "contracting_officer":  ["契約担当官", "氏名並びにその所属"],
    "contract_date":        ["締結した日", "契約日"],
    "vendor":               ["相手方の称号", "相手方の氏名"],
    "corporate_number":     ["法人番号"],
    "contract_basis":       ["随意契約の根拠", "競争入札", "競争種別", "一般競争"],
    "planned_price":        ["予定価格"],
    "contract_amount":      ["契約金額"],
    "award_rate":           ["落札率"],
    "notes":                ["備考"],
    "reemployed_officers":  ["再就職"],
}

def build_col_map(headers: list) -> dict:
    col_map = {}
    for idx, h in enumerate(headers):
        if h is None:
            continue
        h_str = str(h)
        for field, keywords in HEADER_KEYWORDS.items():
            if field not in col_map and any(kw in h_str for kw in keywords):
                col_map[field] = idx
    return col_map


# ---- シートパース ----

def parse_sheet(ws, fiscal_year_hint: int, procurement_type: str, bid_method: str, source_file: str) -> list[dict]:
    rows = list(ws.iter_rows(values_only=True))
    if len(rows) < 3:
        return []

    headers = [str(c) if c is not None else None for c in rows[0]]
    col_map = build_col_map(headers)

    if "contract_name" not in col_map or "contract_amount" not in col_map:
        print(f"  [WARN] 列マッピング失敗: {source_file} / {ws.title}")
        print(f"  ヘッダー: {headers[:12]}")
        return []

    records = []
    for row in rows[2:]:  # row[1] は合計行 → スキップ
        def cell(field):
            idx = col_map.get(field)
            return row[idx] if idx is not None and idx < len(row) else None

        contract_name = str(cell("contract_name") or "").strip()
        if not contract_name or contract_name in ("None", "合計", "小計"):
            continue

        contract_date_raw = normalize_date(cell("contract_date"))
        vendor_raw = cell("vendor")
        vendor_name, vendor_address = split_vendor(vendor_raw)

        contracting_officer = str(cell("contracting_officer") or "").strip()
        corporate_number = str(cell("corporate_number") or "").strip()
        contract_basis = str(cell("contract_basis") or "").strip()
        planned_price = normalize_amount(cell("planned_price"))
        contract_amount = normalize_amount(cell("contract_amount"))
        award_rate_raw = cell("award_rate")
        award_rate = normalize_amount(award_rate_raw)
        notes = str(cell("notes") or "").strip() or None
        reemployed = str(cell("reemployed_officers") or "").strip() or None

        # 会計年度: 契約日から算出、フォールバックでファイルのFYを使用
        if contract_date_raw:
            fy = date_to_fy(contract_date_raw)
            if fy is None:
                fy = fiscal_year_hint
        else:
            fy = fiscal_year_hint

        records.append({
            "fiscal_year":         fy,
            "procurement_type":    procurement_type,
            "bid_method":          bid_method,
            "contract_name":       contract_name or None,
            "contracting_officer": contracting_officer or None,
            "contract_date":       contract_date_raw,
            "vendor_name":         vendor_name or None,
            "vendor_address":      vendor_address or None,
            "corporate_number":    corporate_number or None,
            "contract_basis":      contract_basis or None,
            "planned_price":       planned_price,
            "contract_amount":     contract_amount,
            "award_rate":          award_rate,
            "notes":               notes,
            "reemployed_officers": reemployed,
            "source_file":         source_file,
        })

    return records


# ---- メイン ----

def main():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print(f"既存DB削除: {DB_PATH}")

    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.executescript(CREATE_TABLE)
    for stmt in CREATE_INDEX.strip().split("\n"):
        stmt = stmt.strip()
        if stmt:
            cur.execute(stmt)
    con.commit()

    total_inserted = 0
    fy_stats: dict[int, dict] = {}

    for fy_hint, fname in sorted(FILES.items()):
        path = os.path.join(RAW_DIR, fname)
        if not os.path.exists(path):
            print(f"[SKIP] {path} not found")
            continue

        wb = openpyxl.load_workbook(path, data_only=True)
        print(f"\n=== {fname} (FYヒント: {fy_hint}) ===")
        print(f"シート一覧: {wb.sheetnames}")

        file_records = []
        for sheet_name, (p_type, b_method) in SHEET_MAP.items():
            if sheet_name not in wb.sheetnames:
                print(f"  [MISSING] {sheet_name}")
                continue
            ws = wb[sheet_name]
            recs = parse_sheet(ws, fy_hint, p_type, b_method, fname)
            print(f"  {sheet_name}: {len(recs)}件")
            file_records.extend(recs)

        # DB挿入
        insert_sql = """
        INSERT INTO contracts
          (fiscal_year, procurement_type, bid_method, contract_name,
           contracting_officer, contract_date, vendor_name, vendor_address,
           corporate_number, contract_basis, planned_price, contract_amount,
           award_rate, notes, reemployed_officers, source_file)
        VALUES
          (:fiscal_year, :procurement_type, :bid_method, :contract_name,
           :contracting_officer, :contract_date, :vendor_name, :vendor_address,
           :corporate_number, :contract_basis, :planned_price, :contract_amount,
           :award_rate, :notes, :reemployed_officers, :source_file)
        """
        cur.executemany(insert_sql, file_records)
        con.commit()
        total_inserted += len(file_records)
        print(f"  → {len(file_records)}件挿入")

        # FY別集計（同一ファイルから複数FYが入る可能性）
        for r in file_records:
            fy = r["fiscal_year"] or fy_hint
            if fy not in fy_stats:
                fy_stats[fy] = {"count": 0, "amount": 0.0}
            fy_stats[fy]["count"] += 1
            fy_stats[fy]["amount"] += r["contract_amount"] or 0.0

    con.close()

    print(f"\n=== 合計挿入: {total_inserted}件 ===\n")


if __name__ == "__main__":
    main()
