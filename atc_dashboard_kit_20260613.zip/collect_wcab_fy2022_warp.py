#!/usr/bin/env python3
"""
WCAB FY2022 未収得ファイル補完スクリプト
WARP published.html (20230601) から新規発見したファイルを追加収集。
全14ファイルはライブサーバーで200確認済み。
"""

import re, time, sqlite3, urllib.request, urllib.error
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import fitz
except ImportError:
    print("ERROR: pymupdf not installed. Run: pip install pymupdf")
    import sys; sys.exit(1)

PROJECT  = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR  = PROJECT / 'data/pdfs/atc'
HEADERS  = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
WCAB_BASE = 'https://www.cab.mlit.go.jp/wcab/file/'
REIWA_BASE = 2018

# 新規収集ファイル（WARP published.html 20230601 で発見、ライブ200確認済み）
NEW_FILES = [
    # Apr 2022
    'kk_20220406.pdf', 'kk_20220427.pdf',
    'bk_20220412.pdf', 'bk_20220427.pdf',
    'bz_20220406.pdf', 'bz_20220427.pdf',
    'kz_20220406.pdf', 'kz_20220427.pdf',
    # Jul 2022 extra（collect_wcab_fy2022.py 未掲載）
    'bk_20220705.pdf', 'kk_20220705.pdf',
    'bz_20220701.pdf', 'bz_20220708.pdf',
    'kz_20220701.pdf', 'kz_20220705.pdf',
]

RE_REIWA_DATE   = re.compile(r'^令和(\d+)年(\d+)月(\d+)日$')
RE_REIWA_PERIOD = re.compile(r'令和\d+年\d+月\d+日.*[～~]')
RE_CORP_NUM     = re.compile(r'^\d{13}$')
RE_AMOUNT_YEN   = re.compile(r'^[\d,]+円$')
RE_TWOAMOUNTS   = re.compile(r'^([\d,]+)\s+([\d,]+)$')
RE_RATE_PCT     = re.compile(r'^[\d.]+%$')
RE_PAGE_HEADER  = re.compile(
    r'公共調達の適正化|契約の相手方の商号|公共工事の名称|物品役務の名称|'
    r'契約担当官|一般競争入札.*指名競争|又は名称及び住所|随意契約によることとした')
RE_DATE_PREFIX  = re.compile(r'^(令和\d+年\d+月\d+日)(.+)$')


def is_page_header(text):
    return bool(RE_PAGE_HEADER.search(text)) or len(text) > 80


def classify_line(text):
    if RE_REIWA_DATE.match(text): return 'date'
    if RE_REIWA_PERIOD.search(text): return 'period'
    if RE_CORP_NUM.match(text): return 'corp_num'
    if RE_AMOUNT_YEN.match(text): return 'amount_yen'
    if RE_TWOAMOUNTS.match(text.replace(',', '')): return 'two_amounts'
    t_clean = text.replace(',', '').replace('円', '').strip()
    if re.match(r'^\d+$', t_clean) and len(t_clean) >= 4:
        try:
            if float(t_clean) >= 100: return 'amount_plain'
        except: pass
    if RE_RATE_PCT.match(text): return 'rate'
    try:
        v = float(text)
        if 0.0 <= v <= 100.0 and '.' in text: return 'rate'
    except: pass
    if '競争入札' in text or '指名競争' in text: return 'bid_kw'
    if '随意契約' in text and len(text) < 30: return 'bid_kw'
    if '会計法' in text or '規定を適用' in text or '随意契約を締結' in text: return 'basis_kw'
    if is_page_header(text): return 'header'
    return 'other'


def extract_pdf_lines(pdf_path):
    doc = fitz.open(str(pdf_path))
    result = []
    for page_num, page in enumerate(doc):
        try:
            xml_str = page.get_text('xml')
            root = ET.fromstring(xml_str)
        except Exception:
            continue
        for line in root.findall('.//line'):
            chars_with_x = []
            for char in line.findall('.//char'):
                c = char.get('c', '')
                if not c: continue
                try:
                    cx = float(char.get('x', '0'))
                    bbox = line.get('bbox', '')
                    parts = bbox.split()
                    if len(parts) >= 4:
                        y0, y1 = float(parts[1]), float(parts[3])
                    else:
                        y0 = y1 = 0.0
                    chars_with_x.append((cx, (y0 + y1) / 2, c))
                except: continue
            if not chars_with_x:
                text = line.get('text', '').strip() if hasattr(line, 'get') else ''
                if not text: continue
                bbox = line.get('bbox', '')
                try:
                    x0, y0, x1, y1 = [float(v) for v in bbox.split()]
                except: continue
                y_center = (y0 + y1) / 2
                result.append({'page': page_num, 'x_min': x0, 'x_max': x1,
                    'y_page': y_center, 'y_global': page_num * 1000 + y_center, 'text': text})
                continue
            COL_GAP = 12.0
            segments = []
            seg_chars = [chars_with_x[0]]
            for i in range(1, len(chars_with_x)):
                if chars_with_x[i][0] - chars_with_x[i-1][0] > COL_GAP:
                    segments.append(seg_chars)
                    seg_chars = [chars_with_x[i]]
                else:
                    seg_chars.append(chars_with_x[i])
            segments.append(seg_chars)
            y_center = chars_with_x[0][1]
            for seg in segments:
                seg_text = ''.join(c for _, _, c in seg).strip()
                if not seg_text: continue
                x_min = seg[0][0]
                m = RE_DATE_PREFIX.match(seg_text)
                if m:
                    dp, rp = m.group(1), m.group(2)
                    dl = len(dp)
                    if len(seg) >= dl:
                        sx = seg[dl][0]; dxmax = sx - 1
                    else:
                        dxmax = x_min + dl * 8
                    for st, sx0, sx1 in [(dp, x_min, dxmax), (rp, dxmax+1, dxmax+1+len(rp)*8)]:
                        result.append({'page': page_num, 'x_min': sx0, 'x_max': sx1,
                            'y_page': y_center, 'y_global': page_num * 1000 + y_center, 'text': st})
                else:
                    result.append({'page': page_num, 'x_min': x_min, 'x_max': seg[-1][0]+8,
                        'y_page': y_center, 'y_global': page_num * 1000 + y_center, 'text': seg_text})
    doc.close()
    return result


def parse_records(lines, procurement_type, bid_or_zui):
    data_lines = [ln for ln in lines if ln['y_page'] > 95 and not is_page_header(ln['text'])]
    if not data_lines: return []
    corp_lines = sorted([ln for ln in data_lines if classify_line(ln['text']) == 'corp_num'],
                        key=lambda l: l['y_global'])
    if not corp_lines: return []
    records = []
    for idx, corp_ln in enumerate(corp_lines):
        y_low = (min(l['y_global'] for l in data_lines) - 1) if idx == 0 \
            else (corp_lines[idx-1]['y_global'] + corp_ln['y_global']) / 2
        y_high = (max(l['y_global'] for l in data_lines) + 1) if idx == len(corp_lines) - 1 \
            else (corp_ln['y_global'] + corp_lines[idx+1]['y_global']) / 2
        rec_lines = sorted([ln for ln in data_lines if y_low <= ln['y_global'] <= y_high],
                           key=lambda l: (l['x_min'], l['y_global']))
        if not rec_lines: continue
        corp_x = corp_ln['x_min']
        classified = [(ln, classify_line(ln['text'])) for ln in rec_lines]
        cn = co = cd = vn = va = cb = bm = None
        pp = ca = ar = None
        amounts = []
        for ln, t in classified:
            if t == 'date':
                v = RE_REIWA_DATE.match(ln['text'])
                if v:
                    ry, mo, dd = int(v.group(1)), int(v.group(2)), int(v.group(3))
                    if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
                        cd = f'{REIWA_BASE+ry}{mo:02d}{dd:02d}'
            elif t in ('amount_yen', 'amount_plain'):
                try:
                    v = float(ln['text'].replace(',', '').replace('円', ''))
                    if v >= 100: amounts.append((v, ln['x_min']))
                except: pass
            elif t == 'rate':
                try: ar = float(ln['text'].replace('%', ''))
                except: pass
            elif t == 'bid_kw':
                bm = '随意契約' if '随意' in ln['text'] else '一般競争入札'
            elif t == 'basis_kw':
                cb = ln['text']
            elif t == 'two_amounts':
                parts = ln['text'].replace(',', '').split()
                try: amounts.extend([(float(p), ln['x_min']) for p in parts if float(p) >= 100])
                except: pass
            elif t == 'other':
                txt = ln['text'].strip()
                if not txt: continue
                if ln['x_min'] < corp_x - 10:
                    if cn is None: cn = txt
                    elif co is None: co = txt
                else:
                    if vn is None: vn = txt
                    elif va is None: va = txt
        if amounts:
            amounts_sorted = sorted(amounts, key=lambda x: x[1])
            vals = [a for a, _ in amounts_sorted]
            if len(vals) >= 2: pp, ca = vals[0], vals[1]
            elif len(vals) == 1: ca = vals[0]
        if bm is None and cb: bm = '随意契約'
        if cn is None and ca is None: continue
        records.append({
            'contract_name': cn, 'contracting_officer': co, 'contract_date': cd,
            'vendor_name': vn, 'vendor_address': va, 'corporate_number': corp_ln['text'].strip(),
            'bid_method': bm or ('随意契約' if bid_or_zui == 'zui' else '一般競争入札'),
            'contract_basis': cb, 'planned_price': pp, 'contract_amount': ca, 'award_rate': ar,
            'procurement_type': procurement_type or '物品役務',
        })
    return records


def date_to_fy(ds):
    if not ds or len(ds) < 6: return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def get_prefix(fname):
    return re.match(r'^([a-z]{2})', fname.lower()).group(1)


def prefix_to_type(prefix):
    pt = '建設工事' if prefix in ('kk', 'kz') else '物品役務'
    bz = 'bid' if prefix in ('kk', 'bk') else 'zui'
    return pt, bz


def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    total_ins = total_dup = total_nd = total_404 = 0
    fy_counts = {}

    for fname in NEW_FILES:
        url = WCAB_BASE + fname
        fpath = PDF_DIR / fname
        prefix = get_prefix(fname)
        pt, bz = prefix_to_type(prefix)

        # ダウンロード
        if not (fpath.exists() and fpath.stat().st_size > 500):
            try:
                req = urllib.request.Request(url, headers=HEADERS)
                resp = urllib.request.urlopen(req, timeout=20)
                data = resp.read()
                if len(data) < 500:
                    print(f"  SKIP(too small): {fname}")
                    total_404 += 1
                    continue
                with open(fpath, 'wb') as f:
                    f.write(data)
            except urllib.error.HTTPError as e:
                print(f"  HTTP{e.code}: {fname}")
                total_404 += 1
                continue
            except Exception as e:
                print(f"  ERR({e}): {fname}")
                total_404 += 1
                continue

        # パース
        lines = extract_pdf_lines(fpath)
        pages = {}
        for ln in lines:
            pages.setdefault(ln['page'], []).append(ln)
        recs = []
        for pn in sorted(pages.keys()):
            recs.extend(parse_records(sorted(pages[pn], key=lambda l: l['y_global']), pt, bz))

        # DB挿入
        ins = dup = nd = 0
        for rec in recs:
            fy = date_to_fy(rec.get('contract_date'))
            if fy is None:
                nd += 1
                continue
            corp = rec.get('corporate_number')
            dt   = rec.get('contract_date')
            amt  = rec.get('contract_amount')
            if corp and dt and amt:
                cur.execute(
                    "SELECT 1 FROM contracts WHERE corporate_number=? AND contract_date=? "
                    "AND contract_amount=? AND fiscal_year=?", (corp, dt, amt, fy))
                if cur.fetchone():
                    dup += 1
                    continue
            cur.execute("""
                INSERT INTO contracts (fiscal_year, procurement_type, bid_method,
                    contract_name, contracting_officer, contract_date, vendor_name, vendor_address,
                    corporate_number, contract_basis, planned_price, contract_amount, award_rate,
                    notes, source_file, source)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                fy, rec.get('procurement_type', '物品役務'), rec.get('bid_method', ''),
                rec.get('contract_name'), rec.get('contracting_officer'), rec.get('contract_date'),
                rec.get('vendor_name'), rec.get('vendor_address'), rec.get('corporate_number'),
                rec.get('contract_basis'), rec.get('planned_price'), rec.get('contract_amount'),
                rec.get('award_rate'), None, fname, 'wcab',
            ))
            ins += 1
            fy_counts[fy] = fy_counts.get(fy, 0) + 1
        conn.commit()
        total_ins += ins
        total_dup += dup
        total_nd += nd

        size_kb = fpath.stat().st_size // 1024
        print(f"  {fname:<28} {size_kb:>4}KB  recs={len(recs):>3}  +{ins}件 (dup={dup})")
        time.sleep(0.3)

    conn.close()
    print(f"\n合計: +{total_ins}件新規  重複={total_dup}  日付なし={total_nd}  404={total_404}")
    print("FY内訳:")
    for fy in sorted(fy_counts):
        print(f"  FY{fy}: {fy_counts[fy]}件")

    # Final summary
    conn2 = sqlite3.connect(DB_PATH)
    c2 = conn2.cursor()
    print("\n=== DB現状（wcab） ===")
    c2.execute(
        "SELECT fiscal_year, COUNT(*), ROUND(SUM(contract_amount)/1e8, 1) "
        "FROM contracts WHERE source='wcab' GROUP BY fiscal_year ORDER BY fiscal_year")
    for r in c2.fetchall():
        print(f"  FY{r[0]}: {r[1]:>4}件  {(r[2] or 0):.1f}億円")
    conn2.close()


if __name__ == '__main__':
    main()
