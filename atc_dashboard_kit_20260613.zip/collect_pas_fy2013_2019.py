#!/usr/bin/env python3
"""
PAS (地方整備局) FY2013-2018 空港関連データ収集スクリプト

=== 調査結果サマリー（2026-04-20確認済み） ===

旧URLパターン（〜2019年頃）:
  http://www.pas.ysk.nilim.go.jp/KekkaKohyo/{Bureau}/koji{YYYYMM}.xls
新URLパターン（2020年以降）:
  https://www.pas.ysk.nilim.go.jp/contents/KekkaKohyo/{Bureau}/koji{YYYYMM}.xls

WARPは旧URL系を2013年〜2019年2月まで保存。確認済みスナップ一覧:
  coll=20130610, ts=20130604044002 → koji201204-201403 (FY2012-FY2013)
  coll=20140611, ts=20140601042445 → koji201304-201503 (FY2013-FY2014)
  coll=20150622, ts=20150601221742 → koji201404-201603 (FY2014-FY2015)
  coll=20160628, ts=20160601162952 → koji201504-201703 (FY2015-FY2016)
  coll=20170629, ts=20170601125730 → koji201604-201803 (FY2016-FY2017)
  coll=20180629, ts=20180601092430 → koji201704-201903 (FY2017-FY2018 April-Dec)
  coll=20190227, ts=20190201120557 → koji201804-201812 (FY2018 April-Dec only)

=== FY別カバレッジ ===
  FY2013: 12/12ヶ月 完全 (coll=20140611)
  FY2014: 12/12ヶ月 完全 (coll=20150622)
  FY2015: 12/12ヶ月 完全 (coll=20160628)
  FY2016: 11/12ヶ月 (201610欠落、両スナップとも404)
  FY2017: 12/12ヶ月 完全 (coll=20180629)
  FY2018:  9/12ヶ月 (Jan-Mar2019は未アーカイブ)
  FY2019: 0ヶ月 → 完全不可（旧URL最終スナップ2019-02、新URL最初スナップ2022-04）

対象局（旧システムでは8局、Hokkaido/Okinawaなし）:
  Tohoku, Kanto, Hokuriku, Chubu, Kinki, Chugoku, Shikoku, Kyushu
"""

import re
import time
import sqlite3
import urllib.request
import urllib.error
from pathlib import Path

try:
    import xlrd
except ImportError:
    import subprocess, sys
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'xlrd==1.2.0'], check=True)
    import xlrd

PROJECT = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH = PROJECT / 'data/db/atc_procurement.db'
DL_DIR  = PROJECT / 'data/raw/pas_kekka'
DL_DIR.mkdir(parents=True, exist_ok=True)

HEADERS  = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
OLD_PAS_BASE = 'http://www.pas.ysk.nilim.go.jp'

# FY → ([(coll, ts), ...], [months_in_FY])
# 複数スナップを持つFYは fallback として使用
WARP_BY_FY = {
    2013: [('20140611', '20140601042445'), ('20130610', '20130604044002')],
    2014: [('20150622', '20150601221742'), ('20140611', '20140601042445')],
    2015: [('20160628', '20160601162952'), ('20150622', '20150601221742')],
    2016: [('20170629', '20170601125730'), ('20160628', '20160601162952')],
    2017: [('20180629', '20180601092430'), ('20170629', '20170601125730')],
    2018: [('20190227', '20190201120557'), ('20180629', '20180601092430')],
    # FY2019: 完全不可（旧URL最終スナップ=2019-02で Jan-Mar2019未収録、
    #          新URL最初スナップ=2022-04で koji201904以降のみ）
}

# 旧システムで確認済みの8局（Hokkaido/Okinawaは旧URLに存在しない）
BUREAUS = [
    ('Tohoku',   '東北'),
    ('Kanto',    '関東'),
    ('Hokuriku', '北陸'),
    ('Chubu',    '中部'),
    ('Kinki',    '近畿'),
    ('Chugoku',  '中国'),
    ('Shikoku',  '四国'),
    ('Kyushu',   '九州'),
]

# 空港関連キーワード
AIRPORT_KW = [
    '空港', '滑走路', '誘導路', 'エプロン', '航空灯火', '航空保安', '空港整備',
    '空港護岸', '空港埋立', '着陸帯', '旅客搭乗橋', '除雪機庫', '航空局',
]

TARGET_FY = list(range(2013, 2019))  # 2019は取得不可のため除外


def fy_months(fy):
    """Return list of YYYYMM for a given fiscal year (Apr-Mar)."""
    months = []
    for m in range(4, 13):
        months.append(f'{fy}{m:02d}')
    for m in range(1, 4):
        months.append(f'{fy+1}{m:02d}')
    return months


def is_airport_related(name):
    return bool(name) and any(kw in name for kw in AIRPORT_KW)


def serial_to_ymd(serial, datemode=0):
    try:
        v = float(serial)
        if v <= 0:
            return None
        t = xlrd.xldate_as_tuple(v, datemode)
        if t[0] == 0:
            return None
        return f'{t[0]:04d}{t[1]:02d}{t[2]:02d}'
    except Exception:
        return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def yyyymm_to_fy(yyyymm):
    y, m = int(str(yyyymm)[:4]), int(str(yyyymm)[4:])
    return y if m >= 4 else y - 1


def download_warp(bureau_en, fname, dest_path, warp_coll, warp_ts):
    """旧URL形式でWARPから XLS を取得。成功時 True を返す。"""
    if dest_path.exists() and dest_path.stat().st_size > 5000:
        return True
    orig_url = f'{OLD_PAS_BASE}/KekkaKohyo/{bureau_en}/{fname}'
    warp_url = f'https://warp.ndl.go.jp/{warp_coll}/{warp_ts}id_/{orig_url}'
    try:
        req  = urllib.request.Request(warp_url, headers=HEADERS)
        resp = urllib.request.urlopen(req, timeout=30)
        data = resp.read()
        if len(data) < 1000:
            return False
        dest_path.write_bytes(data)
        return True
    except Exception:
        return False


def parse_xls(fpath, file_type, bureau_ja, yyyymm, notes_tag, target_fy):
    """XLS をパースして airport 関連レコードを返す。target_fy でフィルタ。"""
    try:
        wb = xlrd.open_workbook(str(fpath))
    except Exception as e:
        print(f'  ERROR opening {fpath.name}: {e}')
        return []

    ws = wb.sheet_by_index(0)
    dm = wb.datemode
    records = []

    for r in range(4, ws.nrows):
        row = [ws.cell_value(r, c) if c < ws.ncols else '' for c in range(19)]
        name_raw = str(row[1]).strip()
        if not name_raw or name_raw in ('None', '0.0', ''):
            continue
        if not is_airport_related(name_raw):
            continue

        bid_date   = serial_to_ymd(row[2], dm)
        award_date = serial_to_ymd(row[3], dm)
        if not bid_date:
            bid_date = f'{yyyymm[:4]}{yyyymm[4:]}01'

        fy = date_to_fy(bid_date) or yyyymm_to_fy(yyyymm)
        # 対象FYのみ収録
        if fy != target_fy:
            continue

        def safe_float(v):
            try:
                f = float(v)
                return f if f > 0 else None
            except Exception:
                return None

        work_type   = str(row[4]).strip() or None
        bid_method  = str(row[5]).strip() or None
        vendor_raw  = str(row[7]).strip()
        vendor_name = vendor_raw if vendor_raw and vendor_raw not in ('None', '') else None

        records.append({
            'fiscal_year':   fy,
            'bureau':        bureau_ja,
            'file_name':     fpath.name,
            'file_type':     file_type,
            'contract_name': name_raw,
            'bid_date':      bid_date,
            'award_date':    award_date,
            'work_type':     work_type if work_type != 'None' else None,
            'bid_method':    bid_method if bid_method != 'None' else None,
            'vendor_name':   vendor_name,
            'planned_price': safe_float(row[8]),
            'bid_amount':    safe_float(row[9]),
            'award_amount':  safe_float(row[11]),
            'notes':         notes_tag,
        })
    return records


def get_existing_keys(conn):
    try:
        rows = conn.execute(
            "SELECT bureau || '/' || file_name || '/' || CAST(fiscal_year AS TEXT) "
            "FROM pas_airport_contracts WHERE fiscal_year < 2020"
        ).fetchall()
        return set(r[0] for r in rows)
    except Exception:
        return set()


def insert_records(conn, records):
    if not records:
        return 0
    conn.executemany("""
        INSERT INTO pas_airport_contracts
          (fiscal_year, bureau, file_name, file_type, contract_name,
           bid_date, award_date, work_type, bid_method, vendor_name,
           planned_price, bid_amount, award_amount, notes)
        VALUES
          (:fiscal_year, :bureau, :file_name, :file_type, :contract_name,
           :bid_date, :award_date, :work_type, :bid_method, :vendor_name,
           :planned_price, :bid_amount, :award_amount, :notes)
    """, records)
    conn.commit()
    return len(records)


def main():
    import sys
    sys.stdout.reconfigure(encoding='utf-8')

    conn = sqlite3.connect(str(DB_PATH))
    existing = get_existing_keys(conn)
    print(f'既存キー数（FY2013-2018）: {len(existing)}')

    total_ins = total_skip = total_fail = 0

    for fy in TARGET_FY:
        months    = fy_months(fy)
        warp_snaps = WARP_BY_FY[fy]
        fy_ins = 0
        print(f'\n=== FY{fy} ({len(warp_snaps)}スナップ) ===')

        for bureau_en, bureau_ja in BUREAUS:
            bureau_ins = 0
            for yyyymm in months:
                for ftype in ['koji', 'gyomu']:
                    fname     = f'{ftype}{yyyymm}.xls'
                    dedup_key = f'{bureau_ja}/{fname}/{fy}'

                    if dedup_key in existing:
                        total_skip += 1
                        continue

                    dest = DL_DIR / f'old_{bureau_en}_{fname}'
                    got  = False
                    tag  = ''

                    # スナップを順番に試す
                    for warp_coll, warp_ts in warp_snaps:
                        ok = download_warp(bureau_en, fname, dest, warp_coll, warp_ts)
                        if ok:
                            tag = f'warp:{warp_coll}'
                            got = True
                            break

                    if not got:
                        total_fail += 1
                        continue

                    time.sleep(0.15)

                    recs = parse_xls(dest, ftype, bureau_ja, yyyymm, tag, fy)
                    if recs:
                        n = insert_records(conn, recs)
                        bureau_ins += n
                        total_ins  += n
                        existing.add(dedup_key)

            if bureau_ins:
                print(f'  {bureau_ja}: {bureau_ins}件')
            fy_ins += bureau_ins

        print(f'  FY{fy} 小計: {fy_ins}件')

    conn.close()

    print(f'\n=== PAS FY2013-2018 収集完了 ===')
    print(f'新規挿入: {total_ins}件')
    print(f'スキップ: {total_skip}件（既存）')
    print(f'取得失敗: {total_fail}件（404等）')

    print('\n=== 全FY PAS集計 ===')
    conn2 = sqlite3.connect(str(DB_PATH))
    for row in conn2.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(award_amount,0))/1e8, 1)
        FROM pas_airport_contracts GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall():
        print(f'  FY{row[0]}: {row[1]}件 / {row[2]}億円')
    conn2.close()


if __name__ == '__main__':
    main()
