"""
航空管制調達DB → atc_fy2024_dashboard.xlsx
"""
import sqlite3
import io
import sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, PatternFill, numbers
from openpyxl.styles import Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.filters import AutoFilter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

DB_PATH = "data/db/atc_procurement.db"
OUT_PATH = "data/output/atc_fy2024_dashboard.xlsx"

HDR_BG = "1F497D"
HDR_FG = "FFFFFF"

def hdr_style():
    font = Font(bold=True, color=HDR_FG, name="Arial", size=10)
    fill = PatternFill("solid", fgColor=HDR_BG)
    align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    return font, fill, align

def apply_header(ws, row, cols):
    font, fill, align = hdr_style()
    for col_idx, val in enumerate(cols, 1):
        c = ws.cell(row=row, column=col_idx, value=val)
        c.font = font
        c.fill = fill
        c.alignment = align

def num_fmt(ws, col, start_row, end_row, fmt):
    for r in range(start_row, end_row + 1):
        ws.cell(r, col).number_format = fmt

def set_col_widths(ws, widths):
    for col_idx, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(col_idx)].width = w

def freeze_and_filter(ws, freeze_cell, filter_range):
    ws.freeze_panes = freeze_cell
    ws.auto_filter.ref = filter_range

def classify_org(contracting_officer, source):
    """組織分類ルール（優先順位: より具体的なものを先に適用）"""
    if contracting_officer is None:
        if source == 'tcab':
            return "東京航空局"
        elif source == 'wcab':
            return "大阪航空局"
        else:
            return "その他"
    co = contracting_officer
    # More specific checks first
    if "東京航空局" in co:
        return "東京航空局"
    if "大阪航空局" in co:
        return "大阪航空局"
    if "管制部" in co or "ATMC" in co:
        return "航空交通管制部"
    if "空港事務所" in co:
        return "空港事務所"
    if "航空保安大学校" in co:
        return "航空保安大学校"
    if "航空局" in co or "霞が関" in co or "九段南" in co:
        return "航空局本局"
    return "その他"

def money_fmt(ws, col_letter, data_start, data_end):
    for r in range(data_start, data_end + 1):
        ws[f"{col_letter}{r}"].number_format = '#,##0'

# ───────────────────────────────────────────────
# Load data
# ───────────────────────────────────────────────
conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

cur.execute("""
SELECT id, fiscal_year, contract_name, contracting_officer, contract_date,
       vendor_name, corporate_number, bid_method, planned_price, contract_amount,
       award_rate, procurement_type, source_file, source
FROM contracts
ORDER BY fiscal_year, contract_date
""")
all_contracts = cur.fetchall()

cur.execute("""
SELECT id, fiscal_year, bureau, file_name, file_type, contract_name,
       bid_date, award_date, work_type, bid_method, vendor_name,
       planned_price, bid_amount, award_amount, notes
FROM pas_airport_contracts
ORDER BY fiscal_year, bureau, award_date
""")
all_pas = cur.fetchall()
conn.close()

# Add org classification to contracts
contracts_with_org = []
for r in all_contracts:
    org = classify_org(r['contracting_officer'], r['source'])
    contracts_with_org.append({
        'fiscal_year': r['fiscal_year'],
        'contract_name': r['contract_name'],
        'contracting_officer': r['contracting_officer'],
        'org': org,
        'contract_date': r['contract_date'],
        'vendor_name': r['vendor_name'],
        'corporate_number': r['corporate_number'],
        'bid_method': r['bid_method'],
        'planned_price': r['planned_price'],
        'contract_amount': r['contract_amount'],
        'award_rate': r['award_rate'],
        'procurement_type': r['procurement_type'],
        'source': r['source'],
        'source_file': r['source_file'],
    })

wb = Workbook()

# ───────────────────────────────────────────────
# Sheet 1: 全件データ（航空局）
# ───────────────────────────────────────────────
ws1 = wb.active
ws1.title = "全件データ（航空局）"

headers1 = ["年度", "件名", "契約担当官", "組織分類", "契約日",
            "相手方", "法人番号", "入札方式", "予定価格（円）", "契約金額（円）",
            "落札率（%）", "調達種別", "ソース"]
apply_header(ws1, 1, headers1)

col_widths1 = [6, 50, 35, 14, 12, 30, 14, 18, 16, 16, 10, 12, 15]
set_col_widths(ws1, col_widths1)

for i, r in enumerate(contracts_with_org, 2):
    ws1.cell(i, 1, r['fiscal_year'])
    ws1.cell(i, 2, r['contract_name'])
    ws1.cell(i, 3, r['contracting_officer'])
    ws1.cell(i, 4, r['org'])
    ws1.cell(i, 5, r['contract_date'])
    ws1.cell(i, 6, r['vendor_name'])
    ws1.cell(i, 7, r['corporate_number'])
    ws1.cell(i, 8, r['bid_method'])
    if r['planned_price'] is not None:
        ws1.cell(i, 9, r['planned_price']).number_format = '#,##0'
    if r['contract_amount'] is not None:
        ws1.cell(i, 10, r['contract_amount']).number_format = '#,##0'
    if r['award_rate'] is not None:
        ws1.cell(i, 11, r['award_rate']).number_format = '0.0%'
    ws1.cell(i, 12, r['procurement_type'])
    ws1.cell(i, 13, r['source'])

# Set number format for all money rows (9, 10) and pct (11)
n1 = len(contracts_with_org) + 1
freeze_and_filter(ws1, "A2", f"A1:{get_column_letter(len(headers1))}1")

ws1.row_dimensions[1].height = 30

# ───────────────────────────────────────────────
# Sheet 2: 全件データ（地方整備局）
# ───────────────────────────────────────────────
ws2 = wb.create_sheet("全件データ（地方整備局）")

headers2 = ["年度", "整備局", "ファイル名", "種別", "件名",
            "入札日", "落札日", "工事種別", "入札方式",
            "業者名", "予定価格（円）", "入札額（円）", "落札額（円）", "備考"]
apply_header(ws2, 1, headers2)
col_widths2 = [6, 8, 28, 8, 45, 12, 12, 18, 20, 30, 16, 16, 16, 20]
set_col_widths(ws2, col_widths2)

for i, r in enumerate(all_pas, 2):
    ws2.cell(i, 1, r['fiscal_year'])
    ws2.cell(i, 2, r['bureau'])
    ws2.cell(i, 3, r['file_name'])
    ws2.cell(i, 4, r['file_type'])
    ws2.cell(i, 5, r['contract_name'])
    ws2.cell(i, 6, r['bid_date'])
    ws2.cell(i, 7, r['award_date'])
    ws2.cell(i, 8, r['work_type'])
    ws2.cell(i, 9, r['bid_method'])
    ws2.cell(i, 10, r['vendor_name'])
    for col_idx, key in [(11, 'planned_price'), (12, 'bid_amount'), (13, 'award_amount')]:
        v = r[key]
        if v is not None:
            ws2.cell(i, col_idx, v).number_format = '#,##0'
    ws2.cell(i, 14, r['notes'])

freeze_and_filter(ws2, "A2", f"A1:{get_column_letter(len(headers2))}1")
ws2.row_dimensions[1].height = 30

# ───────────────────────────────────────────────
# Sheet 3: 企業別内訳
# ───────────────────────────────────────────────
ws3 = wb.create_sheet("企業別内訳")

# Aggregate: vendor_name → count + total amount (contracts + pas)
from collections import defaultdict
vendor_data = defaultdict(lambda: {'count': 0, 'amount': 0.0})

for r in contracts_with_org:
    vn = r['vendor_name'] or '（不明）'
    vendor_data[vn]['count'] += 1
    vendor_data[vn]['amount'] += r['contract_amount'] or 0.0

for r in all_pas:
    vn = r['vendor_name'] or '（不明）'
    vendor_data[vn]['count'] += 1
    vendor_data[vn]['amount'] += r['award_amount'] or 0.0

# Sort by amount desc
vendor_sorted = sorted(vendor_data.items(), key=lambda x: -x[1]['amount'])

headers3 = ["業者名", "件数", "合計金額（円）", "平均金額（円）"]
apply_header(ws3, 1, headers3)
set_col_widths(ws3, [40, 8, 18, 18])

for i, (vn, d) in enumerate(vendor_sorted, 2):
    ws3.cell(i, 1, vn)
    ws3.cell(i, 2, d['count'])
    ws3.cell(i, 3, d['amount']).number_format = '#,##0'
    avg = d['amount'] / d['count'] if d['count'] else 0
    ws3.cell(i, 4, f'=C{i}/B{i}').number_format = '#,##0'

freeze_and_filter(ws3, "A2", f"A1:{get_column_letter(len(headers3))}1")
ws3.row_dimensions[1].height = 30

# ───────────────────────────────────────────────
# Sheet 4: 組織別内訳
# ───────────────────────────────────────────────
ws4 = wb.create_sheet("組織別内訳")

org_data = defaultdict(lambda: {'count': 0, 'amount': 0.0})
for r in contracts_with_org:
    o = r['org']
    org_data[o]['count'] += 1
    org_data[o]['amount'] += r['contract_amount'] or 0.0

# Add 整備局 aggregate
pas_amount = sum(r['award_amount'] or 0 for r in all_pas)
pas_count = len(all_pas)
org_data['地方整備局（PAS）'] = {'count': pas_count, 'amount': pas_amount}

org_sorted = sorted(org_data.items(), key=lambda x: -x[1]['amount'])
total_amount = sum(d['amount'] for d in org_data.values())
total_count = sum(d['count'] for d in org_data.values())

headers4 = ["組織分類", "件数", "合計金額（円）", "平均単価（円）", "金額シェア（%）"]
apply_header(ws4, 1, headers4)
set_col_widths(ws4, [20, 8, 18, 18, 14])

for i, (org, d) in enumerate(org_sorted, 2):
    ws4.cell(i, 1, org)
    ws4.cell(i, 2, d['count'])
    ws4.cell(i, 3, d['amount']).number_format = '#,##0'
    ws4.cell(i, 4, f'=C{i}/B{i}').number_format = '#,##0'
    ws4.cell(i, 5, f'=C{i}/C{len(org_sorted)+2}').number_format = '0.0%'

# Total row
tr = len(org_sorted) + 2
font, fill, align = hdr_style()
for col_idx, val in enumerate(["合計", total_count, None, None, None], 1):
    c = ws4.cell(tr, col_idx, val)
    c.font = font
    c.fill = fill
ws4.cell(tr, 3, f'=SUM(C2:C{tr-1})').number_format = '#,##0'
ws4.cell(tr, 3).font = Font(bold=True, color=HDR_FG, name="Arial")
ws4.cell(tr, 3).fill = PatternFill("solid", fgColor=HDR_BG)
ws4.cell(tr, 4, '').number_format = '#,##0'
ws4.cell(tr, 5, '').number_format = '0.0%'

freeze_and_filter(ws4, "A2", f"A1:{get_column_letter(len(headers4))}1")
ws4.row_dimensions[1].height = 30

# ───────────────────────────────────────────────
# Sheet 5: 年度別サマリー
# ───────────────────────────────────────────────
ws5 = wb.create_sheet("年度別サマリー")

# Build FY data for contracts
from collections import Counter

fy_contracts = defaultdict(lambda: {
    'count': 0, 'amount': 0.0,
    'competitive_count': 0, 'zuikei_count': 0
})
for r in contracts_with_org:
    fy = r['fiscal_year']
    fy_contracts[fy]['count'] += 1
    fy_contracts[fy]['amount'] += r['contract_amount'] or 0.0
    bm = r['bid_method'] or ''
    pt = r['procurement_type'] or ''
    if '競争' in bm or '一般' in bm or '指名' in bm:
        fy_contracts[fy]['competitive_count'] += 1
    if '随意' in bm or '随意' in pt:
        fy_contracts[fy]['zuikei_count'] += 1

fy_pas = defaultdict(lambda: {'count': 0, 'amount': 0.0})
for r in all_pas:
    fy = r['fiscal_year']
    fy_pas[fy]['count'] += 1
    fy_pas[fy]['amount'] += r['award_amount'] or 0.0

all_fys = sorted(set(list(fy_contracts.keys()) + list(fy_pas.keys())))

headers5 = ["年度",
            "航空局件数", "航空局金額（円）", "一般競争件数", "随意契約件数",
            "一般競争率（%）", "随意契約率（%）",
            "整備局件数", "整備局金額（円）",
            "合計件数", "合計金額（円）"]
apply_header(ws5, 1, headers5)
set_col_widths(ws5, [8, 10, 18, 12, 12, 14, 14, 10, 18, 10, 18])

for i, fy in enumerate(all_fys, 2):
    fc = fy_contracts[fy]
    fp = fy_pas[fy]
    ws5.cell(i, 1, fy)
    ws5.cell(i, 2, fc['count'])
    ws5.cell(i, 3, fc['amount']).number_format = '#,##0'
    ws5.cell(i, 4, fc['competitive_count'])
    ws5.cell(i, 5, fc['zuikei_count'])
    ws5.cell(i, 6, f'=IF(B{i}=0,"",D{i}/B{i})').number_format = '0.0%'
    ws5.cell(i, 7, f'=IF(B{i}=0,"",E{i}/B{i})').number_format = '0.0%'
    ws5.cell(i, 8, fp['count'])
    ws5.cell(i, 9, fp['amount']).number_format = '#,##0'
    ws5.cell(i, 10, f'=B{i}+H{i}')
    ws5.cell(i, 11, f'=C{i}+I{i}').number_format = '#,##0'

# Total row
tr5 = len(all_fys) + 2
apply_header(ws5, tr5, ["合計"] + [""] * (len(headers5) - 1))
for col_idx, col_letter in [(2, 'B'), (3, 'C'), (4, 'D'), (5, 'E'),
                              (8, 'H'), (9, 'I'), (10, 'J'), (11, 'K')]:
    c = ws5.cell(tr5, col_idx, f'=SUM({col_letter}2:{col_letter}{tr5-1})')
    c.font = Font(bold=True, color=HDR_FG, name="Arial")
    c.fill = PatternFill("solid", fgColor=HDR_BG)
    if col_idx in [3, 9, 11]:
        c.number_format = '#,##0'

freeze_and_filter(ws5, "A2", f"A1:{get_column_letter(len(headers5))}1")
ws5.row_dimensions[1].height = 30

# ───────────────────────────────────────────────
# Sheet 6: 予算比較（FY2024）
# ───────────────────────────────────────────────
ws6 = wb.create_sheet("予算比較（FY2024）")

# Budget comparison hardcoded values (from user specification)
budget_rows = [
    ("空港整備勘定 歳出合計", 421300000000, "国土交通省 空港整備勘定決算書 FY2024"),
    ("人件費（推定）", 70000000000, "推定値（概算）"),
    ("借入金償還", 42700000000, "空港整備勘定決算書 FY2024"),
    ("調達母数（推定）", 308600000000, "歳出合計 − 人件費 − 借入金償還"),
    ("DB収録額（航空局）", 118300000000, "atc_procurement.db contracts テーブル FY2024"),
    ("DB収録額（地方整備局）", 79700000000, "atc_procurement.db pas_airport_contracts テーブル FY2024"),
    ("DB合計", 198000000000, "航空局 + 地方整備局"),
    ("未収録（推定）", 110600000000, "調達母数 − DB合計"),
    ("網羅率（推定）", 0.64, "DB合計 / 調達母数"),
]

headers6 = ["項目", "金額（円）", "備考・出典"]
apply_header(ws6, 1, headers6)
set_col_widths(ws6, [30, 18, 60])
ws6.row_dimensions[1].height = 30

for i, (label, val, note) in enumerate(budget_rows, 2):
    ws6.cell(i, 1, label)
    if isinstance(val, float):  # percentage
        c = ws6.cell(i, 2, val)
        c.number_format = '0.0%'
    else:
        c = ws6.cell(i, 3 - 1, val)  # col B = 2
        ws6.cell(i, 2, val).number_format = '#,##0'
    ws6.cell(i, 3, note)

# DB actual values for FY2024 (computed from data)
fy2024_contracts_amt = sum(r['contract_amount'] or 0 for r in contracts_with_org if r['fiscal_year'] == 2024)
fy2024_contracts_cnt = sum(1 for r in contracts_with_org if r['fiscal_year'] == 2024)
fy2024_pas_amt = sum(r['award_amount'] or 0 for r in all_pas if r['fiscal_year'] == 2024)
fy2024_pas_cnt = sum(1 for r in all_pas if r['fiscal_year'] == 2024)

note_row = len(budget_rows) + 3
ws6.cell(note_row, 1, "【DB実績値（FY2024）】").font = Font(bold=True, name="Arial")
ws6.cell(note_row + 1, 1, "航空局 件数")
ws6.cell(note_row + 1, 2, fy2024_contracts_cnt)
ws6.cell(note_row + 2, 1, "航空局 金額合計（円）")
ws6.cell(note_row + 2, 2, fy2024_contracts_amt).number_format = '#,##0'
ws6.cell(note_row + 3, 1, "整備局 件数")
ws6.cell(note_row + 3, 2, fy2024_pas_cnt)
ws6.cell(note_row + 4, 1, "整備局 金額合計（円）")
ws6.cell(note_row + 4, 2, fy2024_pas_amt).number_format = '#,##0'
ws6.cell(note_row + 5, 1, "DB合計金額（円）")
ws6.cell(note_row + 5, 2, fy2024_contracts_amt + fy2024_pas_amt).number_format = '#,##0'

ws6.freeze_panes = "A2"

# ───────────────────────────────────────────────
# Save
# ───────────────────────────────────────────────
wb.save(OUT_PATH)
print(f"Saved: {OUT_PATH}")
print(f"Sheet 1 (航空局): {len(contracts_with_org)} rows")
print(f"Sheet 2 (整備局): {len(all_pas)} rows")
print(f"Sheet 3 (企業別): {len(vendor_sorted)} vendors")
print(f"Sheet 4 (組織別): {len(org_sorted)} orgs")
print(f"Sheet 5 (年度別): {len(all_fys)} fiscal years")
print(f"FY2024 航空局: {fy2024_contracts_cnt}件 / {fy2024_contracts_amt/1e8:.1f}億円")
print(f"FY2024 整備局: {fy2024_pas_cnt}件 / {fy2024_pas_amt/1e8:.1f}億円")
