#!/usr/bin/env python3
"""
WCABパーサー修正 & 失敗ファイル再収集スクリプト

対象ファイル:
  bk_20220705.pdf  — FY2022 物品役務 競争 (10件)
  kk_20220705.pdf  — FY2022 建設工事 競争 (8件)
  kk_230531.pdf    — FY2022/2023 建設工事 競争 (5件)
  kk_221212.pdf    — FY2022 建設工事 競争 (未DL)

修正内容:
  RE_CORP_NUM を前方サブマッチに変更し、
  "2011101020396 一般競争入札" 形式に対応。
"""

import re
import time
import sqlite3
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import fitz
except ImportError:
    print("ERROR: PyMuPDF not installed. Run: pip install pymupdf")
    import sys; sys.exit(1)

PROJECT   = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH   = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR   = PROJECT / 'data/pdfs/atc'
WCAB_BASE = 'https://www.cab.mlit.go.jp/wcab/file/'
HEADERS   = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
REIWA_BASE = 2018

# ── 対象ファイル ──────────────────────────────────────────────
TARGET_FILES = [
    ('bk_20220705.pdf', '物品役務', 'bid'),
    ('kk_20220705.pdf', '建設工事', 'bid'),
    ('kk_230531.pdf',   '建設工事', 'bid'),
    ('kk_221212.pdf',   '建設工事', 'bid'),  # 要DL
]

# ── 修正済み正規表現 ──────────────────────────────────────────
RE_REIWA_DATE   = re.compile(r'^令和(\d+)年(\d+)月(\d+)日$')
RE_REIWA_PERIOD = re.compile(r'令和\d+年\d+月\d+日.*[～~]')
# ★ 修正: 13桁数字で始まる文字列 (後続テキストあり/なし両方に対応)
RE_CORP_NUM_PREFIX = re.compile(r'^(\d{13})(\s.*)?$')
RE_CORP_NUM_EXTRACT = re.compile(r'^(\d{13})\s*(.*)')
RE_AMOUNT_YEN   = re.compile(r'^[\d,]+円$')
RE_TWOAMOUNTS   = re.compile(r'^([\d,]+)\s+([\d,]+)$')
RE_RATE_PCT     = re.compile(r'^[\d.]+%$')
RE_DATE_PREFIX  = re.compile(r'^(令和\d+年\d+月\d+日)(.+)$')
RE_PAGE_HEADER  = re.compile(
    r'公共調達の適正化|契約の相手方の商号|公共工事の名称|物品役務の名称|'
    r'契約担当官|一般競争入札.*指名競争|又は名称及び住所|随意契約によることとした')


def is_page_header(text):
    return bool(RE_PAGE_HEADER.search(text)) or len(text) > 80


def classify_line(text):
    if RE_REIWA_DATE.match(text):
        return 'date'
    if RE_REIWA_PERIOD.search(text):
        return 'period'
    # ★ 修正: 13桁プレフィックスで corp_num と判定
    if RE_CORP_NUM_PREFIX.match(text):
        return 'corp_num'
    if RE_AMOUNT_YEN.match(text):
        return 'amount_yen'
    if RE_TWOAMOUNTS.match(text.replace(',', '')):
        return 'two_amounts'
    t_clean = text.replace(',', '').replace('円', '').strip()
    if re.match(r'^\d+$', t_clean) and len(t_clean) >= 4:
        try:
            if float(t_clean) >= 100:
                return 'amount_plain'
        except:
            pass
    if RE_RATE_PCT.match(text):
        return 'rate'
    try:
        v = float(text)
        if 0.0 <= v <= 100.0 and '.' in text:
            return 'rate'
    except:
        pass
    if '競争入札' in text or '指名競争' in text:
        return 'bid_kw'
    if '随意契約' in text and len(text) < 30:
        return 'bid_kw'
    if '会計法' in text or '規定を適用' in text or '随意契約を締結' in text:
        return 'basis_kw'
    if is_page_header(text):
        return 'header'
    return 'other'


# ── PDF テキスト抽出 (collect_wcab_fy2022.py と同実装) ──────────

def _split_date_prefix(text, chars_list, x_min):
    m = RE_DATE_PREFIX.match(text)
    if not m:
        return [(text, x_min, x_min + len(text) * 8)]
    date_part = m.group(1)
    rest_part  = m.group(2)
    date_len   = len(date_part)
    if len(chars_list) >= date_len:
        split_x    = chars_list[date_len][0]
        date_x_max = split_x - 1
    else:
        date_x_max = x_min + date_len * 8
    rest_x_min = date_x_max + 1
    return [(date_part, x_min, date_x_max),
            (rest_part, rest_x_min, rest_x_min + len(rest_part) * 8)]


def extract_pdf_lines(pdf_path):
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening PDF: {e}")
        return []
    result = []
    for page_num, page in enumerate(doc):
        try:
            xml_str = page.get_text('xml')
            root = ET.fromstring(xml_str)
        except Exception:
            continue
        for line in root.findall('.//line'):
            chars_with_x = []
            for char in line.findall('.//char'):
                c = char.get('c', '')
                if not c:
                    continue
                try:
                    cx   = float(char.get('x', '0'))
                    bbox = line.get('bbox', '')
                    pts  = bbox.split()
                    y0, y1 = (float(pts[1]), float(pts[3])) if len(pts) >= 4 else (0.0, 0.0)
                    chars_with_x.append((cx, (y0 + y1) / 2, c))
                except Exception:
                    continue
            if not chars_with_x:
                text = line.get('text', '').strip() if hasattr(line, 'get') else ''
                if not text:
                    continue
                bbox = line.get('bbox', '')
                try:
                    x0, y0, x1, y1 = [float(v) for v in bbox.split()]
                except Exception:
                    continue
                y_c = (y0 + y1) / 2
                result.append({'page': page_num, 'x_min': x0, 'x_max': x1,
                                'y_page': y_c, 'y_global': page_num * 1000 + y_c,
                                'text': text})
                continue
            COL_GAP  = 12.0
            segments = []
            seg_ch   = [chars_with_x[0]]
            for i in range(1, len(chars_with_x)):
                if chars_with_x[i][0] - chars_with_x[i-1][0] > COL_GAP:
                    segments.append(seg_ch)
                    seg_ch = [chars_with_x[i]]
                else:
                    seg_ch.append(chars_with_x[i])
            segments.append(seg_ch)
            y_center = chars_with_x[0][1]
            for seg in segments:
                seg_text = ''.join(c for _, _, c in seg).strip()
                if not seg_text:
                    continue
                x_min = seg[0][0]
                for sub_text, sub_x_min, sub_x_max in _split_date_prefix(seg_text, seg, x_min):
                    result.append({'page': page_num, 'x_min': sub_x_min, 'x_max': sub_x_max,
                                   'y_page': y_center, 'y_global': page_num * 1000 + y_center,
                                   'text': sub_text})
    doc.close()
    return result


# ── レコード抽出 ────────────────────────────────────────────────

def parse_records_from_lines(lines, procurement_type, bid_or_zui):
    data_lines = [ln for ln in lines if ln['y_page'] > 95 and not is_page_header(ln['text'])]
    if not data_lines:
        return []
    corp_lines = [ln for ln in data_lines if classify_line(ln['text']) == 'corp_num']
    if not corp_lines:
        return []
    corp_lines_sorted = sorted(corp_lines, key=lambda l: l['y_global'])
    records = []
    for idx, corp_ln in enumerate(corp_lines_sorted):
        y_low  = (min(l['y_global'] for l in data_lines) - 1) if idx == 0 \
                 else (corp_lines_sorted[idx-1]['y_global'] + corp_ln['y_global']) / 2
        y_high = (max(l['y_global'] for l in data_lines) + 1) if idx == len(corp_lines_sorted)-1 \
                 else (corp_ln['y_global'] + corp_lines_sorted[idx+1]['y_global']) / 2
        rec_lines = sorted(
            [ln for ln in data_lines if y_low <= ln['y_global'] <= y_high],
            key=lambda l: (l['x_min'], l['y_global']))
        if not rec_lines:
            continue
        rec = extract_fields(rec_lines, corp_ln, procurement_type, bid_or_zui)
        if rec:
            records.append(rec)
    return records


def extract_fields(rec_lines, corp_ln, procurement_type, bid_or_zui):
    corp_x     = corp_ln['x_min']
    classified = [(ln, classify_line(ln['text'])) for ln in rec_lines]

    # ★ 修正: 結合形式 "NNNNNN... テキスト" から法人番号を抽出
    raw_cn = corp_ln['text'].strip()
    m_cn   = RE_CORP_NUM_EXTRACT.match(raw_cn)
    corporate_number = m_cn.group(1) if m_cn else raw_cn
    # 結合テキストの残余（入札方式など）— 文字化けしているので使わずfilenameフォールバックを使う

    contract_date = None
    planned_price = contract_amount = award_rate = None
    bid_method    = None
    amounts       = []

    for ln, t in classified:
        if t == 'date':
            v = RE_REIWA_DATE.match(ln['text'])
            if v:
                ry, mo, dd = int(v.group(1)), int(v.group(2)), int(v.group(3))
                if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
                    contract_date = f'{REIWA_BASE+ry}{mo:02d}{dd:02d}'
        elif t in ('amount_yen', 'amount_plain'):
            try:
                v = float(ln['text'].replace(',', '').replace('円', ''))
                if v >= 100:
                    amounts.append((v, ln['x_min']))
            except:
                pass
        elif t == 'rate':
            try:
                award_rate = float(ln['text'].replace('%', ''))
            except:
                pass
        elif t == 'bid_kw':
            if '随意' in ln['text']:
                bid_method = '随意契約'
            else:
                bid_method = '一般競争入札'
        elif t == 'basis_kw':
            pass  # not used in competitive bid files
        elif t == 'two_amounts':
            parts = ln['text'].replace(',', '').split()
            try:
                amounts.extend([(float(p), ln['x_min']) for p in parts if float(p) >= 100])
            except:
                pass

    if amounts:
        amounts_sorted = sorted(amounts, key=lambda x: x[1])
        vals = [a for a, _ in amounts_sorted]
        if len(vals) >= 2:
            planned_price, contract_amount = vals[0], vals[1]
        else:
            contract_amount = vals[0]

    # contract_name: 左端列 (x < corp_x - 10) の最初の 'other' テキスト
    contract_name = None
    contracting_officer = None
    vendor_name    = None
    vendor_address = None

    for ln, t in sorted(classified, key=lambda x: x[0]['y_global']):
        if t != 'other':
            continue
        txt = ln['text'].strip()
        if not txt:
            continue
        if ln['x_min'] < corp_x - 10:
            if contract_name is None:
                contract_name = txt
            elif contracting_officer is None:
                contracting_officer = txt
        else:
            if vendor_name is None:
                vendor_name = txt
            elif vendor_address is None:
                vendor_address = txt

    if bid_method is None:
        bid_method = '随意契約' if bid_or_zui == 'zui' else '一般競争入札'

    if contract_name is None and contract_amount is None:
        return None

    return {
        'contract_name':      contract_name,
        'contracting_officer': contracting_officer,
        'contract_date':      contract_date,
        'vendor_name':        vendor_name,
        'vendor_address':     vendor_address,
        'corporate_number':   corporate_number,
        'bid_method':         bid_method,
        'contract_basis':     None,
        'planned_price':      planned_price,
        'contract_amount':    contract_amount,
        'award_rate':         award_rate,
        'procurement_type':   procurement_type,
    }


# ── ヘルパー ─────────────────────────────────────────────────

def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def download_pdf(url, dest_path):
    if dest_path.exists() and dest_path.stat().st_size > 500:
        return True
    try:
        req  = urllib.request.Request(url, headers=HEADERS)
        resp = urllib.request.urlopen(req, timeout=20)
        data = resp.read()
        if len(data) < 500:
            return False
        with open(dest_path, 'wb') as f:
            f.write(data)
        return True
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"    404: {url}")
        else:
            print(f"    HTTP {e.code}: {url}")
        return False
    except Exception as ex:
        print(f"    ERROR: {ex}")
        return False


def already_exists(cur, rec, fy):
    corp = rec.get('corporate_number')
    dt   = rec.get('contract_date')
    amt  = rec.get('contract_amount')
    if corp and dt and amt:
        cur.execute("""
            SELECT 1 FROM contracts
            WHERE corporate_number=? AND contract_date=? AND contract_amount=? AND fiscal_year=?
        """, (corp, dt, amt, fy))
        return cur.fetchone() is not None
    return False


def insert_records(conn, records, source_file):
    cur = conn.cursor()
    inserted = skipped_dup = skipped_nodate = 0
    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy is None:
            skipped_nodate += 1
            continue
        if already_exists(cur, rec, fy):
            skipped_dup += 1
            continue
        cur.execute("""
            INSERT INTO contracts (
                fiscal_year, procurement_type, bid_method,
                contract_name, contracting_officer, contract_date,
                vendor_name, vendor_address, corporate_number,
                contract_basis, planned_price, contract_amount, award_rate,
                notes, source_file, source
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            fy, rec.get('procurement_type', '物品役務'), rec.get('bid_method', ''),
            rec.get('contract_name'), rec.get('contracting_officer'),
            rec.get('contract_date'), rec.get('vendor_name'), rec.get('vendor_address'),
            rec.get('corporate_number'), rec.get('contract_basis'),
            rec.get('planned_price'), rec.get('contract_amount'), rec.get('award_rate'),
            None, source_file, 'wcab',
        ))
        inserted += 1
    conn.commit()
    return inserted, skipped_dup, skipped_nodate


# ── メイン ────────────────────────────────────────────────────

def main():
    conn = sqlite3.connect(str(DB_PATH))
    total_inserted = 0
    fy_totals = {}

    print("=== WCAB 失敗ファイル修正再収集 ===\n")

    for fname, procurement_type, bid_or_zui in TARGET_FILES:
        fpath = PDF_DIR / fname
        url   = WCAB_BASE + fname

        # ダウンロード (未DLの場合のみ)
        ok = download_pdf(url, fpath)
        if not ok:
            print(f"  {fname}: ダウンロード失敗 → スキップ")
            continue

        # PDF解析
        lines = extract_pdf_lines(fpath)
        pages = {}
        for ln in lines:
            pages.setdefault(ln['page'], []).append(ln)

        recs = []
        for pg in sorted(pages):
            pg_lines = sorted(pages[pg], key=lambda l: l['y_global'])
            recs.extend(parse_records_from_lines(pg_lines, procurement_type, bid_or_zui))

        if not recs:
            print(f"  {fname}: パース結果 0件 (要調査)")
            continue

        # DB挿入
        ins, dup, nd = insert_records(conn, recs, fname)
        total_inserted += ins

        for rec in recs:
            fy = date_to_fy(rec.get('contract_date'))
            if fy:
                fy_totals[fy] = fy_totals.get(fy, 0) + 1

        print(f"  {fname:<25} parse={len(recs):>3}件  +{ins}新規  dup={dup}  nodate={nd}")

        # FY別内訳
        fy_breakdown = {}
        for rec in recs:
            fy = date_to_fy(rec.get('contract_date'))
            fy_breakdown[fy] = fy_breakdown.get(fy, 0) + 1
        for fy, cnt in sorted(fy_breakdown.items()):
            print(f"    FY{fy}: {cnt}件")
        time.sleep(0.3)

    conn.close()

    print(f"\n合計: +{total_inserted}件新規追加")
    if fy_totals:
        print("FY別合計:")
        for fy, cnt in sorted(fy_totals.items()):
            print(f"  FY{fy}: {cnt}件")

    # DB最終確認
    conn2 = sqlite3.connect(str(DB_PATH))
    c = conn2.cursor()
    print("\n=== DB現状 (wcab) ===")
    c.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,2)
        FROM contracts WHERE source='wcab'
        GROUP BY fiscal_year ORDER BY fiscal_year
    """)
    for r in c.fetchall():
        print(f"  FY{r[0]}: {r[1]:>4}件  {(r[2] or 0):.2f}億円")
    conn2.close()


if __name__ == '__main__':
    main()
