#!/usr/bin/env python3
"""
PAS (pas.ysk.nilim.go.jp) FY2022 空港関連データ WARP補完

WARPスナップショット: 20240601090314 (coll=20240601)
- PASサーバーは複数年度のファイルを保持しているため、
  FY2023向けに使ったスナップショットでFY2022データも取得可能（確認済み）

対象: 8局 × 12ヶ月(202204〜202303) × koji/gyomu
- 202204分はWayback経由で既取得済み → deduplication で自動スキップ
フィルタ: AIRPORT_KW に含まれるもののみ
出力: atc_procurement.db の pas_airport_contracts テーブル
"""

import re
import time
import sqlite3
import urllib.request
import urllib.error
from pathlib import Path

try:
    import xlrd
except ImportError:
    import subprocess, sys
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'xlrd==1.2.0'], check=True)
    import xlrd

PROJECT = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH = PROJECT / 'data/db/atc_procurement.db'
DL_DIR  = PROJECT / 'data/raw/pas_kekka'
DL_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

WARP_TS   = '20240601090314'
WARP_COLL = '20240601'
PAS_BASE  = 'https://www.pas.ysk.nilim.go.jp/contents/KekkaKohyo'
WARP_BASE = f'https://warp.ndl.go.jp/{WARP_COLL}/{WARP_TS}id_'

BUREAUS = [
    ('Tohoku',   '東北'),
    ('Kanto',    '関東'),
    ('Hokuriku', '北陸'),
    ('Chubu',    '中部'),
    ('Kinki',    '近畿'),
    ('Chugoku',  '中国'),
    ('Shikoku',  '四国'),
    ('Kyushu',   '九州'),
]

# FY2022 = 2022年4月〜2023年3月
# 202204 は Wayback 経由で既取得済み（deduplication でスキップされる）
FY2022_MONTHS = [
    202204, 202205, 202206, 202207, 202208, 202209,
    202210, 202211, 202212, 202301, 202302, 202303,
]

AIRPORT_KW = [
    '空港', '滑走路', '誘導路', 'エプロン', '航空灯火', '航空保安', '空港整備',
    '空港護岸', '空港埋立', '着陸帯', '旅客搭乗橋', '除雪機庫', '航空局',
]


def is_airport_related(name):
    return bool(name) and any(kw in name for kw in AIRPORT_KW)


def serial_to_ymd(serial, datemode=0):
    try:
        v = float(serial)
        if v <= 0:
            return None
        t = xlrd.xldate_as_tuple(v, datemode)
        if t[0] == 0:
            return None
        return f'{t[0]:04d}{t[1]:02d}{t[2]:02d}'
    except Exception:
        return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def yyyymm_to_fy(yyyymm):
    y, m = int(str(yyyymm)[:4]), int(str(yyyymm)[4:])
    return y if m >= 4 else y - 1


def download_warp(bureau_en, fname, dest_path):
    if dest_path.exists() and dest_path.stat().st_size > 5000:
        return True
    orig_url = f'{PAS_BASE}/{bureau_en}/{fname}'
    warp_url = f'{WARP_BASE}/{orig_url}'
    req = urllib.request.Request(warp_url, headers=HEADERS)
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        data = resp.read()
        if len(data) < 1000:
            return False
        with open(dest_path, 'wb') as f:
            f.write(data)
        return True
    except urllib.error.HTTPError as e:
        if e.code not in (404,):
            print(f"  HTTP {e.code}: {bureau_en}/{fname}")
        return False
    except Exception as e:
        print(f"  ERR: {bureau_en}/{fname}: {e}")
        return False


def parse_xls(fpath, file_type, bureau_ja, yyyymm):
    try:
        wb = xlrd.open_workbook(str(fpath))
    except Exception as e:
        print(f"  ERROR opening {fpath.name}: {e}")
        return []

    ws = wb.sheet_by_index(0)
    dm = wb.datemode
    records = []

    for r in range(4, ws.nrows):
        row = [ws.cell_value(r, c) if c < ws.ncols else '' for c in range(19)]
        name_raw = str(row[1]).strip()
        if not name_raw or name_raw in ('None', '0.0', ''):
            continue
        if not is_airport_related(name_raw):
            continue

        bid_date   = serial_to_ymd(row[2], dm)
        award_date = serial_to_ymd(row[3], dm)

        if not bid_date:
            bid_date = f'{str(yyyymm)[:4]}{str(yyyymm)[4:]}01'

        fy = date_to_fy(bid_date) or yyyymm_to_fy(yyyymm)

        def safe_float(v):
            try:
                f = float(v)
                return f if f > 0 else None
            except Exception:
                return None

        work_type   = str(row[4]).strip() or None
        bid_method  = str(row[5]).strip() or None
        vendor_raw  = str(row[7]).strip()
        vendor_name = vendor_raw if vendor_raw and vendor_raw not in ('None', '') else None

        records.append({
            'fiscal_year':   fy,
            'bureau':        bureau_ja,
            'file_name':     fpath.name,
            'file_type':     file_type,
            'contract_name': name_raw,
            'bid_date':      bid_date,
            'award_date':    award_date,
            'work_type':     work_type if work_type != 'None' else None,
            'bid_method':    bid_method if bid_method != 'None' else None,
            'vendor_name':   vendor_name,
            'planned_price': safe_float(row[8]),
            'bid_amount':    safe_float(row[9]),
            'award_amount':  safe_float(row[11]),
            'notes':         f'warp:{WARP_TS[:8]}',
        })
    return records


def get_existing_keys(conn):
    cur = conn.cursor()
    try:
        cur.execute("SELECT bureau || '/' || file_name FROM pas_airport_contracts")
        return set(r[0] for r in cur.fetchall())
    except Exception:
        return set()


def insert_records(conn, records):
    if not records:
        return 0
    cur = conn.cursor()
    cur.executemany("""
        INSERT INTO pas_airport_contracts
          (fiscal_year, bureau, file_name, file_type, contract_name,
           bid_date, award_date, work_type, bid_method, vendor_name,
           planned_price, bid_amount, award_amount, notes)
        VALUES
          (:fiscal_year, :bureau, :file_name, :file_type, :contract_name,
           :bid_date, :award_date, :work_type, :bid_method, :vendor_name,
           :planned_price, :bid_amount, :award_amount, :notes)
    """, records)
    conn.commit()
    return len(records)


def main():
    conn = sqlite3.connect(str(DB_PATH))
    existing = get_existing_keys(conn)
    print(f"既存キー数: {len(existing)}")

    total_dl = total_ins = total_skip = total_404 = 0
    bureau_stats = {}

    for bureau_en, bureau_ja in BUREAUS:
        bureau_ins = 0
        for yyyymm in FY2022_MONTHS:
            for ftype in ['koji', 'gyomu']:
                fname = f'{ftype}{yyyymm}.xls'
                local = f'{bureau_en}_{fname}'
                key   = f'{bureau_ja}/{local}'

                if key in existing:
                    total_skip += 1
                    continue

                dest = DL_DIR / local
                ok = download_warp(bureau_en, fname, dest)
                if not ok:
                    total_404 += 1
                    continue
                total_dl += 1

                recs = parse_xls(dest, ftype, bureau_ja, yyyymm)
                if recs:
                    n = insert_records(conn, recs)
                    bureau_ins += n
                    total_ins += n

                time.sleep(0.3)

        if bureau_ins:
            print(f'  {bureau_ja}: {bureau_ins}件')
        bureau_stats[bureau_ja] = bureau_ins

    conn.close()

    print(f'\n=== FY2022 WARP補完 完了 ===')
    print(f'ダウンロード: {total_dl}ファイル')
    print(f'新規挿入:     {total_ins}件')
    print(f'スキップ:     {total_skip}件')
    print(f'404/失敗:     {total_404}件')

    # Summary
    conn2 = sqlite3.connect(str(DB_PATH))
    cur2 = conn2.cursor()
    print('\n=== FY2022 空港データ サマリ ===')
    cur2.execute("""
        SELECT bureau, file_type, COUNT(*) as cnt,
               ROUND(SUM(COALESCE(bid_amount,0))/1e8, 2) as bid_amt,
               ROUND(SUM(COALESCE(award_amount,0))/1e8, 2) as award_amt
        FROM pas_airport_contracts
        WHERE fiscal_year = 2022
        GROUP BY bureau, file_type ORDER BY bureau, file_type
    """)
    print(f'{"局":<8} {"種別":<6} {"件数":>6} {"入札額(億)":>12} {"落札額(億)":>12}')
    print('-' * 48)
    total_cnt = total_bid = total_award = 0
    for row in cur2.fetchall():
        b, ft, cnt, bid, award = row
        print(f'{b:<8} {ft:<6} {cnt:>6} {(bid or 0):>12.2f} {(award or 0):>12.2f}')
        total_cnt += cnt
        total_bid += (bid or 0)
        total_award += (award or 0)
    print('-' * 48)
    print(f'{"合計":<8} {"":6} {total_cnt:>6} {total_bid:>12.2f} {total_award:>12.2f}')

    print('\n=== 全FY比較 ===')
    cur2.execute("""
        SELECT fiscal_year, COUNT(*) as cnt,
               ROUND(SUM(COALESCE(award_amount,0))/1e8, 2) as award_amt
        FROM pas_airport_contracts
        GROUP BY fiscal_year ORDER BY fiscal_year
    """)
    for row in cur2.fetchall():
        print(f'  FY{row[0]}: {row[1]}件 / {row[2]}億円')
    conn2.close()


if __name__ == '__main__':
    main()
