"""
航空局本局 XLSX FY2013-2019 → atc_procurement.db 挿入スクリプト

ダウンロード済みファイル (data/cache/honbu/):
  001057801_fy2013.xlsx  (平成25年度 / H25 / FY2013)
  001082638_fy2014.xlsx  (平成26年度 / H26 / FY2014)
  001133657_fy2015.xlsx  (平成27年度 / H27 / FY2015)
  001190907_fy2016.xlsx  (平成28年度 / H28 / FY2016)
  001271137_fy2017.xlsx  (平成29年度 / H29 / FY2017)
  001382782_fy2018.xlsx  (平成30年度 / H30 / FY2018)
  001339479_fy2019.xlsx  (令和元年度 / R1 / FY2019)

Usage:
    python collect_honbu_xlsx_fy2013_2019.py [--dry-run]
"""

import sqlite3
import os
import re
import sys
import datetime
import warnings
import argparse
import openpyxl
from openpyxl.utils.datetime import from_excel
from pathlib import Path

try:
    import xlrd
    HAS_XLRD = True
except ImportError:
    HAS_XLRD = False

warnings.filterwarnings("ignore")

DB_PATH = "C:/Users/Percy Iwai/Documents/JAXA_procurement/data/db/atc_procurement.db"
PROJECT = Path("C:/Users/Percy Iwai/Documents/JAXA_procurement")

FILES = {
    # FY2013: original is VelvetSweatshop-encrypted → use pre-decrypted version
    2013: (PROJECT / "data/cache/honbu/001057801_fy2013_dec.xlsx", "001057801.xlsx"),
    2014: (PROJECT / "data/cache/honbu/001082638_fy2014.xlsx", "001082638.xlsx"),
    2015: (PROJECT / "data/cache/honbu/001133657_fy2015.xlsx", "001133657.xlsx"),
    2016: (PROJECT / "data/cache/honbu/001190907_fy2016.xlsx", "001190907.xlsx"),
    2017: (PROJECT / "data/cache/honbu/001271137_fy2017.xlsx", "001271137.xlsx"),
    2018: (PROJECT / "data/cache/honbu/001382782_fy2018.xlsx", "001382782.xlsx"),
    2019: (PROJECT / "data/cache/honbu/001339479_fy2019.xlsx", "001339479.xlsx"),
}

# Sheet names → (procurement_type, bid_method)
SHEET_MAP = {
    "物品役務調達（競争入札）": ("物品役務", "一般競争入札"),
    "物品役務調達（随意契約）": ("物品役務", "随意契約"),
    "公共工事調達（競争入札）": ("建設工事", "一般競争入札"),
    "公共工事調達（随意契約）": ("建設工事", "随意契約"),
    # Older sheet names (H25-H27 era)
    "物品・役務の調達（競争入札）": ("物品役務", "一般競争入札"),
    "物品・役務の調達（随意契約）": ("物品役務", "随意契約"),
    "工事の調達（競争入札）": ("建設工事", "一般競争入札"),
    "工事の調達（随意契約）": ("建設工事", "随意契約"),
}

HEADER_KEYWORDS = {
    "contract_name":        ["名称及び数量", "公共工事の名称", "物品役務の名称", "名称"],
    "contracting_officer":  ["契約担当官", "氏名並びにその所属", "担当官"],
    "contract_date":        ["締結した日", "契約日"],
    "vendor":               ["相手方の称号", "相手方の氏名", "相手方"],
    "corporate_number":     ["法人番号"],
    "contract_basis":       ["随意契約の根拠", "競争入札", "競争種別", "根拠法令"],
    "planned_price":        ["予定価格"],
    "contract_amount":      ["契約金額"],
    "award_rate":           ["落札率"],
    "notes":                ["備考"],
    "reemployed_officers":  ["再就職"],
}

# 月名セパレータ行パターン
MONTH_SEP_PAT = re.compile(r'^[１２３４５６７８９０一二三四五六七八九十\d]{1,2}月$')


def normalize_date(val) -> str | None:
    if val is None:
        return None
    if isinstance(val, (datetime.datetime, datetime.date)):
        return val.strftime("%Y%m%d")
    if isinstance(val, (int, float)):
        try:
            dt = from_excel(int(val))
            return dt.strftime("%Y%m%d")
        except Exception:
            return None
    s = str(val).strip()
    if not s:
        return None
    # YYYY-MM-DD or YYYY/MM/DD
    m = re.match(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        return f"{m.group(1)}{int(m.group(2)):02d}{int(m.group(3)):02d}"
    # 平成YY年MM月DD日 → convert
    m = re.match(r"平成(\d{1,2})年(\d{1,2})月(\d{1,2})日", s)
    if m:
        y, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{1988 + y}{mo:02d}{dd:02d}"
    # 令和NN年MM月DD日
    m = re.match(r"令和(\d{1,2})年(\d{1,2})月(\d{1,2})日", s)
    if m:
        y, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{2018 + y}{mo:02d}{dd:02d}"
    # Reiwa short: "R{yy}.{mm}.{dd}" or "{yy}.{mm}.{dd}"
    m = re.match(r"^[Rr]?(\d{1,2})\.(\d{1,2})\.(\d{1,2})$", s)
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f"{2018 + ry}{mo:02d}{dd:02d}"
    # Heisei short: "H{yy}.{mm}.{dd}" or "h{yy}...."
    m = re.match(r"^[Hh](\d{1,2})\.(\d{1,2})\.(\d{1,2})$", s)
    if m:
        hy, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= hy <= 31 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f"{1988 + hy}{mo:02d}{dd:02d}"
    # YY.MM.DD where YY could be Heisei (large) or Reiwa (small)
    m = re.match(r"^(\d{1,2})\.(\d{1,2})\.(\d{1,2})$", s)
    if m:
        yy, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= dd <= 31:
            if yy >= 20:  # Heisei 20-31
                return f"{1988 + yy}{mo:02d}{dd:02d}"
            else:  # Reiwa 1-20
                return f"{2018 + yy}{mo:02d}{dd:02d}"
    return None


def date_to_fy(ds: str) -> int | None:
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def normalize_amount(val) -> float | None:
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val) if val != 0 else None
    s = str(val).strip().replace(",", "").replace("円", "").replace("¥", "")
    if not s or s in ("-", "－", "―", "—"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def split_vendor(cell_val) -> tuple[str, str]:
    if cell_val is None:
        return ("", "")
    s = str(cell_val).strip()
    if "\n" in s:
        parts = s.split("\n", 1)
        return (parts[0].strip(), parts[1].strip())
    return (s, "")


def build_col_map(headers: list) -> dict:
    col_map = {}
    for idx, h in enumerate(headers):
        if h is None:
            continue
        h_str = str(h).strip()
        for field, keywords in HEADER_KEYWORDS.items():
            if field not in col_map and any(kw in h_str for kw in keywords):
                col_map[field] = idx
    return col_map


def find_header_row(ws) -> int | None:
    """ヘッダー行を自動検出（最初に「名称」「契約金額」が現れる行）"""
    for row_idx, row in enumerate(ws.iter_rows(values_only=True)):
        row_strs = [str(c or "").strip() for c in row]
        if any("契約金額" in s or "名称" in s for s in row_strs):
            return row_idx
    return None


def parse_sheet(ws, fiscal_year_hint: int, procurement_type: str,
                bid_method: str, source_file: str) -> list[dict]:
    rows = list(ws.iter_rows(values_only=True))
    if len(rows) < 3:
        return []

    # Try row 0 first, then auto-detect
    header_idx = 0
    headers = [str(c) if c is not None else None for c in rows[0]]
    col_map = build_col_map(headers)

    if "contract_name" not in col_map or "contract_amount" not in col_map:
        # Try row 1
        if len(rows) > 1:
            headers = [str(c) if c is not None else None for c in rows[1]]
            col_map = build_col_map(headers)
            header_idx = 1

    if "contract_name" not in col_map or "contract_amount" not in col_map:
        # Auto-detect
        hdr = find_header_row(ws)
        if hdr is not None:
            headers = [str(c) if c is not None else None for c in rows[hdr]]
            col_map = build_col_map(headers)
            header_idx = hdr

    if "contract_name" not in col_map:
        print(f"  [WARN] 列マッピング失敗: {source_file} ({ws.title})")
        print(f"  ヘッダー: {headers[:12]}")
        return []

    records = []
    skipped_sep = 0
    data_start = header_idx + 2  # skip header + 1 blank/total row
    for row in rows[data_start:]:
        def cell(field):
            idx = col_map.get(field)
            return row[idx] if idx is not None and idx < len(row) else None

        contract_name = str(cell("contract_name") or "").strip()
        if not contract_name or contract_name in ("None", "合計", "小計", "nan"):
            continue
        if MONTH_SEP_PAT.match(contract_name):
            skipped_sep += 1
            continue

        contract_date_raw = normalize_date(cell("contract_date"))
        vendor_raw = cell("vendor")
        vendor_name, vendor_address = split_vendor(vendor_raw)
        contracting_officer = str(cell("contracting_officer") or "").strip()
        corporate_number = str(cell("corporate_number") or "").strip()
        corporate_number = corporate_number if re.match(r'^\d{13}$', corporate_number) else None
        contract_basis = str(cell("contract_basis") or "").strip()
        planned_price = normalize_amount(cell("planned_price"))
        contract_amount = normalize_amount(cell("contract_amount"))
        award_rate = normalize_amount(cell("award_rate"))
        notes = str(cell("notes") or "").strip() or None
        reemployed = str(cell("reemployed_officers") or "").strip() or None

        if contract_date_raw:
            fy = date_to_fy(contract_date_raw)
            if fy is None:
                fy = fiscal_year_hint
        else:
            fy = fiscal_year_hint

        records.append({
            "fiscal_year":         fy,
            "procurement_type":    procurement_type,
            "bid_method":          bid_method,
            "contract_name":       contract_name or None,
            "contracting_officer": contracting_officer or None,
            "contract_date":       contract_date_raw,
            "vendor_name":         vendor_name or None,
            "vendor_address":      vendor_address or None,
            "corporate_number":    corporate_number,
            "contract_basis":      contract_basis or None,
            "planned_price":       planned_price,
            "contract_amount":     contract_amount,
            "award_rate":          award_rate,
            "notes":               notes,
            "reemployed_officers": reemployed,
            "source_file":         source_file,
            "source":              None,
            "organization":        None,
        })

    if skipped_sep:
        print(f"    月名セパレータ {skipped_sep}件スキップ")
    return records


def parse_xls_sheet(ws_xls, wb_xls, fiscal_year_hint: int, procurement_type: str,
                    bid_method: str, source_file: str) -> list[dict]:
    """xlrd で XLS シートをパース"""
    if ws_xls.nrows < 3:
        return []

    # Convert to list of rows (as values)
    rows = []
    for ri in range(ws_xls.nrows):
        row = []
        for ci in range(ws_xls.ncols):
            cell = ws_xls.cell(ri, ci)
            if cell.ctype == 3:  # XL_CELL_DATE
                try:
                    tup = xlrd.xldate_as_tuple(cell.value, wb_xls.datemode)
                    if tup[0] > 1900:  # Valid date
                        dt = datetime.datetime(*tup[:6])
                        row.append(dt)
                    else:
                        row.append(None)
                except Exception:
                    row.append(None)
            elif cell.ctype == 0:  # XL_CELL_EMPTY
                row.append(None)
            else:
                row.append(cell.value)
        rows.append(tuple(row))

    # Find header row (with col_map)
    header_idx = 0
    col_map = {}
    for ri in range(min(5, len(rows))):
        headers = [str(c) if c is not None else None for c in rows[ri]]
        col_map = build_col_map(headers)
        if "contract_name" in col_map and ("contract_amount" in col_map or "planned_price" in col_map):
            header_idx = ri
            break

    if "contract_name" not in col_map:
        print(f"  [WARN] XLS列マッピング失敗: {source_file}")
        return []

    records = []
    skipped_sep = 0
    data_start = header_idx + 2
    for row in rows[data_start:]:
        def cell(field):
            idx = col_map.get(field)
            return row[idx] if idx is not None and idx < len(row) else None

        contract_name = str(cell("contract_name") or "").strip()
        if not contract_name or contract_name in ("None", "合計", "小計", "nan", ""):
            continue
        if MONTH_SEP_PAT.match(contract_name):
            skipped_sep += 1
            continue

        contract_date_raw = normalize_date(cell("contract_date"))
        vendor_raw = cell("vendor")
        vendor_name, vendor_address = split_vendor(vendor_raw)
        contracting_officer = str(cell("contracting_officer") or "").strip()
        corporate_number = str(cell("corporate_number") or "").strip()
        corporate_number = corporate_number if re.match(r'^\d{13}$', corporate_number) else None
        contract_basis = str(cell("contract_basis") or "").strip()
        planned_price = normalize_amount(cell("planned_price"))
        contract_amount = normalize_amount(cell("contract_amount"))
        award_rate = normalize_amount(cell("award_rate"))
        notes = str(cell("notes") or "").strip() or None
        reemployed = str(cell("reemployed_officers") or "").strip() or None

        if contract_date_raw:
            fy = date_to_fy(contract_date_raw)
            if fy is None:
                fy = fiscal_year_hint
        else:
            fy = fiscal_year_hint

        records.append({
            "fiscal_year":         fy,
            "procurement_type":    procurement_type,
            "bid_method":          bid_method,
            "contract_name":       contract_name or None,
            "contracting_officer": contracting_officer or None,
            "contract_date":       contract_date_raw,
            "vendor_name":         vendor_name or None,
            "vendor_address":      vendor_address or None,
            "corporate_number":    corporate_number,
            "contract_basis":      contract_basis or None,
            "planned_price":       planned_price,
            "contract_amount":     contract_amount,
            "award_rate":          award_rate,
            "notes":               notes,
            "reemployed_officers": reemployed,
            "source_file":         source_file,
            "source":              None,
            "organization":        None,
        })

    if skipped_sep:
        print(f"    月名セパレータ {skipped_sep}件スキップ")
    return records


INSERT_SQL = """
INSERT INTO contracts
  (fiscal_year, procurement_type, bid_method, contract_name,
   contracting_officer, contract_date, vendor_name, vendor_address,
   corporate_number, contract_basis, planned_price, contract_amount,
   award_rate, notes, reemployed_officers, source_file, source, organization)
VALUES
  (:fiscal_year, :procurement_type, :bid_method, :contract_name,
   :contracting_officer, :contract_date, :vendor_name, :vendor_address,
   :corporate_number, :contract_basis, :planned_price, :contract_amount,
   :award_rate, :notes, :reemployed_officers, :source_file, :source, :organization)
"""


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    total_inserted = 0

    for fy_hint, (path, source_file_id) in sorted(FILES.items()):
        if not path.exists():
            print(f"[SKIP] {path} not found")
            continue

        # 重複チェック
        existing = cur.execute(
            "SELECT COUNT(*) FROM contracts WHERE source_file=?", (source_file_id,)
        ).fetchone()[0]
        if existing > 0:
            print(f"[SKIP] FY{fy_hint} {source_file_id} already in DB ({existing}件)")
            continue

        print(f"\n=== FY{fy_hint}: {source_file_id} ===")

        # Detect XLS vs XLSX
        with open(str(path), 'rb') as f:
            magic = f.read(4)
        is_xls = magic == b'\xd0\xcf\x11\xe0'  # OLE compound doc = XLS

        file_records = []

        if is_xls:
            # Use xlrd for old XLS format
            if not HAS_XLRD:
                print(f"  [ERROR] xlrd not available for XLS file")
                continue
            print(f"  [XLS format] using xlrd")
            try:
                wb_xls = xlrd.open_workbook(str(path))
            except Exception as e:
                print(f"  [ERROR] xlrd failed: {e}")
                continue
            print(f"  シート: {wb_xls.sheet_names()}")
            for sheet_name, (p_type, b_method) in SHEET_MAP.items():
                if sheet_name not in wb_xls.sheet_names():
                    continue
                ws_xls = wb_xls.sheet_by_name(sheet_name)
                recs = parse_xls_sheet(ws_xls, wb_xls, fy_hint, p_type, b_method, source_file_id)
                amt = sum(r["contract_amount"] or 0 for r in recs)
                print(f"  {sheet_name}: {len(recs)}件  {amt/1e8:.1f}億")
                file_records.extend(recs)
        else:
            try:
                wb = openpyxl.load_workbook(str(path), data_only=True)
            except Exception as e:
                print(f"  [ERROR] openpyxl failed: {e}")
                continue

            print(f"  シート: {wb.sheetnames}")

            for sheet_name, (p_type, b_method) in SHEET_MAP.items():
                if sheet_name not in wb.sheetnames:
                    continue
                ws = wb[sheet_name]
                recs = parse_sheet(ws, fy_hint, p_type, b_method, source_file_id)
                amt = sum(r["contract_amount"] or 0 for r in recs)
                print(f"  {sheet_name}: {len(recs)}件  {amt/1e8:.1f}億")
                file_records.extend(recs)

        # FY分布
        fy_dist = {}
        for r in file_records:
            fy = r["fiscal_year"]
            fy_dist[fy] = fy_dist.get(fy, 0) + 1
        print(f"  FY分布: {dict(sorted(fy_dist.items()))}")

        # 金額NULLの確認
        null_amt = sum(1 for r in file_records if r["contract_amount"] is None)
        if null_amt:
            print(f"  [WARN] 金額NULL: {null_amt}件")

        if not args.dry_run and file_records:
            cur.executemany(INSERT_SQL, file_records)
            con.commit()
            total_inserted += len(file_records)
            print(f"  → {len(file_records)}件挿入完了")
        elif args.dry_run:
            print(f"  [DRY-RUN] {len(file_records)}件 (挿入なし)")

    con.close()
    print(f"\n=== 合計挿入: {total_inserted}件 ===")

    # 結果確認
    con = sqlite3.connect(DB_PATH)
    rows = con.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(contract_amount)/1e8, 1)
        FROM contracts GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall()
    print("\n=== DB最終サマリー ===")
    for r in rows:
        print(f"  FY{r[0]}: {r[1]}件  {r[2]}億")
    con.close()


if __name__ == "__main__":
    main()
