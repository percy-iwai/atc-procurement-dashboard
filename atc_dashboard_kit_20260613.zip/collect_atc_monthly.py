#!/usr/bin/env python3
"""
東京航空局(tcab)・大阪航空局(wcab)の月次PDFを収集・パース・DB追加

Usage:
    python collect_atc_monthly.py [--dry-run] [--source tcab|wcab|both]
"""

import re
import os
import sys
import time
import sqlite3
import argparse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    print("ERROR: PyMuPDF not installed. Run: pip install pymupdf")
    sys.exit(1)

# ============================================================
# Paths
# ============================================================
PROJECT = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR  = PROJECT / 'data/pdfs/atc'
PDF_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}
REIWA_BASE = 2018

# ============================================================
# URL lists
# ============================================================

def tcab_urls():
    """r04/r05/r06 bid+zui  → FY2022/2023/2024"""
    urls = []
    for yy, reiwa_year in [('04', 4), ('05', 5), ('06', 6)]:
        for mm in range(1, 13):
            for sfx in ('bid', 'zui'):
                url = f'https://www.cab.mlit.go.jp/tcab/files/r{yy}_{mm:02d}_{sfx}.pdf'
                urls.append(('tcab', url, reiwa_year, mm, sfx))
    return urls

def wcab_urls_from_page():
    """WCAB公表ページから全PDFリンクを取得"""
    page_url = 'https://www.cab.mlit.go.jp/wcab/contract/published.html'
    req = urllib.request.Request(page_url, headers=HEADERS)
    try:
        resp = urllib.request.urlopen(req, timeout=15)
        html = resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        print(f"WARN: could not fetch WCAB page: {e}")
        return []

    raw = re.findall(r'href="(https?://www\.cab\.mlit\.go\.jp/wcab/file/[^"]+\.pdf)"',
                     html, re.IGNORECASE)
    urls = []
    for url in sorted(set(raw)):
        fname = url.split('/')[-1].lower()
        if fname == 'f4798e0f52ae4ac1724c725e86d4bae4e18db56b.pdf':
            continue  # mysterious hash file, skip
        urls.append(('wcab', url))
    return urls

# ============================================================
# Download helper
# ============================================================

def download_pdf(url, dest_path, max_retries=2):
    if dest_path.exists() and dest_path.stat().st_size > 1000:
        return True  # already cached
    for attempt in range(max_retries + 1):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            resp = urllib.request.urlopen(req, timeout=20)
            data = resp.read()
            with open(dest_path, 'wb') as f:
                f.write(data)
            return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return False  # doesn't exist
            if attempt < max_retries:
                time.sleep(2)
        except Exception:
            if attempt < max_retries:
                time.sleep(2)
    return False

# ============================================================
# PDF text extraction
# ============================================================

RE_DATE_PREFIX = re.compile(r'^(令和\d+年\d+月\d+日)(.+)$')

def _split_date_prefix(text, chars_list, x_min):
    """
    "令和6年12月17日東光電気工業（株）" のような日付+テキスト混在を分割。
    Returns list of (text, x_min, x_max) tuples.
    """
    m = RE_DATE_PREFIX.match(text)
    if not m:
        return [(text, x_min, x_min + len(text) * 8)]

    date_part = m.group(1)
    rest_part = m.group(2)

    # Estimate x split: date_part chars end where rest_part begins
    date_len = len(date_part)
    if len(chars_list) >= date_len:
        split_x = chars_list[date_len][0]  # x of first char after date
        date_x_max = split_x - 1
    else:
        date_x_max = x_min + date_len * 8

    rest_x_min = date_x_max + 1
    rest_x_max = rest_x_min + len(rest_part) * 8

    return [
        (date_part, x_min, date_x_max),
        (rest_part, rest_x_min, rest_x_max),
    ]


def extract_pdf_lines(pdf_path):
    """
    XMLモードでchar単位に抽出してカラム分離を保証する。
    同一y-line内でx方向に離れた文字グループは別エントリとして返す。

    Returns list of:
      {'page': int, 'x_min': float, 'x_max': float,
       'y_global': float,  # page*1000 + y_center
       'y_page': float,    # raw y_center on page
       'text': str}
    """
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening PDF: {e}")
        return []

    result = []
    for page_num, page in enumerate(doc):
        try:
            xml_str = page.get_text('xml')
            root = ET.fromstring(xml_str)
        except Exception:
            continue

        for line in root.findall('.//line'):
            # Extract individual chars with x positions
            chars_with_x = []
            for char in line.findall('.//char'):
                c = char.get('c', '')
                if not c:
                    continue
                try:
                    cx = float(char.get('x', '0'))
                    # y from the line's bbox
                    bbox = line.get('bbox', '')
                    parts = bbox.split()
                    if len(parts) >= 4:
                        y0, y1 = float(parts[1]), float(parts[3])
                    else:
                        y0 = y1 = 0.0
                    chars_with_x.append((cx, (y0 + y1) / 2, c))
                except Exception:
                    continue

            if not chars_with_x:
                # Fallback: use the line's text attr and bbox
                text = line.get('text', '').strip()
                if not text:
                    continue
                bbox = line.get('bbox', '')
                try:
                    x0, y0, x1, y1 = [float(v) for v in bbox.split()]
                except Exception:
                    continue
                y_center = (y0 + y1) / 2
                result.append({
                    'page': page_num,
                    'x_min': x0,
                    'x_max': x1,
                    'y_page': y_center,
                    'y_global': page_num * 1000 + y_center,
                    'text': text,
                })
                continue

            # Group chars into column-segments: split when x gap > COL_GAP_THRESHOLD
            COL_GAP = 12.0  # pt; gaps bigger than this = different column
            segments = []
            seg_chars = [chars_with_x[0]]
            for i in range(1, len(chars_with_x)):
                prev_x = chars_with_x[i - 1][0]
                curr_x = chars_with_x[i][0]
                if curr_x - prev_x > COL_GAP:
                    segments.append(seg_chars)
                    seg_chars = [chars_with_x[i]]
                else:
                    seg_chars.append(chars_with_x[i])
            segments.append(seg_chars)

            # Convert each segment to result entries
            # Also split segments that contain "date+rest" (e.g. "令和6年12月17日東光電気")
            y_center = chars_with_x[0][1]
            for seg in segments:
                seg_text = ''.join(c for _, _, c in seg).strip()
                if not seg_text:
                    continue
                x_min = seg[0][0]
                x_max = seg[-1][0] + 8  # approx char width

                # Post-split: if text starts with a complete 令和 date followed by more
                # text, split into [date_part, rest_part]
                sub_segs = _split_date_prefix(seg_text, seg, x_min)
                for sub_text, sub_x_min, sub_x_max in sub_segs:
                    result.append({
                        'page': page_num,
                        'x_min': sub_x_min,
                        'x_max': sub_x_max,
                        'y_page': y_center,
                        'y_global': page_num * 1000 + y_center,
                        'text': sub_text,
                    })

    doc.close()
    return result

# ============================================================
# Content classification
# ============================================================

RE_REIWA_DATE  = re.compile(r'^令和(\d+)年(\d+)月(\d+)日$')
RE_REIWA_PERIOD = re.compile(r'令和\d+年\d+月\d+日.*[～~]')
RE_CORP_NUM    = re.compile(r'^\d{13}$')
RE_AMOUNT_YEN  = re.compile(r'^[\d,]+円$')
RE_AMOUNT_NUM  = re.compile(r'^[\d,]+$')
RE_RATE_PCT    = re.compile(r'^[\d.]+%$')
RE_RATE_NUM    = re.compile(r'^[\d.]+$')
RE_TWOAMOUNTS  = re.compile(r'^([\d,]+)\s+([\d,]+)$')  # "1,234 5,678" pattern
RE_PAGE_HEADER = re.compile(r'公共調達の適正化|契約の相手方の商号|公共工事の名称|物品役務の名称|契約担当官|一般競争入札.*指名競争|又は名称及び住所|随意契約によることとした')

def is_page_header(text):
    return bool(RE_PAGE_HEADER.search(text)) or len(text) > 80

def classify_line(text):
    """Return semantic type of line text."""
    if RE_REIWA_DATE.match(text):
        return 'date'
    if RE_REIWA_PERIOD.search(text):
        return 'period'
    if RE_CORP_NUM.match(text):
        return 'corp_num'
    if RE_AMOUNT_YEN.match(text):
        return 'amount_yen'
    t_clean = text.replace(',', '').replace('円', '').strip()
    if RE_TWOAMOUNTS.match(text.replace(',', '')):
        return 'two_amounts'
    if RE_AMOUNT_NUM.match(text.replace(',', '')) and len(text.replace(',', '')) >= 4:
        try:
            v = float(text.replace(',', ''))
            if v >= 100:
                return 'amount_plain'
        except:
            pass
    if RE_RATE_PCT.match(text):
        return 'rate'
    if RE_RATE_NUM.match(text):
        try:
            v = float(text)
            if 0.0 <= v <= 100.0 and '.' in text:
                return 'rate'
        except:
            pass
    if '競争入札' in text or '指名競争' in text:
        return 'bid_kw'
    if '随意契約' in text and len(text) < 30:
        return 'bid_kw'  # short = bid_method
    if '会計法' in text or '規定を適用' in text or '随意契約を締結' in text:
        return 'basis_kw'
    if is_page_header(text):
        return 'header'
    return 'other'

# ============================================================
# Detect procurement_type from page header
# ============================================================

def detect_page_type(lines):
    """
    From lines on a page, detect whether it's 物品役務 or 建設工事.
    """
    for ln in lines:
        t = ln['text']
        if '物品役務' in t and ('情報の公表' in t or '競争' in t or '随意' in t):
            return '物品役務'
        if '公共工事' in t and '情報の公表' in t:
            return '建設工事'
    return None  # unknown, will try to infer later

# ============================================================
# Record parsing using corp_num as anchors
# ============================================================

def parse_records_from_lines(lines, procurement_type, bid_method_from_filename=None):
    """
    lines: all lines from a PAGE (not global), sorted by y_global.
    procurement_type: '物品役務' or '建設工事'
    bid_method_from_filename: 'bid' or 'zui' (from filename)
    Returns list of record dicts.
    """
    # Filter out page headers (y_page < 100) and very-top header text
    data_lines = [ln for ln in lines if ln['y_page'] > 95 and not is_page_header(ln['text'])]
    if not data_lines:
        return []

    # Find corporate_number lines as record anchors
    corp_lines = [ln for ln in data_lines if classify_line(ln['text']) == 'corp_num']
    if not corp_lines:
        return []

    corp_lines_sorted = sorted(corp_lines, key=lambda l: l['y_global'])

    records = []
    for idx, corp_ln in enumerate(corp_lines_sorted):
        # Define y-range for this record
        # Lower bound: midpoint with previous corp_num (or start of page data)
        if idx == 0:
            y_low = min(l['y_global'] for l in data_lines) - 1
        else:
            y_low = (corp_lines_sorted[idx - 1]['y_global'] + corp_ln['y_global']) / 2

        # Upper bound: midpoint with next corp_num (or end of page data)
        if idx == len(corp_lines_sorted) - 1:
            y_high = max(l['y_global'] for l in data_lines) + 1
        else:
            y_high = (corp_ln['y_global'] + corp_lines_sorted[idx + 1]['y_global']) / 2

        # Collect all lines in this y-range
        rec_lines = sorted(
            [ln for ln in data_lines if y_low <= ln['y_global'] <= y_high],
            key=lambda l: (l['x_min'], l['y_global'])
        )

        if not rec_lines:
            continue

        rec = extract_fields(rec_lines, corp_ln, procurement_type, bid_method_from_filename)
        if rec:
            records.append(rec)

    return records

def extract_fields(rec_lines, corp_ln, procurement_type, bid_method_from_filename):
    """
    Given lines belonging to one record and the corp_num anchor line,
    extract field values.
    """
    corp_x = corp_ln['x_min']  # x-position of corporate_number column

    # Sort lines by x_min for column assignment
    lines_by_x = sorted(rec_lines, key=lambda l: l['x_min'])

    # Classify lines
    classified = [(ln, classify_line(ln['text'])) for ln in rec_lines]

    # ---- Corporate number ----
    corporate_number = corp_ln['text'].strip()

    # ---- Contract date ----
    # The 令和 date that is NOT a period line (no ～).
    # 建設工事 pages have period-start dates at x≈25 (leftmost) AND contract dates at x≈270.
    # Sort by x descending to prefer the rightmost date (= contract date column).
    contract_date = None
    date_candidates = [(ln, cls) for ln, cls in classified if cls == 'date']
    for ln, cls in sorted(date_candidates, key=lambda t: t[0]['x_min'], reverse=True):
        d = parse_reiwa_date_str(ln['text'])
        if d:
            contract_date = d
            break

    # ---- Amounts ----
    planned_price = None
    contract_amount = None
    award_rate = None

    # Two-amounts line (e.g. "9,999,000 8,888,000")
    for ln, cls in classified:
        if cls == 'two_amounts':
            m = RE_TWOAMOUNTS.match(ln['text'].replace(',', ''))
            if m:
                planned_price = float(m.group(1))
                contract_amount = float(m.group(2))
            break

    if planned_price is None:
        # Sort amount lines by x position; leftmost = planned, next = contract
        amount_lines = [(ln, cls) for ln, cls in classified if cls in ('amount_yen', 'amount_plain')]
        amount_lines.sort(key=lambda t: t[0]['x_min'])
        for i, (ln, cls) in enumerate(amount_lines):
            val = parse_amount_str(ln['text'])
            if val is None or val < 100:
                continue
            if i == 0:
                planned_price = val
            elif i == 1:
                contract_amount = val

    # Rate
    rate_lines = [(ln, cls) for ln, cls in classified if cls == 'rate']
    if rate_lines:
        award_rate = parse_rate_str(rate_lines[0][0]['text'])

    # ---- Bid method / Contract basis ----
    bid_method = None
    contract_basis = None

    bid_kw_lines = [(ln, cls) for ln, cls in classified if cls == 'bid_kw']
    basis_lines = [(ln, cls) for ln, cls in classified if cls == 'basis_kw']
    # Build basis text from all basis lines (sorted by y)
    if basis_lines or (bid_kw_lines and bid_method_from_filename == 'zui'):
        # Zuikei: bid_kw might actually be the start of basis text
        all_basis = [(ln, cls) for ln, cls in classified if cls in ('bid_kw', 'basis_kw')]
        all_basis.sort(key=lambda t: t[0]['y_global'])
        # Filter to only those with x > corp_x (right of corp_num column)
        all_basis = [(ln, cls) for ln, cls in all_basis if ln['x_min'] > corp_x - 20]
        if all_basis:
            basis_parts = [ln['text'] for ln, cls in all_basis]
            contract_basis = '\n'.join(basis_parts)
    else:
        if bid_kw_lines:
            bid_method = bid_kw_lines[0][0]['text']

    # Fallback bid_method from filename
    if bid_method is None and bid_method_from_filename == 'bid':
        bid_method = '一般競争入札'
    elif bid_method is None and bid_method_from_filename == 'zui':
        bid_method = '随意契約'

    # ---- Identify x-column zones ----
    # Left column (x < corp_x - some threshold): contract_name, period, type
    # Middle-left: officer info
    # Middle: vendor info
    # Right of corp_x: basis/bid_method, amounts, rate

    # Use x-midpoints between columns to split zones
    # corp_ln defines one boundary
    # Date line defines another boundary
    date_lines = [(ln, cls) for ln, cls in classified if cls == 'date']
    # Use the RIGHTMOST date as the contract-date column boundary.
    # 建設工事 pages have period-start dates at x≈25; contract dates at x≈270.
    # Taking max(x_min) ensures we use the correct column separator.
    date_x = max(ln['x_min'] for ln, cls in date_lines) if date_lines else corp_x - 50

    # Lines to the LEFT of date_x and NOT in header
    # These are: contract_name, period, type (leftmost x) and officer (middle-left)
    # Split by a second x threshold (approx midpoint between leftmost and date)
    all_left = [(ln, cls) for ln, cls in classified if ln['x_min'] < date_x - 5]
    all_left.sort(key=lambda t: t[0]['x_min'])

    if all_left:
        # Find the leftmost x and the "second" x zone
        x_vals = [ln['x_min'] for ln, cls in all_left]
        x_min_all = min(x_vals)
        # Lines in the leftmost zone (x within 80 of leftmost)
        left_zone = [(ln, cls) for ln, cls in all_left if ln['x_min'] <= x_min_all + 80]
        officer_zone = [(ln, cls) for ln, cls in all_left if ln['x_min'] > x_min_all + 80]
    else:
        left_zone = []
        officer_zone = []

    # Contract name / period / type from left_zone (sorted by y)
    left_zone_sorted = sorted(left_zone, key=lambda t: t[0]['y_global'])
    contract_name = None
    period_str = None
    contract_type_str = None

    left_text_lines = []
    for ln, cls in left_zone_sorted:
        if cls == 'period':
            period_str = ln['text']
        elif cls == 'header':
            pass
        else:
            left_text_lines.append(ln['text'])

    # Build contract_name from non-period, non-header left lines
    # The first line(s) are the name, period, then type
    name_parts = []
    for t in left_text_lines:
        if period_str and t == period_str:
            continue
        name_parts.append(t)
    if name_parts:
        # Heuristic: if last part looks like a "type" keyword, separate it
        type_kws = ('工事業', 'コンサルタント', 'その他の業種', '地質調査', '建築工事',
                    '舗装工事', '電気工事', '機械設備', '設備工事', '造園工事',
                    '塗装工事', '管工事', '土木', '通信工事', '警備')
        if len(name_parts) > 1 and any(kw in name_parts[-1] for kw in type_kws):
            contract_type_str = name_parts[-1]
            contract_name = '\n'.join(name_parts[:-1])
        else:
            contract_name = '\n'.join(name_parts)

    # Officer info from officer_zone
    officer_zone_sorted = sorted(officer_zone, key=lambda t: t[0]['y_global'])
    officer_parts = [ln['text'] for ln, cls in officer_zone_sorted if cls not in ('header',)]
    contracting_officer = '\n'.join(officer_parts) if officer_parts else None

    # Vendor info: lines between date_x and corp_x
    vendor_zone = [(ln, cls) for ln, cls in classified
                   if date_x <= ln['x_min'] < corp_x + 5
                   and cls not in ('date', 'corp_num', 'header', 'period')]
    vendor_zone_sorted = sorted(vendor_zone, key=lambda t: t[0]['y_global'])
    vendor_parts = []
    for ln, cls in vendor_zone_sorted:
        t = ln['text']
        if classify_line(t) not in ('amount_yen', 'amount_plain', 'rate', 'corp_num'):
            vendor_parts.append(t)

    vendor_name = vendor_parts[0] if vendor_parts else None
    vendor_address_parts = vendor_parts[1:] if len(vendor_parts) > 1 else []
    vendor_address = '\n'.join(vendor_address_parts) if vendor_address_parts else None

    # Determine final bid_method
    if bid_method is None and contract_basis:
        bid_method = '随意契約'

    # Check if we have minimum required fields
    if contract_name is None and contract_amount is None:
        return None

    return {
        'contract_name': contract_name,
        'contracting_officer': contracting_officer,
        'contract_date': contract_date,
        'vendor_name': vendor_name,
        'vendor_address': vendor_address,
        'corporate_number': corporate_number,
        'bid_method': bid_method or ('随意契約' if bid_method_from_filename == 'zui' else '一般競争入札'),
        'contract_basis': contract_basis,
        'planned_price': planned_price,
        'contract_amount': contract_amount,
        'award_rate': award_rate,
        'procurement_type': procurement_type or '物品役務',
    }

# ============================================================
# Date / Amount helpers
# ============================================================

def parse_reiwa_date_str(text):
    m = RE_REIWA_DATE.match(text.strip())
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{REIWA_BASE + ry}{mo:02d}{dd:02d}'
    return None

def parse_amount_str(text):
    t = text.replace(',', '').replace('円', '').strip()
    try:
        v = float(t)
        return v if v >= 0 else None
    except Exception:
        return None

def parse_rate_str(text):
    t = text.replace('%', '').strip()
    try:
        return float(t)
    except Exception:
        return None

def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1

# ============================================================
# Full PDF parsing
# ============================================================

def parse_tcab_pdf(pdf_path, bid_or_zui):
    """Parse TCAB monthly PDF (r{yy}_{mm}_{bid|zui}.pdf)."""
    lines = extract_pdf_lines(pdf_path)
    if not lines:
        return []

    # Group lines by page
    pages = {}
    for ln in lines:
        pages.setdefault(ln['page'], []).append(ln)

    all_records = []
    for page_num in sorted(pages.keys()):
        page_lines = sorted(pages[page_num], key=lambda l: l['y_global'])
        ptype = detect_page_type(page_lines)
        if ptype is None:
            # Infer from filename: bid/zui files contain both types
            # Pages 0-1 tend to be 公共工事, pages 2+ tend to be 物品役務
            # But we detect by header content; if not found, skip
            continue
        recs = parse_records_from_lines(page_lines, ptype, bid_or_zui)
        all_records.extend(recs)

    return all_records

def parse_wcab_pdf(pdf_path, file_prefix):
    """
    Parse WCAB PDF.
    file_prefix: 'kk', 'kz', 'bk', 'bz'
    """
    # Determine procurement_type and bid/zui from prefix
    if file_prefix in ('kk', 'kz'):
        procurement_type = '建設工事'
    else:
        procurement_type = '物品役務'

    bid_or_zui = 'bid' if file_prefix in ('kk', 'bk') else 'zui'

    lines = extract_pdf_lines(pdf_path)
    if not lines:
        return []

    pages = {}
    for ln in lines:
        pages.setdefault(ln['page'], []).append(ln)

    all_records = []
    for page_num in sorted(pages.keys()):
        page_lines = sorted(pages[page_num], key=lambda l: l['y_global'])
        recs = parse_records_from_lines(page_lines, procurement_type, bid_or_zui)
        all_records.extend(recs)

    return all_records

# ============================================================
# DB operations
# ============================================================

def setup_db(conn):
    """Add `source` column if it doesn't exist."""
    cur = conn.cursor()
    # Check if source column exists
    cur.execute("PRAGMA table_info(contracts)")
    cols = [row[1] for row in cur.fetchall()]
    if 'source' not in cols:
        cur.execute("ALTER TABLE contracts ADD COLUMN source TEXT")
        conn.commit()
        print("  Added 'source' column to contracts table.")

def insert_records(conn, records, source, source_file, dry_run=False):
    """Insert records into DB. Returns (inserted, skipped) counts."""
    cur = conn.cursor()
    inserted = 0
    skipped = 0

    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy is None:
            skipped += 1
            continue

        if dry_run:
            inserted += 1
            continue

        try:
            cur.execute("""
                INSERT INTO contracts (
                    fiscal_year, procurement_type, bid_method,
                    contract_name, contracting_officer, contract_date,
                    vendor_name, vendor_address, corporate_number,
                    contract_basis, planned_price, contract_amount, award_rate,
                    notes, source_file, source
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                fy,
                rec.get('procurement_type', '物品役務'),
                rec.get('bid_method', ''),
                rec.get('contract_name'),
                rec.get('contracting_officer'),
                rec.get('contract_date'),
                rec.get('vendor_name'),
                rec.get('vendor_address'),
                rec.get('corporate_number'),
                rec.get('contract_basis'),
                rec.get('planned_price'),
                rec.get('contract_amount'),
                rec.get('award_rate'),
                None,
                source_file,
                source,
            ))
            inserted += 1
        except sqlite3.Error as e:
            print(f"  DB error: {e}")
            skipped += 1

    if not dry_run:
        conn.commit()
    return inserted, skipped

# ============================================================
# Main workflow: TCAB
# ============================================================

def run_tcab(conn, dry_run=False):
    print("\n=== TCAB (東京航空局) ===")
    stats = {'total': 0, 'downloaded': 0, 'skipped_404': 0, 'inserted': 0, 'parse_failed': 0}

    for source_label, url, reiwa_year, month, bid_or_zui in tcab_urls():
        fname = url.split('/')[-1]
        fpath = PDF_DIR / fname

        ok = download_pdf(url, fpath)
        if not ok:
            stats['skipped_404'] += 1
            continue

        stats['downloaded'] += 1
        records = parse_tcab_pdf(fpath, bid_or_zui)

        if not records:
            stats['parse_failed'] += 1
            if not dry_run:
                pass  # Still OK - some files might have 0 records for that month
            continue

        ins, skp = insert_records(conn, records, 'tcab', fname, dry_run)
        stats['inserted'] += ins
        stats['total'] += len(records)

        print(f"  {fname}: {len(records)} records parsed, {ins} inserted, {skp} skipped")
        time.sleep(0.5)

    print(f"\nTCAB summary: downloaded={stats['downloaded']}, "
          f"404={stats['skipped_404']}, parsed={stats['total']}, "
          f"inserted={stats['inserted']}")
    return stats

# ============================================================
# Main workflow: WCAB
# ============================================================

def run_wcab(conn, dry_run=False):
    print("\n=== WCAB (大阪航空局) ===")
    stats = {'total': 0, 'downloaded': 0, 'skipped_404': 0, 'inserted': 0, 'parse_failed': 0}

    wcab_list = wcab_urls_from_page()
    print(f"  Found {len(wcab_list)} WCAB PDFs on published page.")

    for source_label, url in wcab_list:
        fname = url.split('/')[-1]
        # Determine prefix (kk, kz, bk, bz)
        prefix_m = re.match(r'^([a-z]{2})', fname.lower())
        if not prefix_m:
            continue
        prefix = prefix_m.group(1)

        fpath = PDF_DIR / f'wcab_{fname}'
        ok = download_pdf(url, fpath)
        if not ok:
            stats['skipped_404'] += 1
            continue

        stats['downloaded'] += 1
        records = parse_wcab_pdf(fpath, prefix)

        if not records:
            stats['parse_failed'] += 1
            continue

        ins, skp = insert_records(conn, records, 'wcab', fname, dry_run)
        stats['inserted'] += ins
        stats['total'] += len(records)

        print(f"  {fname}: {len(records)} records parsed, {ins} inserted, {skp} skipped")
        time.sleep(0.5)

    print(f"\nWCAB summary: downloaded={stats['downloaded']}, "
          f"404={stats['skipped_404']}, parsed={stats['total']}, "
          f"inserted={stats['inserted']}")
    return stats

# ============================================================
# Summary report
# ============================================================

def print_summary(conn):
    cur = conn.cursor()

    print("\n" + "=" * 60)
    print("DB SUMMARY (atc_procurement.db)")
    print("=" * 60)

    cur.execute("""
        SELECT source, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8, 1) as amt_100m
        FROM contracts
        GROUP BY source
        ORDER BY source
    """)
    rows = cur.fetchall()
    print(f"\n{'Source':<12} {'Contracts':>10} {'Amount(億)':>12}")
    print("-" * 36)
    for row in rows:
        src, cnt, amt = row
        print(f"{src or '(null)':<12} {cnt:>10,} {amt or 0:>12,.1f}")

    cur.execute("""
        SELECT fiscal_year, source,
               COUNT(*) as cnt,
               ROUND(SUM(COALESCE(contract_amount,0))/1e8, 1) as amt
        FROM contracts
        WHERE source IN ('tcab', 'wcab')
        GROUP BY fiscal_year, source
        ORDER BY fiscal_year, source
    """)
    rows = cur.fetchall()
    if rows:
        print(f"\n{'FY':<6} {'Source':<8} {'Count':>8} {'Amount(億)':>12}")
        print("-" * 36)
        for fy, src, cnt, amt in rows:
            print(f"{fy:<6} {src:<8} {cnt:>8,} {amt or 0:>12,.1f}")

    # Coverage change
    cur.execute("""
        SELECT fiscal_year,
               COUNT(*) as cnt,
               ROUND(SUM(COALESCE(contract_amount,0))/1e8, 1) as amt
        FROM contracts
        GROUP BY fiscal_year
        ORDER BY fiscal_year
    """)
    rows = cur.fetchall()
    print(f"\n{'FY':<6} {'Total Count':>12} {'Total Amount(億)':>16}")
    print("-" * 36)
    for fy, cnt, amt in rows:
        print(f"{fy:<6} {cnt:>12,} {amt or 0:>16,.1f}")

# ============================================================
# Main
# ============================================================

def main():
    parser = argparse.ArgumentParser(description='Collect ATC monthly PDFs')
    parser.add_argument('--dry-run', action='store_true',
                        help='Parse only, do not insert into DB')
    parser.add_argument('--source', choices=['tcab', 'wcab', 'both'], default='both',
                        help='Which source to collect (default: both)')
    args = parser.parse_args()

    conn = sqlite3.connect(str(DB_PATH))
    setup_db(conn)

    if args.source in ('tcab', 'both'):
        run_tcab(conn, dry_run=args.dry_run)

    if args.source in ('wcab', 'both'):
        run_wcab(conn, dry_run=args.dry_run)

    if not args.dry_run:
        print_summary(conn)

    conn.close()

if __name__ == '__main__':
    main()
