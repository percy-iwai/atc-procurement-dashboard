#!/usr/bin/env python3
"""
PAS (地方整備局) FY2020/2021 空港関連データ 収集スクリプト

戦略:
  1. WARP ts=20240601090314 でまず試行 (FY2021 の一部が取れる可能性)
  2. WARP ts=20220601 系の古いスナップショットも試行 (FY2020向け)
  3. Wayback Machine CDX API でも該当ファイルを探す

対象月:
  FY2020: 202004〜202103 (Apr 2020 - Mar 2021)
  FY2021: 202104〜202203 (Apr 2021 - Mar 2022)

局: Tohoku, Kanto, Hokkaido, Hokuriku, Chubu, Kinki, Chugoku, Shikoku, Kyushu, Okinawa

出力: atc_procurement.db → pas_airport_contracts テーブル
"""

import re
import time
import json
import sqlite3
import urllib.request
import urllib.error
from pathlib import Path

try:
    import xlrd
except ImportError:
    import subprocess, sys
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'xlrd==1.2.0'], check=True)
    import xlrd

PROJECT = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH = PROJECT / 'data/db/atc_procurement.db'
DL_DIR  = PROJECT / 'data/raw/pas_kekka'
DL_DIR.mkdir(parents=True, exist_ok=True)

HEADERS  = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
PAS_BASE = 'https://www.pas.ysk.nilim.go.jp/contents/KekkaKohyo'

# WARP snapshots to try (newest → oldest)
WARP_SNAPSHOTS = [
    ('20240601090314', '20240601'),  # known-good: has FY2022+ data, may have FY2021
    ('20230601090000', '20230601'),  # try for FY2021/FY2020
    ('20220601090000', '20220601'),  # try for FY2020
    ('20210601090000', '20210601'),  # try for FY2020
]

# Bureaus (English names as used in PAS URL, Japanese label)
BUREAUS = [
    ('Tohoku',   '東北'),
    ('Kanto',    '関東'),
    ('Hokkaido', '北海道'),
    ('Hokuriku', '北陸'),
    ('Chubu',    '中部'),
    ('Kinki',    '近畿'),
    ('Chugoku',  '中国'),
    ('Shikoku',  '四国'),
    ('Kyushu',   '九州'),
    ('Okinawa',  '沖縄'),
]

FY2020_MONTHS = [202004, 202005, 202006, 202007, 202008, 202009,
                  202010, 202011, 202012, 202101, 202102, 202103]
FY2021_MONTHS = [202104, 202105, 202106, 202107, 202108, 202109,
                  202110, 202111, 202112, 202201, 202202, 202203]

AIRPORT_KW = [
    '空港', '滑走路', '誘導路', 'エプロン', '航空灯火', '航空保安', '空港整備',
    '空港護岸', '空港埋立', '着陸帯', '旅客搭乗橋', '除雪機庫', '航空局',
]


def is_airport_related(name):
    return bool(name) and any(kw in name for kw in AIRPORT_KW)


def serial_to_ymd(serial, datemode=0):
    try:
        v = float(serial)
        if v <= 0:
            return None
        t = xlrd.xldate_as_tuple(v, datemode)
        if t[0] == 0:
            return None
        return f'{t[0]:04d}{t[1]:02d}{t[2]:02d}'
    except Exception:
        return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def yyyymm_to_fy(yyyymm):
    y, m = int(str(yyyymm)[:4]), int(str(yyyymm)[4:])
    return y if m >= 4 else y - 1


def download_warp(bureau_en, fname, dest_path, warp_ts, warp_coll):
    """Try WARP snapshot for given timestamp."""
    if dest_path.exists() and dest_path.stat().st_size > 5000:
        return True
    orig_url = f'{PAS_BASE}/{bureau_en}/{fname}'
    warp_url = f'https://warp.ndl.go.jp/{warp_coll}/{warp_ts}id_/{orig_url}'
    req = urllib.request.Request(warp_url, headers=HEADERS)
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        data = resp.read()
        if len(data) < 1000:
            return False
        dest_path.write_bytes(data)
        return True
    except urllib.error.HTTPError as e:
        return False
    except Exception as e:
        return False


def download_wayback(bureau_en, fname, dest_path):
    """Try Wayback CDX API to find and download via web.archive.org."""
    if dest_path.exists() and dest_path.stat().st_size > 5000:
        return True
    orig_url = f'{PAS_BASE}/{bureau_en}/{fname}'
    cdx_url = (
        f'http://web.archive.org/cdx/search/cdx'
        f'?url={orig_url}&output=json&fl=timestamp,statuscode'
        f'&from=20190401&to=20230401&limit=10'
    )
    try:
        req = urllib.request.Request(cdx_url, headers=HEADERS)
        resp = urllib.request.urlopen(req, timeout=20)
        data = json.loads(resp.read())
        if not data or len(data) < 2:
            return False
        # Find earliest 200 snapshot
        for row in data[1:]:
            if len(row) >= 2 and row[1] in ('200', '-'):
                ts = row[0]
                wb_url = f'https://web.archive.org/web/{ts}if_/{orig_url}'
                req2 = urllib.request.Request(wb_url, headers=HEADERS)
                try:
                    resp2 = urllib.request.urlopen(req2, timeout=30)
                    raw = resp2.read()
                    if len(raw) > 1000:
                        dest_path.write_bytes(raw)
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    return False


def parse_xls(fpath, file_type, bureau_ja, yyyymm, notes_tag):
    try:
        wb = xlrd.open_workbook(str(fpath))
    except Exception as e:
        print(f"  ERROR opening {fpath.name}: {e}")
        return []

    ws = wb.sheet_by_index(0)
    dm = wb.datemode
    records = []

    for r in range(4, ws.nrows):
        row = [ws.cell_value(r, c) if c < ws.ncols else '' for c in range(19)]
        name_raw = str(row[1]).strip()
        if not name_raw or name_raw in ('None', '0.0', ''):
            continue
        if not is_airport_related(name_raw):
            continue

        bid_date   = serial_to_ymd(row[2], dm)
        award_date = serial_to_ymd(row[3], dm)
        if not bid_date:
            bid_date = f'{str(yyyymm)[:4]}{str(yyyymm)[4:]}01'

        fy = date_to_fy(bid_date) or yyyymm_to_fy(yyyymm)

        def safe_float(v):
            try:
                f = float(v)
                return f if f > 0 else None
            except Exception:
                return None

        work_type  = str(row[4]).strip() or None
        bid_method = str(row[5]).strip() or None
        vendor_raw = str(row[7]).strip()
        vendor_name = vendor_raw if vendor_raw and vendor_raw not in ('None', '') else None

        records.append({
            'fiscal_year':   fy,
            'bureau':        bureau_ja,
            'file_name':     fpath.name,
            'file_type':     file_type,
            'contract_name': name_raw,
            'bid_date':      bid_date,
            'award_date':    award_date,
            'work_type':     work_type if work_type != 'None' else None,
            'bid_method':    bid_method if bid_method != 'None' else None,
            'vendor_name':   vendor_name,
            'planned_price': safe_float(row[8]),
            'bid_amount':    safe_float(row[9]),
            'award_amount':  safe_float(row[11]),
            'notes':         notes_tag,
        })
    return records


def get_existing_keys(conn):
    cur = conn.cursor()
    try:
        cur.execute("SELECT bureau || '/' || file_name FROM pas_airport_contracts")
        return set(r[0] for r in cur.fetchall())
    except Exception:
        return set()


def insert_records(conn, records):
    if not records:
        return 0
    cur = conn.cursor()
    cur.executemany("""
        INSERT INTO pas_airport_contracts
          (fiscal_year, bureau, file_name, file_type, contract_name,
           bid_date, award_date, work_type, bid_method, vendor_name,
           planned_price, bid_amount, award_amount, notes)
        VALUES
          (:fiscal_year, :bureau, :file_name, :file_type, :contract_name,
           :bid_date, :award_date, :work_type, :bid_method, :vendor_name,
           :planned_price, :bid_amount, :award_amount, :notes)
    """, records)
    conn.commit()
    return len(records)


def ensure_pas_table(conn):
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS pas_airport_contracts (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            fiscal_year   INTEGER,
            bureau        TEXT,
            file_name     TEXT,
            file_type     TEXT,
            contract_name TEXT,
            bid_date      TEXT,
            award_date    TEXT,
            work_type     TEXT,
            bid_method    TEXT,
            vendor_name   TEXT,
            planned_price REAL,
            bid_amount    REAL,
            award_amount  REAL,
            notes         TEXT
        )
    """)
    conn.commit()


def main():
    conn = sqlite3.connect(str(DB_PATH))
    ensure_pas_table(conn)
    existing = get_existing_keys(conn)
    print(f"既存キー数: {len(existing)}")

    total_ins = total_skip = total_fail = 0

    for target_fy, months in [(2020, FY2020_MONTHS), (2021, FY2021_MONTHS)]:
        print(f"\n=== FY{target_fy} ===")
        fy_ins = 0

        for bureau_en, bureau_ja in BUREAUS:
            bureau_ins = 0
            for yyyymm in months:
                for ftype in ['koji', 'gyomu']:
                    fname     = f'{ftype}{yyyymm}.xls'
                    local_key = f'{bureau_ja}/{bureau_en}_{fname}'

                    if local_key in existing:
                        total_skip += 1
                        continue

                    dest = DL_DIR / f'{bureau_en}_{fname}'
                    got  = False
                    tag  = ''

                    # Try WARP snapshots first (newest to oldest)
                    for warp_ts, warp_coll in WARP_SNAPSHOTS:
                        ok = download_warp(bureau_en, fname, dest, warp_ts, warp_coll)
                        if ok:
                            tag = f'warp:{warp_ts[:8]}'
                            got = True
                            break

                    # Fallback: Wayback Machine
                    if not got:
                        ok = download_wayback(bureau_en, fname, dest)
                        if ok:
                            tag = 'wayback'
                            got = True

                    if not got:
                        total_fail += 1
                        continue

                    recs = parse_xls(dest, ftype, bureau_ja, yyyymm, tag)
                    # Filter: only include target_fy records
                    recs = [r for r in recs if r['fiscal_year'] == target_fy]
                    if recs:
                        n = insert_records(conn, recs)
                        bureau_ins += n
                        total_ins  += n
                        existing.add(local_key)  # prevent re-insert in this session

                    time.sleep(0.2)

            if bureau_ins:
                print(f'  {bureau_ja}: {bureau_ins}件')
            fy_ins += bureau_ins

        print(f'  FY{target_fy} 小計: {fy_ins}件')

    conn.close()

    print(f'\n=== PAS FY2020/2021 収集完了 ===')
    print(f'新規挿入: {total_ins}件')
    print(f'スキップ: {total_skip}件')
    print(f'取得失敗: {total_fail}件')

    # Summary
    conn2 = sqlite3.connect(str(DB_PATH))
    cur2  = conn2.cursor()
    print('\n=== 全FY PAS集計 ===')
    cur2.execute("""
        SELECT fiscal_year, COUNT(*),
               ROUND(SUM(COALESCE(award_amount,0))/1e8, 2) as award_amt
        FROM pas_airport_contracts
        GROUP BY fiscal_year ORDER BY fiscal_year
    """)
    for row in cur2.fetchall():
        print(f'  FY{row[0]}: {row[1]}件 / {row[2]}億円')
    conn2.close()


if __name__ == '__main__':
    main()
