#!/usr/bin/env python3
"""
TCAB FY2020/2021 + WCAB FY2020/2021 収集スクリプト

TCAB:
  FY2020: r02_04_bid/zui.pdf ~ r03_03_bid/zui.pdf (12ヶ月×2種)
  FY2021: r03_04_bid/zui.pdf ~ r04_03_bid/zui.pdf (12ヶ月×2種) ※一部DB済み

WCAB:
  Wayback CDX API で FY2020/2021 のアーカイブURLを発見し
  web.archive.org/web/{ts}if_/{url} でダウンロード・パース

Usage:
    python collect_atc_fy2020_2021.py [--dry-run] [--source tcab|wcab|both]
"""

import re
import os
import sys
import time
import json
import sqlite3
import argparse
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    print("ERROR: PyMuPDF not installed. Run: pip install pymupdf")
    sys.exit(1)

# ============================================================
# Paths / Constants
# ============================================================
PROJECT  = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR  = PROJECT / 'data/pdfs/atc'
PDF_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}
REIWA_BASE = 2018

# WARP snapshots of WCAB published.html to scrape for FY2020/2021 PDF URLs
# (CDX API on web.archive.org returns 0 results for this domain)
WARP_PUBLISHED_SNAPSHOTS = [
    # (warp_ts, warp_coll, id_form)
    ('20220601134447', '20220601', True),   # has FY2021 + late FY2020 files
    ('20211201145310', '20211231', True),   # has FY2020 + early FY2021 files
]
WCAB_PUBLISHED_URL = 'https://www.cab.mlit.go.jp/wcab/contract/published.html'
WCAB_FILE_BASE     = 'https://www.cab.mlit.go.jp/wcab/file/'

# ============================================================
# URL generation: TCAB
# ============================================================

def tcab_urls_fy2020_2021():
    """
    FY2020: 令和2年4月(r02_04) ~ 令和3年3月(r03_03)
    FY2021: 令和3年4月(r03_04) ~ 令和4年3月(r04_03)
    """
    urls = []
    # Reiwa year 2 = 2020, year 3 = 2021, year 4 = 2022
    for reiwa_yr, months in [(2, range(4, 13)), (3, range(1, 13)), (4, range(1, 4))]:
        yy = f'{reiwa_yr:02d}'
        for mm in months:
            for sfx in ('bid', 'zui'):
                url = f'https://www.cab.mlit.go.jp/tcab/files/r{yy}_{mm:02d}_{sfx}.pdf'
                urls.append(('tcab', url, reiwa_yr, mm, sfx))
    return urls

# ============================================================
# Download helpers
# ============================================================

def download_direct(url, dest_path, max_retries=2):
    """Direct HTTP download. Returns True on success."""
    if dest_path.exists() and dest_path.stat().st_size > 1000:
        return True
    for attempt in range(max_retries + 1):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            resp = urllib.request.urlopen(req, timeout=20)
            data = resp.read()
            if len(data) < 500:
                return False
            dest_path.write_bytes(data)
            return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return False
            if attempt < max_retries:
                time.sleep(2)
        except Exception:
            if attempt < max_retries:
                time.sleep(2)
    return False


def download_wayback(timestamp, orig_url, dest_path, max_retries=2):
    """Download via Wayback Machine (if_ = raw file, no JS wrapper)."""
    if dest_path.exists() and dest_path.stat().st_size > 1000:
        return True
    wb_url = f'https://web.archive.org/web/{timestamp}if_/{orig_url}'
    return download_direct(wb_url, dest_path, max_retries)

# ============================================================
# WCAB: Wayback CDX discovery
# ============================================================

def discover_wcab_urls_via_warp():
    """
    Scrape WARP snapshots of WCAB published.html to find FY2020/2021 PDF URLs.
    Returns list of (warp_download_url, fname) tuples for files not yet in DB.
    """
    seen = {}  # fname -> warp_download_url (first found wins)

    for warp_ts, warp_coll, use_id in WARP_PUBLISHED_SNAPSHOTS:
        id_flag = 'id_' if use_id else ''
        snap_url = f'https://warp.ndl.go.jp/{warp_coll}/{warp_ts}{id_flag}/{WCAB_PUBLISHED_URL}'
        print(f"  WARP published.html: {snap_url}")
        try:
            req  = urllib.request.Request(snap_url, headers=HEADERS)
            resp = urllib.request.urlopen(req, timeout=20)
            html = resp.read().decode('utf-8', errors='replace')
        except Exception as e:
            print(f"  WARN: {e}")
            continue

        # Extract WCAB file PDF names from the page
        raw_fnames = re.findall(r'/wcab/file/([^\"\'\s<>]+\.pdf)', html, re.IGNORECASE)
        print(f"    Found {len(set(raw_fnames))} unique file refs")

        for fname in set(raw_fnames):
            # Skip hash files
            if re.match(r'^[0-9a-f]{40}\.pdf$', fname, re.IGNORECASE):
                continue
            # Only process bk/bz/kk/kz prefixed files
            base = fname.split('/')[-1]  # handle subdirectory like pdf/bk_202010.pdf
            if not re.match(r'^(bk|bz|kk|kz)', base, re.IGNORECASE):
                continue
            if base not in seen:
                # Build the WARP direct download URL
                orig_url = WCAB_FILE_BASE + fname
                dl_url = f'https://warp.ndl.go.jp/{warp_coll}/{warp_ts}id_/{orig_url}'
                seen[base] = dl_url

    print(f"  Total unique WCAB files discovered: {len(seen)}")
    return list(seen.items())  # [(fname, warp_dl_url), ...]

# ============================================================
# PDF text extraction (identical to collect_atc_monthly.py)
# ============================================================

RE_DATE_PREFIX = re.compile(r'^(令和\d+年\d+月\d+日)(.+)$')

def _split_date_prefix(text, chars_list, x_min):
    m = RE_DATE_PREFIX.match(text)
    if not m:
        return [(text, x_min, x_min + len(text) * 8)]
    date_part = m.group(1)
    rest_part = m.group(2)
    date_len = len(date_part)
    if len(chars_list) >= date_len:
        split_x = chars_list[date_len][0]
        date_x_max = split_x - 1
    else:
        date_x_max = x_min + date_len * 8
    rest_x_min = date_x_max + 1
    return [
        (date_part, x_min, date_x_max),
        (rest_part, rest_x_min, rest_x_min + len(rest_part) * 8),
    ]


def extract_pdf_lines(pdf_path):
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening PDF: {e}")
        return []

    result = []
    for page_num, page in enumerate(doc):
        try:
            xml_str = page.get_text('xml')
            root = ET.fromstring(xml_str)
        except Exception:
            continue

        for line in root.findall('.//line'):
            chars_with_x = []
            for char in line.findall('.//char'):
                c = char.get('c', '')
                if not c:
                    continue
                try:
                    cx = float(char.get('x', '0'))
                    bbox = line.get('bbox', '')
                    parts = bbox.split()
                    if len(parts) >= 4:
                        y0, y1 = float(parts[1]), float(parts[3])
                    else:
                        y0 = y1 = 0.0
                    chars_with_x.append((cx, (y0 + y1) / 2, c))
                except Exception:
                    continue

            if not chars_with_x:
                text = line.get('text', '').strip()
                if not text:
                    continue
                bbox = line.get('bbox', '')
                try:
                    x0, y0, x1, y1 = [float(v) for v in bbox.split()]
                except Exception:
                    continue
                y_center = (y0 + y1) / 2
                result.append({
                    'page': page_num,
                    'x_min': x0, 'x_max': x1,
                    'y_page': y_center,
                    'y_global': page_num * 1000 + y_center,
                    'text': text,
                })
                continue

            COL_GAP = 12.0
            segments = []
            seg_chars = [chars_with_x[0]]
            for i in range(1, len(chars_with_x)):
                if chars_with_x[i][0] - chars_with_x[i - 1][0] > COL_GAP:
                    segments.append(seg_chars)
                    seg_chars = [chars_with_x[i]]
                else:
                    seg_chars.append(chars_with_x[i])
            segments.append(seg_chars)

            y_center = chars_with_x[0][1]
            for seg in segments:
                seg_text = ''.join(c for _, _, c in seg).strip()
                if not seg_text:
                    continue
                x_min = seg[0][0]
                sub_segs = _split_date_prefix(seg_text, seg, x_min)
                for sub_text, sub_x_min, sub_x_max in sub_segs:
                    result.append({
                        'page': page_num,
                        'x_min': sub_x_min, 'x_max': sub_x_max,
                        'y_page': y_center,
                        'y_global': page_num * 1000 + y_center,
                        'text': sub_text,
                    })
    doc.close()
    return result

# ============================================================
# Content classification
# ============================================================

RE_REIWA_DATE   = re.compile(r'^令和(\d+)年(\d+)月(\d+)日$')
RE_REIWA_PERIOD = re.compile(r'令和\d+年\d+月\d+日.*[～~]')
RE_CORP_NUM     = re.compile(r'^\d{13}$')
RE_AMOUNT_YEN   = re.compile(r'^[\d,]+円$')
RE_AMOUNT_NUM   = re.compile(r'^[\d,]+$')
RE_RATE_PCT     = re.compile(r'^[\d.]+%$')
RE_TWOAMOUNTS   = re.compile(r'^([\d,]+)\s+([\d,]+)$')
RE_PAGE_HEADER  = re.compile(
    r'公共調達の適正化|契約の相手方の商号|公共工事の名称|物品役務の名称|'
    r'契約担当官|一般競争入札.*指名競争|又は名称及び住所|随意契約によることとした'
)


def is_page_header(text):
    return bool(RE_PAGE_HEADER.search(text)) or len(text) > 80


def classify_line(text):
    if RE_REIWA_DATE.match(text):
        return 'date'
    if RE_REIWA_PERIOD.search(text):
        return 'period'
    if RE_CORP_NUM.match(text):
        return 'corp_num'
    if RE_AMOUNT_YEN.match(text):
        return 'amount_yen'
    if RE_TWOAMOUNTS.match(text.replace(',', '')):
        return 'two_amounts'
    if RE_AMOUNT_NUM.match(text.replace(',', '')) and len(text.replace(',', '')) >= 4:
        try:
            v = float(text.replace(',', ''))
            if v >= 100:
                return 'amount_plain'
        except Exception:
            pass
    if RE_RATE_PCT.match(text):
        return 'rate'
    try:
        v = float(text)
        if 0.0 <= v <= 100.0 and '.' in text:
            return 'rate'
    except Exception:
        pass
    if '競争入札' in text or '指名競争' in text:
        return 'bid_kw'
    if '随意契約' in text and len(text) < 30:
        return 'bid_kw'
    if '会計法' in text or '規定を適用' in text or '随意契約を締結' in text:
        return 'basis_kw'
    if is_page_header(text):
        return 'header'
    return 'other'


def detect_page_type(lines):
    for ln in lines:
        t = ln['text']
        if '物品役務' in t and ('情報の公表' in t or '競争' in t or '随意' in t):
            return '物品役務'
        if '公共工事' in t and '情報の公表' in t:
            return '建設工事'
    return None

# ============================================================
# Record parsing
# ============================================================

def parse_reiwa_date_str(text):
    m = RE_REIWA_DATE.match(text.strip())
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{REIWA_BASE + ry}{mo:02d}{dd:02d}'
    return None


def parse_amount_str(text):
    t = text.replace(',', '').replace('円', '').strip()
    try:
        v = float(t)
        return v if v >= 0 else None
    except Exception:
        return None


def parse_rate_str(text):
    try:
        return float(text.replace('%', '').strip())
    except Exception:
        return None


def extract_fields(rec_lines, corp_ln, procurement_type, bid_method_from_filename):
    corp_x = corp_ln['x_min']
    classified = [(ln, classify_line(ln['text'])) for ln in rec_lines]

    corporate_number = corp_ln['text'].strip()

    # Contract date: rightmost date candidate
    contract_date = None
    date_candidates = [(ln, cls) for ln, cls in classified if cls == 'date']
    for ln, cls in sorted(date_candidates, key=lambda t: t[0]['x_min'], reverse=True):
        d = parse_reiwa_date_str(ln['text'])
        if d:
            contract_date = d
            break

    # Amounts
    planned_price = contract_amount = award_rate = None
    for ln, cls in classified:
        if cls == 'two_amounts':
            m = RE_TWOAMOUNTS.match(ln['text'].replace(',', ''))
            if m:
                planned_price = float(m.group(1))
                contract_amount = float(m.group(2))
            break

    if planned_price is None:
        amount_lines = [(ln, cls) for ln, cls in classified if cls in ('amount_yen', 'amount_plain')]
        amount_lines.sort(key=lambda t: t[0]['x_min'])
        for i, (ln, cls) in enumerate(amount_lines):
            val = parse_amount_str(ln['text'])
            if val is None or val < 100:
                continue
            if i == 0:
                planned_price = val
            elif i == 1:
                contract_amount = val

    rate_lines = [(ln, cls) for ln, cls in classified if cls == 'rate']
    if rate_lines:
        award_rate = parse_rate_str(rate_lines[0][0]['text'])

    bid_method = contract_basis = None
    bid_kw_lines  = [(ln, cls) for ln, cls in classified if cls == 'bid_kw']
    basis_lines   = [(ln, cls) for ln, cls in classified if cls == 'basis_kw']

    if basis_lines or (bid_kw_lines and bid_method_from_filename == 'zui'):
        all_basis = [(ln, cls) for ln, cls in classified if cls in ('bid_kw', 'basis_kw')]
        all_basis.sort(key=lambda t: t[0]['y_global'])
        all_basis = [(ln, cls) for ln, cls in all_basis if ln['x_min'] > corp_x - 20]
        if all_basis:
            contract_basis = '\n'.join(ln['text'] for ln, cls in all_basis)
    else:
        if bid_kw_lines:
            bid_method = bid_kw_lines[0][0]['text']

    if bid_method is None and bid_method_from_filename == 'bid':
        bid_method = '一般競争入札'
    elif bid_method is None and bid_method_from_filename == 'zui':
        bid_method = '随意契約'

    date_lines = [(ln, cls) for ln, cls in classified if cls == 'date']
    date_x = max(ln['x_min'] for ln, cls in date_lines) if date_lines else corp_x - 50

    all_left = [(ln, cls) for ln, cls in classified if ln['x_min'] < date_x - 5]
    all_left.sort(key=lambda t: t[0]['x_min'])

    if all_left:
        x_vals    = [ln['x_min'] for ln, cls in all_left]
        x_min_all = min(x_vals)
        left_zone   = [(ln, cls) for ln, cls in all_left if ln['x_min'] <= x_min_all + 80]
        officer_zone = [(ln, cls) for ln, cls in all_left if ln['x_min'] > x_min_all + 80]
    else:
        left_zone = officer_zone = []

    left_zone_sorted = sorted(left_zone, key=lambda t: t[0]['y_global'])
    period_str = None
    left_text_lines = []
    for ln, cls in left_zone_sorted:
        if cls == 'period':
            period_str = ln['text']
        elif cls != 'header':
            left_text_lines.append(ln['text'])

    type_kws = ('工事業', 'コンサルタント', 'その他の業種', '地質調査', '建築工事',
                '舗装工事', '電気工事', '機械設備', '設備工事', '造園工事',
                '塗装工事', '管工事', '土木', '通信工事', '警備')
    if left_text_lines and len(left_text_lines) > 1 and any(kw in left_text_lines[-1] for kw in type_kws):
        contract_name = '\n'.join(left_text_lines[:-1])
    else:
        contract_name = '\n'.join(left_text_lines) if left_text_lines else None

    officer_zone_sorted = sorted(officer_zone, key=lambda t: t[0]['y_global'])
    officer_parts = [ln['text'] for ln, cls in officer_zone_sorted if cls != 'header']
    contracting_officer = '\n'.join(officer_parts) if officer_parts else None

    vendor_zone = [(ln, cls) for ln, cls in classified
                   if date_x <= ln['x_min'] < corp_x + 5
                   and cls not in ('date', 'corp_num', 'header', 'period')]
    vendor_parts = []
    for ln, cls in sorted(vendor_zone, key=lambda t: t[0]['y_global']):
        if classify_line(ln['text']) not in ('amount_yen', 'amount_plain', 'rate', 'corp_num'):
            vendor_parts.append(ln['text'])
    vendor_name    = vendor_parts[0] if vendor_parts else None
    vendor_address = '\n'.join(vendor_parts[1:]) if len(vendor_parts) > 1 else None

    if bid_method is None and contract_basis:
        bid_method = '随意契約'
    if contract_name is None and contract_amount is None:
        return None

    return {
        'contract_name':       contract_name,
        'contracting_officer': contracting_officer,
        'contract_date':       contract_date,
        'vendor_name':         vendor_name,
        'vendor_address':      vendor_address,
        'corporate_number':    corporate_number,
        'bid_method':          bid_method or ('随意契約' if bid_method_from_filename == 'zui' else '一般競争入札'),
        'contract_basis':      contract_basis,
        'planned_price':       planned_price,
        'contract_amount':     contract_amount,
        'award_rate':          award_rate,
        'procurement_type':    procurement_type or '物品役務',
    }


def parse_records_from_lines_date_anchor(lines, procurement_type, bid_method_from_filename=None):
    """
    Fallback parser when no 13-digit corp numbers exist.
    Uses 令和 date lines as record anchors instead.
    """
    data_lines = [ln for ln in lines if ln['y_page'] > 95 and not is_page_header(ln['text'])]
    if not data_lines:
        return []

    # Use date lines as anchors
    date_anchor_lines = [ln for ln in data_lines if classify_line(ln['text']) == 'date']
    if not date_anchor_lines:
        return []

    date_anchor_lines_sorted = sorted(date_anchor_lines, key=lambda l: l['y_global'])
    records = []
    for idx, anchor_ln in enumerate(date_anchor_lines_sorted):
        y_low  = min(l['y_global'] for l in data_lines) - 1 if idx == 0 \
                 else (date_anchor_lines_sorted[idx - 1]['y_global'] + anchor_ln['y_global']) / 2
        y_high = max(l['y_global'] for l in data_lines) + 1 if idx == len(date_anchor_lines_sorted) - 1 \
                 else (anchor_ln['y_global'] + date_anchor_lines_sorted[idx + 1]['y_global']) / 2

        rec_lines = sorted(
            [ln for ln in data_lines if y_low <= ln['y_global'] <= y_high],
            key=lambda l: (l['x_min'], l['y_global'])
        )
        if not rec_lines:
            continue

        # Extract fields directly from the record's lines
        contract_date = parse_reiwa_date_str(anchor_ln['text'])

        classified = [(ln, classify_line(ln['text'])) for ln in rec_lines]
        amounts = [(ln, cls) for ln, cls in classified if cls in ('amount_yen', 'amount_plain')]
        amounts.sort(key=lambda t: t[0]['x_min'])

        planned_price = contract_amount = award_rate = None
        for i, (ln, cls) in enumerate(amounts):
            val = parse_amount_str(ln['text'])
            if val is None or val < 100:
                continue
            if planned_price is None:
                planned_price = val
            elif contract_amount is None:
                contract_amount = val

        # Two-amounts check
        for ln, cls in classified:
            if cls == 'two_amounts':
                m = RE_TWOAMOUNTS.match(ln['text'].replace(',', ''))
                if m:
                    planned_price = float(m.group(1))
                    contract_amount = float(m.group(2))
                break

        rate_lines = [(ln, cls) for ln, cls in classified if cls == 'rate']
        if rate_lines:
            award_rate = parse_rate_str(rate_lines[0][0]['text'])

        # Bid method
        bid_method = None
        for ln, cls in classified:
            if cls == 'bid_kw':
                bid_method = ln['text']
                break
        if bid_method is None:
            bid_method = '随意契約' if bid_method_from_filename == 'zui' else '一般競争入札'

        # Contract name: longest non-header, non-amount, non-date text line
        name_candidates = [(ln, cls) for ln, cls in classified
                           if cls == 'other' and len(ln['text']) > 6
                           and not is_page_header(ln['text'])]
        contract_name = name_candidates[0][0]['text'] if name_candidates else None

        # Vendor: text lines excluding contract_name, dates, amounts
        vendor_candidates = [(ln, cls) for ln, cls in classified
                             if cls == 'other' and ln != (name_candidates[0][0] if name_candidates else None)]
        vendor_name = vendor_candidates[0][0]['text'] if vendor_candidates else None

        if contract_amount is None:
            continue

        records.append({
            'contract_name':       contract_name,
            'contracting_officer': None,
            'contract_date':       contract_date,
            'vendor_name':         vendor_name,
            'vendor_address':      None,
            'corporate_number':    None,
            'bid_method':          bid_method,
            'contract_basis':      None,
            'planned_price':       planned_price,
            'contract_amount':     contract_amount,
            'award_rate':          award_rate,
            'procurement_type':    procurement_type or '物品役務',
        })
    return records


def parse_records_from_lines(lines, procurement_type, bid_method_from_filename=None):
    data_lines = [ln for ln in lines if ln['y_page'] > 95 and not is_page_header(ln['text'])]
    if not data_lines:
        return []

    corp_lines = [ln for ln in data_lines if classify_line(ln['text']) == 'corp_num']
    if not corp_lines:
        # Fallback: use date lines as anchors (legacy format without corp numbers)
        return parse_records_from_lines_date_anchor(lines, procurement_type, bid_method_from_filename)

    corp_lines_sorted = sorted(corp_lines, key=lambda l: l['y_global'])
    records = []
    for idx, corp_ln in enumerate(corp_lines_sorted):
        y_low  = min(l['y_global'] for l in data_lines) - 1 if idx == 0 \
                 else (corp_lines_sorted[idx - 1]['y_global'] + corp_ln['y_global']) / 2
        y_high = max(l['y_global'] for l in data_lines) + 1 if idx == len(corp_lines_sorted) - 1 \
                 else (corp_ln['y_global'] + corp_lines_sorted[idx + 1]['y_global']) / 2

        rec_lines = sorted(
            [ln for ln in data_lines if y_low <= ln['y_global'] <= y_high],
            key=lambda l: (l['x_min'], l['y_global'])
        )
        if not rec_lines:
            continue
        rec = extract_fields(rec_lines, corp_ln, procurement_type, bid_method_from_filename)
        if rec:
            records.append(rec)
    return records


# ============================================================
# Legacy parser: no corporate numbers (pre-FY2021 late format)
# Each PyMuPDF block contains one full record:
#   "令和X年M月D日\n<vendor_name>\n<address>\n<bid_method>\n<planned>\n<contract>\n<rate>"
# ============================================================

RE_REIWA_DATE_FULL = re.compile(r'令和(\d{1,2})年(\d{1,2})月(\d{1,2})日')
RE_LARGE_AMOUNT    = re.compile(r'^[\d,]{5,15}$')


def _parse_amount(s):
    t = s.replace(',', '').strip()
    try:
        v = float(t)
        return v if v >= 1000 else None
    except Exception:
        return None


def _parse_rate(s):
    t = s.strip()
    try:
        v = float(t)
        return v if 0 < v <= 100 else None
    except Exception:
        return None


def parse_tcab_pdf_legacy(pdf_path, bid_or_zui, reiwa_year_hint, month_hint):
    """
    Parse legacy TCAB PDFs (r02_* through early r03_*) that have no corporate numbers.
    Uses PyMuPDF 'dict' mode to iterate blocks; each data block contains one record.
    """
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening PDF (legacy): {e}")
        return []

    bid_method_default = '随意契約' if bid_or_zui == 'zui' else '一般競争入札'
    records = []

    for page_num, page in enumerate(doc):
        d = page.get_text('dict')
        # Detect procurement type from page text
        page_text = page.get_text()
        if '物品役務' in page_text:
            ptype = '物品役務'
        elif '公共工事' in page_text:
            ptype = '建設工事'
        else:
            ptype = '物品役務'

        for block in d.get('blocks', []):
            # Collect all spans in this block
            spans = []
            for line in block.get('lines', []):
                for span in line.get('spans', []):
                    t = span.get('text', '').strip()
                    if t:
                        spans.append(t)

            if not spans:
                continue

            # Check if this block contains amounts (= a data record block)
            amounts_in_block = []
            for s in spans:
                v = _parse_amount(s)
                if v is not None and v > 100000:
                    amounts_in_block.append(v)

            if len(amounts_in_block) < 2:
                continue

            # Extract contract date
            contract_date = None
            for s in spans:
                m = RE_REIWA_DATE_FULL.search(s)
                if m:
                    ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
                    if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
                        contract_date = f'{2018 + ry}{mo:02d}{dd:02d}'
                        break

            # Fallback: use file year+month
            if not contract_date:
                wy = 2018 + reiwa_year_hint
                contract_date = f'{wy}{month_hint:02d}01'

            # Extract amounts: sorted descending by value, first 2 are planned/contract
            amounts_in_block.sort(reverse=True)
            planned_price   = amounts_in_block[0] if amounts_in_block else None
            contract_amount = amounts_in_block[1] if len(amounts_in_block) > 1 else None

            # Swap if planned < contract (shouldn't happen, but guard)
            if planned_price and contract_amount and planned_price < contract_amount:
                planned_price, contract_amount = contract_amount, planned_price

            # Extract award rate (float between 0-100 with decimal)
            award_rate = None
            for s in spans:
                if RE_LARGE_AMOUNT.match(s):
                    continue
                v = _parse_rate(s)
                if v is not None and 50 < v <= 100:
                    award_rate = v
                    break

            # Extract bid method
            bid_method = bid_method_default
            for s in spans:
                if '随意契約' in s and len(s) < 20:
                    bid_method = '随意契約'
                    break
                if '競争入札' in s or '指名競争' in s:
                    bid_method = '一般競争入札'
                    break

            # Extract contract_name: first long non-date non-amount span
            # (typically the contract name is in the leftmost block, not this block)
            # For legacy format, contract names are in separate blocks; we skip them here
            # and just record what we have
            contract_name = None
            for s in spans:
                if len(s) < 8:
                    continue
                if RE_REIWA_DATE_FULL.search(s):
                    continue
                if RE_LARGE_AMOUNT.match(s.replace(',', '')):
                    continue
                try:
                    float(s.replace(',', ''))
                    continue
                except ValueError:
                    pass
                if '月' in s and '日' in s:
                    continue
                # Likely a name or address line
                if contract_name is None:
                    contract_name = s
                break

            if contract_amount is None:
                continue

            records.append({
                'contract_name':       contract_name,
                'contracting_officer': None,
                'contract_date':       contract_date,
                'vendor_name':         None,
                'vendor_address':      None,
                'corporate_number':    None,
                'bid_method':          bid_method,
                'contract_basis':      None,
                'planned_price':       planned_price,
                'contract_amount':     contract_amount,
                'award_rate':          award_rate,
                'procurement_type':    ptype,
            })

    doc.close()
    return records


def parse_tcab_pdf(pdf_path, bid_or_zui, reiwa_year_hint=None, month_hint=None):
    lines = extract_pdf_lines(pdf_path)
    if not lines:
        return []

    # Check for corporate numbers on any page
    has_corp_nums = any(classify_line(ln['text']) == 'corp_num' for ln in lines)

    if not has_corp_nums:
        # Legacy format (r02_* through early r03_*): use block-based parser
        return parse_tcab_pdf_legacy(pdf_path, bid_or_zui,
                                     reiwa_year_hint or 2, month_hint or 4)

    pages = {}
    for ln in lines:
        pages.setdefault(ln['page'], []).append(ln)
    all_records = []
    for page_num in sorted(pages.keys()):
        page_lines = sorted(pages[page_num], key=lambda l: l['y_global'])
        ptype = detect_page_type(page_lines)
        if ptype is None:
            continue
        all_records.extend(parse_records_from_lines(page_lines, ptype, bid_or_zui))
    return all_records


def parse_wcab_pdf(pdf_path, file_prefix):
    # WCAB prefix: kk/kz=建設工事, bk/bz=物品役務
    procurement_type = '建設工事' if file_prefix in ('kk', 'kz') else '物品役務'
    bid_or_zui = 'bid' if file_prefix in ('kk', 'bk') else 'zui'
    lines = extract_pdf_lines(pdf_path)
    if not lines:
        return []
    pages = {}
    for ln in lines:
        pages.setdefault(ln['page'], []).append(ln)
    all_records = []
    for page_num in sorted(pages.keys()):
        page_lines = sorted(pages[page_num], key=lambda l: l['y_global'])
        all_records.extend(parse_records_from_lines(page_lines, procurement_type, bid_or_zui))
    return all_records

# ============================================================
# DB helpers
# ============================================================

def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def setup_db(conn):
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(contracts)")
    cols = [r[1] for r in cur.fetchall()]
    if 'source' not in cols:
        cur.execute("ALTER TABLE contracts ADD COLUMN source TEXT")
        conn.commit()


def get_existing_source_files(conn):
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT source_file FROM contracts WHERE source_file IS NOT NULL")
    return {r[0] for r in cur.fetchall()}


def insert_records(conn, records, source, source_file, dry_run=False):
    cur = conn.cursor()
    inserted = skipped = 0
    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy is None:
            skipped += 1
            continue
        if dry_run:
            inserted += 1
            continue
        try:
            cur.execute("""
                INSERT INTO contracts (
                    fiscal_year, procurement_type, bid_method,
                    contract_name, contracting_officer, contract_date,
                    vendor_name, vendor_address, corporate_number,
                    contract_basis, planned_price, contract_amount, award_rate,
                    notes, source_file, source
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                fy,
                rec.get('procurement_type', '物品役務'),
                rec.get('bid_method', ''),
                rec.get('contract_name'),
                rec.get('contracting_officer'),
                rec.get('contract_date'),
                rec.get('vendor_name'),
                rec.get('vendor_address'),
                rec.get('corporate_number'),
                rec.get('contract_basis'),
                rec.get('planned_price'),
                rec.get('contract_amount'),
                rec.get('award_rate'),
                None,
                source_file,
                source,
            ))
            inserted += 1
        except sqlite3.Error as e:
            print(f"  DB error: {e}")
            skipped += 1
    if not dry_run:
        conn.commit()
    return inserted, skipped

# ============================================================
# TCAB workflow
# ============================================================

def run_tcab(conn, dry_run=False):
    print("\n=== TCAB FY2020/2021 ===")
    existing = get_existing_source_files(conn)
    stats = {'inserted': 0, 'skipped_db': 0, 'skipped_404': 0, 'parse_failed': 0}

    for _, url, reiwa_year, month, bid_or_zui in tcab_urls_fy2020_2021():
        fname = url.split('/')[-1]
        if fname in existing:
            stats['skipped_db'] += 1
            continue

        fpath = PDF_DIR / fname
        ok = download_direct(url, fpath)
        if not ok:
            stats['skipped_404'] += 1
            continue

        # Pass reiwa_year/month hints for legacy fallback parser
        records = parse_tcab_pdf(fpath, bid_or_zui,
                                  reiwa_year_hint=reiwa_year, month_hint=month)
        if not records:
            stats['parse_failed'] += 1
            print(f"  {fname}: 0 records (parse failed)")
            continue

        ins, skp = insert_records(conn, records, 'tcab', fname, dry_run)
        stats['inserted'] += ins
        print(f"  {fname}: {len(records)} parsed, {ins} inserted")
        time.sleep(0.3)

    print(f"TCAB: inserted={stats['inserted']}, 404={stats['skipped_404']}, "
          f"already_in_db={stats['skipped_db']}, parse_failed={stats['parse_failed']}")
    return stats

# ============================================================
# WCAB workflow
# ============================================================

def wcab_fname_to_fy_hint(fname):
    """Estimate FY from WCAB filename date portion."""
    # Patterns: bk_YYYYMM.pdf, bk_YYYYMMDD.pdf, bk_2021109.pdf (typo for 202109)
    base = fname  # already the basename
    # 8-digit date (YYYYMMDD)
    m = re.search(r'_(\d{4})(\d{2})(\d{2})\.pdf$', base)
    if m:
        yr, mo = int(m.group(1)), int(m.group(2))
        return yr if mo >= 4 else yr - 1
    # 6-digit (YYYYMM)
    m = re.search(r'_(\d{4})(\d{2})\.pdf$', base)
    if m:
        yr, mo = int(m.group(1)), int(m.group(2))
        return yr if mo >= 4 else yr - 1
    # Typo patterns like bk_2021109.pdf (= 2021-09? or 2021-10-09?)
    m = re.search(r'_(\d{4})(\d{3})\.pdf$', base)
    if m:
        yr = int(m.group(1))
        rest = m.group(2)
        # Treat as YYYYMMX where first 2 of rest are month: 109 → mo=10
        mo = int(rest[:2])
        return yr if mo >= 4 else yr - 1
    # 4-digit month (YYMM format older files like 2109)
    m = re.search(r'_(\d{2})(\d{2})\.pdf$', base)
    if m:
        yr = 2000 + int(m.group(1))
        mo = int(m.group(2))
        return yr if mo >= 4 else yr - 1
    return None


def run_wcab(conn, dry_run=False):
    print("\n=== WCAB FY2020/2021 (WARP published.html) ===")
    existing = get_existing_source_files(conn)
    stats = {'inserted': 0, 'skipped_db': 0, 'skipped_404': 0,
             'parse_failed': 0, 'fy_skip': 0}

    wcab_files = discover_wcab_urls_via_warp()
    if not wcab_files:
        print("  No WCAB files found.")
        return stats

    TARGET_FY = {2020, 2021}

    for fname, warp_dl_url in sorted(wcab_files):
        # Estimate FY from filename
        file_fy = wcab_fname_to_fy_hint(fname)
        if file_fy not in TARGET_FY:
            stats['fy_skip'] += 1
            continue

        # Dedup check
        if fname in existing:
            stats['skipped_db'] += 1
            continue

        fpath = PDF_DIR / f'wcab_{fname}'
        ok = download_direct(warp_dl_url, fpath)
        if not ok:
            stats['skipped_404'] += 1
            print(f"  FAIL: {fname}")
            continue

        prefix_m = re.match(r'^([a-z]{2})', fname.lower())
        if not prefix_m:
            continue
        prefix = prefix_m.group(1)

        records = parse_wcab_pdf(fpath, prefix)
        if not records:
            # Legacy WCAB files might also lack corp nums - try legacy approach
            records = parse_tcab_pdf_legacy(fpath, 'bid' if prefix in ('bk', 'kk') else 'zui',
                                             reiwa_year_hint=file_fy - 2018,
                                             month_hint=4)
            # Override procurement_type based on prefix
            ptype = '建設工事' if prefix in ('kk', 'kz') else '物品役務'
            for r in records:
                r['procurement_type'] = ptype

        if not records:
            stats['parse_failed'] += 1
            print(f"  {fname}: 0 records")
            continue

        # Filter to target FY (the file may contain multiple FYs due to rolling window)
        records_target = [r for r in records
                          if date_to_fy(r.get('contract_date')) in TARGET_FY]
        if not records_target:
            stats['fy_skip'] += 1
            continue

        ins, skp = insert_records(conn, records_target, 'wcab', fname, dry_run)
        stats['inserted'] += ins
        print(f"  {fname} (fy~{file_fy}): {len(records)} parsed, {ins} target-FY inserted")
        time.sleep(0.4)

    print(f"WCAB: inserted={stats['inserted']}, 404/fail={stats['skipped_404']}, "
          f"already_in_db={stats['skipped_db']}, fy_outside_target={stats['fy_skip']}")
    return stats

# ============================================================
# Summary
# ============================================================

def print_summary(conn):
    cur = conn.cursor()
    print("\n" + "=" * 60)
    print("DB SUMMARY (FY2020-2025)")
    print("=" * 60)
    cur.execute("""
        SELECT fiscal_year, source, COUNT(*),
               ROUND(SUM(COALESCE(contract_amount,0))/1e8, 1)
        FROM contracts
        WHERE source IN ('tcab','wcab')
        GROUP BY fiscal_year, source
        ORDER BY fiscal_year, source
    """)
    print(f"{'FY':<6} {'Source':<8} {'Count':>8} {'Amount(億)':>12}")
    print("-" * 36)
    for fy, src, cnt, amt in cur.fetchall():
        print(f"{fy or '?':<6} {src:<8} {cnt:>8,} {(amt or 0):>12,.1f}")

    cur.execute("""
        SELECT fiscal_year, COUNT(*),
               ROUND(SUM(COALESCE(contract_amount,0))/1e8, 1)
        FROM contracts
        GROUP BY fiscal_year ORDER BY fiscal_year
    """)
    print(f"\n{'FY':<6} {'Total':>10} {'Amount(億)':>14}")
    print("-" * 32)
    for fy, cnt, amt in cur.fetchall():
        print(f"{fy or '?':<6} {cnt:>10,} {(amt or 0):>14,.1f}")

# ============================================================
# Main
# ============================================================

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--source', choices=['tcab', 'wcab', 'both'], default='both')
    args = ap.parse_args()

    conn = sqlite3.connect(str(DB_PATH))
    setup_db(conn)

    if args.source in ('tcab', 'both'):
        run_tcab(conn, dry_run=args.dry_run)

    if args.source in ('wcab', 'both'):
        run_wcab(conn, dry_run=args.dry_run)

    if not args.dry_run:
        print_summary(conn)

    conn.close()


if __name__ == '__main__':
    main()
