#!/usr/bin/env python3
"""
FY2020〜FY2024 の5年分予算比較 JSON を生成する。
出力: data/output/budget_vs_db_5yr.json
"""

import sqlite3
import json
from datetime import date
from pathlib import Path

PROJECT    = Path(__file__).parent
DB_ATC     = PROJECT / 'data/db/atc_procurement.db'
OUTPUT_DIR = PROJECT / 'data/output'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_PATH = OUTPUT_DIR / 'budget_vs_db_5yr.json'

# ============================================================
# 予算データ (億円) — ユーザー提供値
# ============================================================
BUDGET_RAW = {
    2020: {'total': 3922, 'borrowing': 300, 'personnel': 800, 'reiwa': 2, 'note': 'R2 空港整備勘定（推計）'},
    2021: {'total': 3938, 'borrowing': 312, 'personnel': 810, 'reiwa': 3, 'note': 'R3 空港整備勘定（推計）'},
    2022: {'total': 3942, 'borrowing': 320, 'personnel': 815, 'reiwa': 4, 'note': 'R4 空港整備勘定（確定）'},
    2023: {'total': 3959, 'borrowing': 330, 'personnel': 820, 'reiwa': 5, 'note': 'R5 空港整備勘定（確定）'},
    2024: {'total': 3959, 'borrowing': 427, 'personnel': 827, 'reiwa': 6, 'note': 'R6 空港整備勘定（確定）'},
}

# 確定済み調達母数 (CLAUDE.md より)
CONFIRMED_PROC_BASE = {2022: 2137, 2023: 2147, 2024: 2407}

# FY2020/2021 の misc (その他非調達経費) は FY2022 に合わせて推計
MISC_OTHER_EST = 670

def calc_proc_base(fy):
    if fy in CONFIRMED_PROC_BASE:
        return CONFIRMED_PROC_BASE[fy]
    b = BUDGET_RAW[fy]
    return b['total'] - b['personnel'] - b['borrowing'] - MISC_OTHER_EST

def query_db():
    conn = sqlite3.connect(str(DB_ATC))
    cur = conn.cursor()

    cur.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(contract_amount)/1e8, 2)
        FROM contracts WHERE fiscal_year BETWEEN 2020 AND 2024
        GROUP BY fiscal_year ORDER BY fiscal_year
    """)
    contracts_totals = {row[0]: (row[1], row[2]) for row in cur.fetchall()}

    cur.execute("""
        SELECT fiscal_year,
            ROUND(SUM(CASE WHEN source_file LIKE 'fy%.xlsx' OR source_file LIKE 'fy%.xls' THEN contract_amount ELSE 0 END)/1e8, 2),
            ROUND(SUM(CASE WHEN source_file LIKE 'r%_bid.pdf' OR source_file LIKE 'r%_zui.pdf' THEN contract_amount ELSE 0 END)/1e8, 2),
            ROUND(SUM(CASE WHEN (source_file LIKE 'b%_%' OR source_file LIKE 'k%_%') THEN contract_amount ELSE 0 END)/1e8, 2)
        FROM contracts WHERE fiscal_year BETWEEN 2020 AND 2024
        GROUP BY fiscal_year ORDER BY fiscal_year
    """)
    by_source = {row[0]: {'honkyoku': row[1] or 0, 'tcab': row[2] or 0, 'wcab': row[3] or 0}
                 for row in cur.fetchall()}

    cur.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(award_amount)/1e8, 2)
        FROM pas_airport_contracts WHERE fiscal_year BETWEEN 2020 AND 2024
        GROUP BY fiscal_year ORDER BY fiscal_year
    """)
    pas_totals = {row[0]: (row[1], row[2]) for row in cur.fetchall()}

    conn.close()
    return contracts_totals, by_source, pas_totals

def main():
    contracts_totals, by_source, pas_totals = query_db()

    fiscal_years = {}
    for fy in range(2020, 2025):
        b = BUDGET_RAW[fy]
        total = b['total']
        borrowing = b['borrowing']
        personnel = b['personnel']
        proc_base = calc_proc_base(fy)
        misc_other = total - personnel - borrowing - proc_base

        c_count, c_oku = contracts_totals.get(fy, (0, 0.0))
        p_count, p_oku = pas_totals.get(fy, (0, 0.0))
        c_oku = c_oku or 0.0
        p_oku = p_oku or 0.0
        combined_oku = round(c_oku + p_oku, 2)
        coverage_pct = round(combined_oku / proc_base * 100, 1) if proc_base else 0

        src = by_source.get(fy, {'honkyoku': 0, 'tcab': 0, 'wcab': 0})

        fiscal_years[str(fy)] = {
            'fy': fy,
            'reiwa_year': b['reiwa'],
            'budget': {
                'total_expenditure_oku': total,
                'personnel_oku': personnel,
                'borrowing_repayment_oku': borrowing,
                'misc_non_procurement_oku': misc_other,
                'procurement_base_oku': proc_base,
                'source_note': b['note'],
            },
            'db': {
                'contracts': {'total_count': c_count, 'total_oku': c_oku, 'by_source': src},
                'pas_airport': {'total_count': p_count, 'total_oku': p_oku},
                'combined_count': (c_count or 0) + (p_count or 0),
                'combined_oku': combined_oku,
            },
            'coverage': {
                'db_oku': combined_oku,
                'procurement_base_oku': proc_base,
                'coverage_pct': coverage_pct,
            },
        }

    avg_cov = round(sum(v['coverage']['coverage_pct'] for v in fiscal_years.values()) / 5, 1)
    out = {
        'generated': str(date.today()),
        'note': '航空管制調達DB FY2020-2024 5年分予算比較',
        'units': '億円',
        'coverage_note': 'DB実績(contracts+PAS) / 調達母数 = 網羅率',
        'fiscal_years': fiscal_years,
        'summary': {'fy_range': '2020-2024', 'avg_coverage_pct': avg_cov},
    }

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"Written: {OUTPUT_PATH}")

    print(f"\n{'FY':>4} {'歳出':>6} {'調達母数':>6} {'DB収録':>7} {'網羅率':>7}")
    for fy in range(2020, 2025):
        d = fiscal_years[str(fy)]
        print(f"{fy:>4} {d['budget']['total_expenditure_oku']:>6,} "
              f"{d['budget']['procurement_base_oku']:>6,} "
              f"{d['db']['combined_oku']:>7.1f} "
              f"{d['coverage']['coverage_pct']:>6.1f}%")
    print(f"\n5年平均網羅率: {avg_cov}%")

if __name__ == '__main__':
    main()
