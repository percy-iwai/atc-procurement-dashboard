#!/usr/bin/env python3
"""
WCAB Q4 FY2024 (bk/kk 2501-2503) - 新フォーマット対応パーサー

2025年以降のWCABファイルは法人番号と入札方式が同一XMLラインに結合されている
  例: "7340001001064 一般競争入札"
collect_atc_monthly.py の COL_GAP=12pt では分離できないため、
法人番号先頭13桁を個別セグメントとして抽出する後処理を追加。
"""

import re
import sys
import time
import sqlite3
from pathlib import Path

try:
    import fitz
    import xml.etree.ElementTree as ET
except ImportError:
    print("ERROR: PyMuPDF not installed.")
    sys.exit(1)

sys.path.insert(0, str(Path(__file__).parent))
from collect_atc_monthly import (
    PDF_DIR, DB_PATH,
    download_pdf, setup_db, print_summary,
    parse_records_from_lines, detect_page_type,
    parse_reiwa_date_str, parse_amount_str, parse_rate_str,
    date_to_fy, classify_line, is_page_header,
    RE_TWOAMOUNTS, RE_REIWA_DATE, RE_CORP_NUM, REIWA_BASE
)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

RE_CORP_NUM_PREFIX = re.compile(r'^(\d{13})(.*)$', re.DOTALL)


# ============================================================
# 修正版 extract_pdf_lines: 法人番号+付加文字を分離
# ============================================================

def extract_pdf_lines_v2(pdf_path):
    """
    collect_atc_monthly.extract_pdf_lines と同じ処理だが、
    セグメントテキストが「13桁数字 + 付加文字」で始まる場合に分割する。
    """
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening PDF: {e}")
        return []

    result = []
    for page_num, page in enumerate(doc):
        try:
            xml_str = page.get_text('xml')
            root = ET.fromstring(xml_str)
        except Exception:
            continue

        for line in root.findall('.//line'):
            chars_with_x = []
            for char in line.findall('.//char'):
                c = char.get('c', '')
                if not c:
                    continue
                try:
                    cx = float(char.get('x', '0'))
                    bbox = line.get('bbox', '')
                    parts = bbox.split()
                    if len(parts) >= 4:
                        y0, y1 = float(parts[1]), float(parts[3])
                    else:
                        y0 = y1 = 0.0
                    chars_with_x.append((cx, (y0 + y1) / 2, c))
                except Exception:
                    continue

            if not chars_with_x:
                text = line.get('text', '').strip()
                if not text:
                    continue
                bbox = line.get('bbox', '')
                try:
                    x0, y0, x1, y1 = [float(v) for v in bbox.split()]
                except Exception:
                    continue
                y_center = (y0 + y1) / 2
                result.append({
                    'page': page_num, 'x_min': x0, 'x_max': x1,
                    'y_page': y_center, 'y_global': page_num * 1000 + y_center,
                    'text': text,
                })
                continue

            # Group chars into column-segments (COL_GAP=12pt as before)
            COL_GAP = 12.0
            segments = []
            seg_chars = [chars_with_x[0]]
            for i in range(1, len(chars_with_x)):
                prev_x = chars_with_x[i - 1][0]
                curr_x = chars_with_x[i][0]
                if curr_x - prev_x > COL_GAP:
                    segments.append(seg_chars)
                    seg_chars = [chars_with_x[i]]
                else:
                    seg_chars.append(chars_with_x[i])
            segments.append(seg_chars)

            y_center = chars_with_x[0][1]
            for seg in segments:
                seg_text = ''.join(c for _, _, c in seg).strip()
                if not seg_text:
                    continue
                x_min = seg[0][0]
                x_max = seg[-1][0] + 8

                # ---- NEW: split "13-digit corp_num + trailing text" ----
                m = RE_CORP_NUM_PREFIX.match(seg_text)
                if m and m.group(2).strip():
                    corp_part = m.group(1)
                    rest_part = m.group(2).strip()
                    # x_split: position of 14th char
                    split_idx = 13
                    if len(seg) > split_idx:
                        x_split = seg[split_idx][0]
                    else:
                        x_split = x_min + split_idx * 3.2  # approx
                    result.append({
                        'page': page_num, 'x_min': x_min, 'x_max': x_split - 1,
                        'y_page': y_center, 'y_global': page_num * 1000 + y_center,
                        'text': corp_part,
                    })
                    result.append({
                        'page': page_num, 'x_min': x_split, 'x_max': x_max,
                        'y_page': y_center, 'y_global': page_num * 1000 + y_center,
                        'text': rest_part,
                    })
                    continue

                result.append({
                    'page': page_num, 'x_min': x_min, 'x_max': x_max,
                    'y_page': y_center, 'y_global': page_num * 1000 + y_center,
                    'text': seg_text,
                })

    doc.close()
    return result


def parse_wcab_pdf_v2(pdf_path, file_prefix):
    """WCACPDFを新フォーマット対応パーサーで解析"""
    if file_prefix in ('kk', 'kz'):
        procurement_type = '建設工事'
    else:
        procurement_type = '物品役務'
    bid_or_zui = 'bid' if file_prefix in ('kk', 'bk') else 'zui'

    lines = extract_pdf_lines_v2(pdf_path)
    if not lines:
        return []

    pages = {}
    for ln in lines:
        pages.setdefault(ln['page'], []).append(ln)

    all_records = []
    for page_num in sorted(pages.keys()):
        page_lines = sorted(pages[page_num], key=lambda l: l['y_global'])
        recs = parse_records_from_lines(page_lines, procurement_type, bid_or_zui)
        all_records.extend(recs)
    return all_records


# ============================================================
# DB insert (reuse from collect_atc_monthly)
# ============================================================

def insert_records(conn, records, source, source_file):
    cur = conn.cursor()
    inserted = skipped = 0
    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy is None:
            skipped += 1
            continue
        try:
            cur.execute("""
                INSERT INTO contracts (
                    fiscal_year, procurement_type, bid_method,
                    contract_name, contracting_officer, contract_date,
                    vendor_name, vendor_address, corporate_number,
                    contract_basis, planned_price, contract_amount, award_rate,
                    notes, source_file, source
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                fy,
                rec.get('procurement_type', '物品役務'),
                rec.get('bid_method', ''),
                rec.get('contract_name'),
                rec.get('contracting_officer'),
                rec.get('contract_date'),
                rec.get('vendor_name'),
                rec.get('vendor_address'),
                rec.get('corporate_number'),
                rec.get('contract_basis'),
                rec.get('planned_price'),
                rec.get('contract_amount'),
                rec.get('award_rate'),
                None,
                source_file,
                source,
            ))
            inserted += 1
        except sqlite3.Error as e:
            print(f"  DB error: {e}")
            skipped += 1
    conn.commit()
    return inserted, skipped


# ============================================================
# Target files
# ============================================================

WCAB_Q4_NEW = [
    ('https://www.cab.mlit.go.jp/wcab/file/bk_2501.pdf', 'bk'),
    ('https://www.cab.mlit.go.jp/wcab/file/bk_2502.pdf', 'bk'),
    ('https://www.cab.mlit.go.jp/wcab/file/bk_2503.pdf', 'bk'),
    ('https://www.cab.mlit.go.jp/wcab/file/kk_2501.pdf', 'kk'),
    ('https://www.cab.mlit.go.jp/wcab/file/kk_2502.pdf', 'kk'),
    ('https://www.cab.mlit.go.jp/wcab/file/kk_2503.pdf', 'kk'),
]


def main():
    conn = sqlite3.connect(str(DB_PATH))
    setup_db(conn)

    # Get existing source files
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT source_file FROM contracts")
    existing = set(r[0] for r in cur.fetchall())

    total_inserted = 0

    print("=== WCAB Q4 新フォーマット対応収集 ===\n")
    for url, prefix in WCAB_Q4_NEW:
        fname = url.split('/')[-1]
        cached_fname = f'wcab_{fname}'

        if fname in existing or cached_fname in existing:
            print(f"  SKIP (already in DB): {fname}")
            continue

        fpath = PDF_DIR / cached_fname
        ok = download_pdf(url, fpath)
        if not ok:
            print(f"  404: {fname}")
            continue

        records = parse_wcab_pdf_v2(fpath, prefix)
        if not records:
            print(f"  WARN: 0 records from {fname} (要手動確認)")
            continue

        ins, skp = insert_records(conn, records, 'wcab', fname)
        total_inserted += ins
        print(f"  {fname}: {len(records)} parsed → {ins} inserted, {skp} skipped")

        # Show FY breakdown
        from collections import Counter
        fy_ctr = Counter(date_to_fy(r.get('contract_date')) for r in records)
        for fy, cnt in sorted((k,v) for k,v in fy_ctr.items() if k is not None):
            print(f"    FY{fy}: {cnt}件")
        time.sleep(0.5)

    print(f"\n合計追加: {total_inserted}件")
    print_summary(conn)
    conn.close()


if __name__ == '__main__':
    main()
