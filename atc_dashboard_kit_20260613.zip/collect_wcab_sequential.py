#!/usr/bin/env python3
"""
WCAB (大阪航空局) 連番 PDF FY2015-2019 収集・パーススクリプト

WARP published.html (ts=20210301154504, coll=20210331) に
  bk (1).pdf ~ bk (64).pdf など連番PDF 255件が存在。
これらは H27(FY2015)〜R01(FY2019) 時代のデータ。

ダウンロードURL例:
  https://warp.ndl.go.jp/20210331/20210301154504id_/
  https://www.cab.mlit.go.jp/wcab/file/pdf/bk%20(1).pdf

各ファイルをパースして contract_date からFYを判定し、FY2015〜FY2019のレコードのみ挿入。

Usage:
    python collect_wcab_sequential.py [--dry-run] [--skip-download]
"""

import re
import sys
import time
import sqlite3
import argparse
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path

try:
    import fitz
except ImportError:
    print("ERROR: PyMuPDF not installed")
    sys.exit(1)

PROJECT  = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR  = PROJECT / 'data/pdfs/wcab_sequential'
PDF_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

# WARP snapshot of published.html (captured Mar 2021)
WARP_COLL = '20210331'
WARP_TS   = '20210301154504'
WCAB_FILE_PDF_BASE = 'https://www.cab.mlit.go.jp/wcab/file/pdf/'

HEISEI_BASE = 1988
REIWA_BASE  = 2018

TARGET_FY = set(range(2015, 2020))  # FY2015-FY2019

FILE_TYPES = ['bk', 'bz', 'kk', 'kz']
# N ranges per type (from published.html analysis)
N_MAX = {'bk': 64, 'bz': 64, 'kk': 64, 'kz': 63}

TYPE_MAP = {
    'bk': ('建設工事', '一般競争入札'),
    'bz': ('建設工事', '随意契約'),
    'kk': ('物品役務', '一般競争入札'),
    'kz': ('物品役務', '随意契約'),
}

RE_HEISEI_DATE  = re.compile(r'平成(\d{1,2})年(\d{1,2})月(\d{1,2})日')
RE_REIWA_DATE   = re.compile(r'令和(\d{1,2})年(\d{1,2})月(\d{1,2})日')
RE_AMOUNT_YEN   = re.compile(r'^[\d,]+円$')
RE_RATE_PCT     = re.compile(r'^[\d.]+%$')


def hm_date_to_ymd(text):
    m = RE_HEISEI_DATE.search(text)
    if m:
        hy, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= hy <= 64 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{HEISEI_BASE + hy}{mo:02d}{dd:02d}'
    m = RE_REIWA_DATE.search(text)
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{REIWA_BASE + ry}{mo:02d}{dd:02d}'
    return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def download_sequential(fname_raw, dest_path):
    """Download bk (N).pdf from WARP."""
    if dest_path.exists() and dest_path.stat().st_size > 500:
        return True

    # URL-encode the filename (space → %20, parens → %28/%29)
    fname_enc = urllib.parse.quote(fname_raw)
    orig_url  = WCAB_FILE_PDF_BASE + fname_raw  # literal (for WARP path)
    orig_url_enc = WCAB_FILE_PDF_BASE + fname_enc

    warp_url = (f'https://warp.ndl.go.jp/{WARP_COLL}/{WARP_TS}id_/'
                + orig_url_enc)

    for attempt in range(3):
        try:
            req  = urllib.request.Request(warp_url, headers=HEADERS)
            resp = urllib.request.urlopen(req, timeout=30)
            data = resp.read()
            if len(data) < 500:
                return False
            if not data.startswith(b'%PDF'):
                return False
            dest_path.write_bytes(data)
            return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return False
            if attempt < 2:
                time.sleep(3)
        except Exception:
            if attempt < 2:
                time.sleep(3)
    return False


SKIP_KEYWORDS = ('公共調達の適正化', '物品役務等の名称及び数量', '公共工事の名称',
                  '契約担当官等の氏名', 'の名称及び所在地', '契約を締結した日',
                  '契約の相手方の商号', '又は名称及び住所', '一般競争入札・指名',
                  '競争入札の別', '総合評価の実施', '予定価格', '契約金額', '落札率', '備考',
                  '随意契約によること')


def is_header_block(spans):
    return any(any(kw in s for kw in SKIP_KEYWORDS) for s in spans)


def _block_spans(block):
    spans = []
    for line in block.get('lines', []):
        for span in line.get('spans', []):
            t = span.get('text', '').strip()
            if t:
                spans.append(t)
    return spans


def _parse_amount_yen(s):
    t = s.replace(',', '').replace('円', '').strip()
    try:
        v = float(t)
        return v if v >= 1 else None
    except Exception:
        return None


def _parse_rate(s):
    t = s.strip().rstrip('%')
    try:
        v = float(t)
        return v if 0 < v <= 100 else None
    except Exception:
        return None


def parse_wcab_sequential_pdf(pdf_path, ftype):
    """
    Parse WCAB sequential PDF (same block structure as H25/H26 era):
      Block N  : contract_name
      Block N+1: contracting_officer
      Block N+2: contract_date
      Block N+3: vendor_name
      Block N+4: bid_method + planned_yen + contract_yen + rate%
    """
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening {pdf_path.name}: {e}")
        return []

    ptype, bid_method_default = TYPE_MAP.get(ftype, ('物品役務', '一般競争入札'))
    records = []

    for page in doc:
        page_text = page.get_text()
        if not page_text.strip():
            continue

        d = page.get_text('dict')
        all_blocks = [_block_spans(b) for b in d.get('blocks', [])]

        for i, spans in enumerate(all_blocks):
            if not spans:
                continue

            yen_amounts = [s for s in spans if RE_AMOUNT_YEN.match(s)]
            rates       = [s for s in spans if RE_RATE_PCT.match(s)]
            if len(yen_amounts) < 2 or not rates:
                continue

            planned_price   = _parse_amount_yen(yen_amounts[0])
            contract_amount = _parse_amount_yen(yen_amounts[1])
            if planned_price and contract_amount and planned_price < contract_amount:
                planned_price, contract_amount = contract_amount, planned_price
            if contract_amount is None or contract_amount < 1:
                continue

            award_rate = _parse_rate(rates[0])
            bid_method = bid_method_default
            for s in spans:
                if '随意契約' in s and len(s) < 25:
                    bid_method = '随意契約'
                    break
                if '競争入札' in s or '指名競争' in s:
                    bid_method = '一般競争入札'
                    break

            contract_date  = None
            vendor_name    = None
            contract_name  = None

            for j in range(i - 1, max(i - 7, -1), -1):
                prev = all_blocks[j]
                if not prev or is_header_block(prev):
                    break
                if contract_date is None:
                    for s in prev:
                        d_str = hm_date_to_ymd(s)
                        if d_str:
                            contract_date = d_str
                            break
                if vendor_name is None and contract_date is None:
                    non_hdr = [s for s in prev if len(s) > 2
                               and not any(kw in s for kw in SKIP_KEYWORDS)]
                    if non_hdr:
                        vendor_name = non_hdr[0]
                if contract_name is None:
                    for s in prev:
                        if len(s) > 8 and any(kw in s for kw in ('年度', '事業', '業務', '工事', '整備', '委託')):
                            if not is_header_block([s]):
                                contract_name = s
                                break

            if not contract_date:
                continue  # Skip records without parseable dates

            records.append({
                'contract_name':       contract_name,
                'contracting_officer': None,
                'contract_date':       contract_date,
                'vendor_name':         vendor_name,
                'vendor_address':      None,
                'corporate_number':    None,
                'bid_method':          bid_method,
                'contract_basis':      None,
                'planned_price':       planned_price,
                'contract_amount':     contract_amount,
                'award_rate':          award_rate,
                'procurement_type':    ptype,
            })

    doc.close()
    return records


def setup_db(conn):
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(contracts)")
    cols = [r[1] for r in cur.fetchall()]
    if 'source' not in cols:
        cur.execute("ALTER TABLE contracts ADD COLUMN source TEXT")
        conn.commit()


def get_existing_source_files(conn):
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT source_file FROM contracts WHERE source_file IS NOT NULL")
    return {r[0] for r in cur.fetchall()}


def insert_records(conn, records, source_file, dry_run=False):
    cur = conn.cursor()
    ins = skip = 0
    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy not in TARGET_FY:
            skip += 1
            continue
        if dry_run:
            ins += 1
            continue
        try:
            cur.execute("""
                INSERT INTO contracts (
                    fiscal_year, procurement_type, bid_method,
                    contract_name, contracting_officer, contract_date,
                    vendor_name, vendor_address, corporate_number,
                    contract_basis, planned_price, contract_amount, award_rate,
                    notes, source_file, source
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                fy,
                rec.get('procurement_type', '物品役務'),
                rec.get('bid_method', ''),
                rec.get('contract_name'),
                rec.get('contracting_officer'),
                rec.get('contract_date'),
                rec.get('vendor_name'),
                rec.get('vendor_address'),
                rec.get('corporate_number'),
                rec.get('contract_basis'),
                rec.get('planned_price'),
                rec.get('contract_amount'),
                rec.get('award_rate'),
                None,
                source_file,
                'wcab',
            ))
            ins += 1
        except sqlite3.Error as e:
            print(f"  DB error: {e}")
            skip += 1
    if not dry_run:
        conn.commit()
    return ins, skip


def main():
    ap = argparse.ArgumentParser(description='WCAB連番PDF FY2015-2019 収集')
    ap.add_argument('--dry-run',       action='store_true')
    ap.add_argument('--skip-download', action='store_true')
    args = ap.parse_args()

    sys.stdout.reconfigure(encoding='utf-8')

    conn = sqlite3.connect(str(DB_PATH))
    setup_db(conn)
    existing = get_existing_source_files(conn)

    total_dl = total_parsed = total_inserted = total_404 = total_skip_db = 0
    fy_dist = {}

    for ftype in FILE_TYPES:
        n_max = N_MAX[ftype]
        for n in range(1, n_max + 1):
            fname_raw   = f'{ftype} ({n}).pdf'
            local_fname = f'wcab_seq_{ftype}_{n:03d}.pdf'

            if local_fname in existing:
                total_skip_db += 1
                continue

            dest_path = PDF_DIR / local_fname

            if not args.skip_download:
                ok = download_sequential(fname_raw, dest_path)
                if not ok:
                    print(f"  [404] {fname_raw}")
                    total_404 += 1
                    continue
                total_dl += 1
                time.sleep(0.25)
            else:
                if not dest_path.exists():
                    total_404 += 1
                    continue

            records = parse_wcab_sequential_pdf(dest_path, ftype)
            total_parsed += len(records)

            if not records:
                continue

            # Show date range of this file
            dates = [r.get('contract_date') for r in records if r.get('contract_date')]
            min_d = min(dates) if dates else '?'
            max_d = max(dates) if dates else '?'
            fy_counts = {}
            for r in records:
                fy = date_to_fy(r.get('contract_date'))
                fy_counts[fy] = fy_counts.get(fy, 0) + 1

            ins, skp = insert_records(conn, records, local_fname, args.dry_run)
            total_inserted += ins
            for fy, cnt in fy_counts.items():
                fy_dist[fy] = fy_dist.get(fy, 0) + cnt

            if ins > 0:
                print(f"  {local_fname} ({ftype}): {len(records)}件 {min_d[:6]}-{max_d[:6]} → inserted={ins} skipped={skp}")
                print(f"    FY dist: {fy_counts}")

    conn.close()

    print(f"\n=== 完了 ===")
    print(f"  downloaded:  {total_dl}")
    print(f"  parsed:      {total_parsed}")
    print(f"  inserted:    {total_inserted}")
    print(f"  not_found:   {total_404}")
    print(f"  skipped_db:  {total_skip_db}")
    print(f"  FY分布 (全パース): {dict(sorted(fy_dist.items()))}")

    conn = sqlite3.connect(str(DB_PATH))
    print("\n=== DB summary (WCAB source, FY2015-2019) ===")
    for row in conn.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,1)
        FROM contracts WHERE source='wcab' AND fiscal_year BETWEEN 2015 AND 2019
        GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall():
        print(f"  FY{row[0]}: {row[1]}件  {row[2]}億")
    print("\n=== DB全体 ===")
    for row in conn.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,1)
        FROM contracts GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall():
        print(f"  FY{row[0]}: {row[1]}件  {row[2]}億")
    conn.close()


if __name__ == '__main__':
    main()
