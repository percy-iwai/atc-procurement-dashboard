#!/usr/bin/env python3
"""
FY2024 Q4（R7年1〜3月）TCAB・WCAB 月次PDF 追加収集スクリプト

対象:
  TCAB: r07_01_bid/zui, r07_02_bid/zui, r07_03_bid/zui
  WCAB: bk_2501/2502/2503, kk_2501/2502/2503
        （bz/kz 2501-2503 は既収集済み）
"""

import sys
import time
import sqlite3
from pathlib import Path

# collect_atc_monthly のユーティリティを再利用
sys.path.insert(0, str(Path(__file__).parent))
from collect_atc_monthly import (
    PDF_DIR, DB_PATH,
    download_pdf, parse_tcab_pdf, parse_wcab_pdf,
    insert_records, setup_db, print_summary
)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}

# ============================================================
# 追加収集対象リスト
# ============================================================

TCAB_Q4 = [
    # (url, bid_or_zui)
    ('https://www.cab.mlit.go.jp/tcab/files/r07_01_bid.pdf', 'bid'),
    ('https://www.cab.mlit.go.jp/tcab/files/r07_01_zui.pdf', 'zui'),
    ('https://www.cab.mlit.go.jp/tcab/files/r07_02_bid.pdf', 'bid'),
    ('https://www.cab.mlit.go.jp/tcab/files/r07_02_zui.pdf', 'zui'),
    ('https://www.cab.mlit.go.jp/tcab/files/r07_03_bid.pdf', 'bid'),
    ('https://www.cab.mlit.go.jp/tcab/files/r07_03_zui.pdf', 'zui'),
]

WCAB_Q4 = [
    # (url, file_prefix)
    ('https://www.cab.mlit.go.jp/wcab/file/bk_2501.pdf', 'bk'),
    ('https://www.cab.mlit.go.jp/wcab/file/bk_2502.pdf', 'bk'),
    ('https://www.cab.mlit.go.jp/wcab/file/bk_2503.pdf', 'bk'),
    ('https://www.cab.mlit.go.jp/wcab/file/kk_2501.pdf', 'kk'),
    ('https://www.cab.mlit.go.jp/wcab/file/kk_2502.pdf', 'kk'),
    ('https://www.cab.mlit.go.jp/wcab/file/kk_2503.pdf', 'kk'),
]

# ============================================================
# 重複チェック: 既にDBにあるsource_fileはスキップ
# ============================================================

def get_existing_source_files(conn):
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT source_file FROM contracts")
    return set(r[0] for r in cur.fetchall())


# ============================================================
# メイン
# ============================================================

def main():
    conn = sqlite3.connect(str(DB_PATH))
    setup_db(conn)
    existing = get_existing_source_files(conn)

    total_inserted = 0
    total_skipped_dup = 0

    # --- TCAB Q4 ---
    print("\n=== TCAB Q4 (r07_01〜r07_03) ===")
    for url, bid_or_zui in TCAB_Q4:
        fname = url.split('/')[-1]
        if fname in existing:
            print(f"  SKIP (already in DB): {fname}")
            total_skipped_dup += 1
            continue

        fpath = PDF_DIR / fname
        ok = download_pdf(url, fpath)
        if not ok:
            print(f"  404: {fname}")
            continue

        records = parse_tcab_pdf(fpath, bid_or_zui)
        if not records:
            print(f"  WARN: 0 records parsed from {fname}")
            continue

        ins, skp = insert_records(conn, records, 'tcab', fname, dry_run=False)
        total_inserted += ins
        print(f"  {fname}: {len(records)} parsed → {ins} inserted, {skp} skipped")
        time.sleep(0.5)

    # --- WCAB Q4 ---
    print("\n=== WCAB Q4 (bk/kk 2501〜2503) ===")
    for url, prefix in WCAB_Q4:
        fname = url.split('/')[-1]
        cached_fname = f'wcab_{fname}'  # collect_atc_monthly は wcab_ prefix をつける
        if fname in existing or cached_fname in existing:
            print(f"  SKIP (already in DB): {fname}")
            total_skipped_dup += 1
            continue

        fpath = PDF_DIR / cached_fname
        ok = download_pdf(url, fpath)
        if not ok:
            print(f"  404: {fname}")
            continue

        records = parse_wcab_pdf(fpath, prefix)
        if not records:
            print(f"  WARN: 0 records parsed from {fname}")
            continue

        ins, skp = insert_records(conn, records, 'wcab', fname, dry_run=False)
        total_inserted += ins
        print(f"  {fname}: {len(records)} parsed → {ins} inserted, {skp} skipped")
        time.sleep(0.5)

    print(f"\n合計追加: {total_inserted}件 (重複スキップ: {total_skipped_dup}件)")
    print_summary(conn)
    conn.close()


if __name__ == '__main__':
    main()
