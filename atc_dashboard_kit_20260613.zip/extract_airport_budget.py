"""
空港整備勘定 歳出合計を予算概要PDFから抽出する。
Usage: python extract_airport_budget.py
"""

import json
import os
import re
import time

import fitz  # PyMuPDF
import requests
from bs4 import BeautifulSoup

CACHE_DIR = "data/cache/budget_pdfs"
OUTPUT_FILE = "data/output/budget_all_years.json"
os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs("data/output", exist_ok=True)

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# 既知のPDF URL（年号 → FY変換: 令和N=2018+N年度、平成N=1988+N年度）
KNOWN_URLS = {
    "FY2026": "https://www.mlit.go.jp/page/content/001982277.pdf",  # R8
    "FY2025": "https://www.mlit.go.jp/page/content/001858395.pdf",  # R7
    "FY2024": "https://www.mlit.go.jp/page/content/001720601.pdf",  # R6
    "FY2023": "https://www.mlit.go.jp/page/content/001583485.pdf",  # R5
    "FY2018": "https://www.mlit.go.jp/common/001218123.pdf",        # H30
    "FY2017": "https://www.mlit.go.jp/common/001159187.pdf",        # H29
    "FY2011": "https://www.mlit.go.jp/common/000133656.pdf",        # H23
}

INDEX_URL = "https://www.mlit.go.jp/policy/file000004.html"


def download_pdf(url: str, fy: str) -> str | None:
    """PDFをキャッシュに保存してパスを返す。失敗時はNone。"""
    fname = os.path.join(CACHE_DIR, f"{fy}.pdf")
    if os.path.exists(fname) and os.path.getsize(fname) > 10000:
        return fname
    try:
        r = requests.get(url, headers=HEADERS, timeout=30)
        if r.status_code == 200 and b"%PDF" in r.content[:10]:
            with open(fname, "wb") as f:
                f.write(r.content)
            print(f"  Downloaded {fy}: {len(r.content)//1024}KB")
            return fname
        print(f"  FAILED {fy}: HTTP {r.status_code}")
    except Exception as e:
        print(f"  ERROR {fy}: {e}")
    return None


def fetch_index_links(url: str) -> dict[str, str]:
    """インデックスページから航空局予算概要のPDFリンクを収集する。"""
    print(f"\nFetching index: {url}")
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.encoding = "utf-8"
    soup = BeautifulSoup(r.text, "html.parser")

    links: dict[str, str] = {}
    for a in soup.find_all("a", href=True):
        text = a.get_text(strip=True)
        href = a["href"]
        if not href.endswith(".pdf"):
            continue
        # 年号を含むリンクテキストで航空局予算概要を探す
        if "航空局" in text or "aviation" in text.lower():
            print(f"  Found: {text!r} → {href}")
            links[text] = href

    # リンクが少なければサブページも辿る
    if len(links) < 3:
        for a in soup.find_all("a", href=True):
            text = a.get_text(strip=True)
            href = a["href"]
            if re.search(r"(予算概要|budget)", text, re.I):
                sub_url = href if href.startswith("http") else f"https://www.mlit.go.jp{href}"
                print(f"  Sub-page: {text!r} → {sub_url}")
                try:
                    sub_links = fetch_aviation_pdf_links(sub_url)
                    links.update(sub_links)
                except Exception as e:
                    print(f"    sub-page error: {e}")
    return links


def fetch_aviation_pdf_links(url: str) -> dict[str, str]:
    """サブページから航空局PDFリンクを収集する。"""
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.encoding = "utf-8"
    soup = BeautifulSoup(r.text, "html.parser")
    links = {}
    for a in soup.find_all("a", href=True):
        text = a.get_text(strip=True)
        href = a["href"]
        if not href.endswith(".pdf"):
            continue
        if "航空局" in text or re.search(r"[Hh](2[3-9]|30|31)|[Rr][1-8]", text):
            full = href if href.startswith("http") else f"https://www.mlit.go.jp{href}"
            links[text] = full
    return links


def extract_text_from_pdf(pdf_path: str) -> str:
    """PDFから全テキストを抽出する（最大20ページ）。"""
    doc = fitz.open(pdf_path)
    texts = []
    for i, page in enumerate(doc):
        if i >= 20:
            break
        texts.append(page.get_text())
    doc.close()
    return "\n".join(texts)


def find_budget_total(text: str) -> int | None:
    """
    テキストから空港整備勘定の歳出合計を探す。
    単位は億円（百万円→億円に変換）または兆円表記に対応。
    予算表の「合計」行の数値を取る。
    """
    # 空港整備勘定の総則・合計付近を探す
    # 通常 "空港整備勘定" の近くに合計行がある
    # 金額は百万円単位のことが多い

    lines = text.split("\n")

    # 「空港整備勘定」が出てくる前後50行を対象に数値を探す
    airport_indices = [i for i, l in enumerate(lines) if "空港整備勘定" in l]
    if not airport_indices:
        return None

    # 関連行を収集
    relevant: list[str] = []
    for idx in airport_indices:
        start = max(0, idx - 5)
        end = min(len(lines), idx + 60)
        relevant.extend(lines[start:end])

    full_section = "\n".join(relevant)

    # 「合計」行から金額を探す
    # 形式例: "合計 　 　 1,234,567" （百万円）
    # または "歳出合計 1,234,567"
    patterns = [
        r"歳\s*出\s*合\s*計[^\d]*?([\d,]+)",
        r"合\s*計[^\d]*?([\d,]+)",
        r"空港整備勘定[^\d]{0,30}([\d,]+)",
    ]

    candidates = []
    for pat in patterns:
        for m in re.finditer(pat, full_section):
            val_str = m.group(1).replace(",", "")
            try:
                val = int(val_str)
                if val > 100000:  # 百万円以上なら候補
                    candidates.append(val)
            except ValueError:
                pass

    if not candidates:
        return None

    # 最大値（歳出合計は通常最大の数値）
    return max(candidates)


def parse_year_hint(text: str) -> str | None:
    """PDFテキストから年度を推定する。"""
    m = re.search(r"令和\s*(\d+)\s*年度", text)
    if m:
        ry = int(m.group(1))
        return f"FY{2018 + ry}"
    m = re.search(r"平成\s*(\d+)\s*年度", text)
    if m:
        hy = int(m.group(1))
        return f"FY{1988 + hy}"
    return None


def process_pdf(pdf_path: str, fy: str, url: str) -> dict | None:
    """PDFを解析して結果dictを返す。"""
    try:
        text = extract_text_from_pdf(pdf_path)
    except Exception as e:
        print(f"  [ERROR] fitz failed: {e}")
        return None

    total = find_budget_total(text)
    if total is None:
        print(f"  [WARN] Could not find budget total in {fy}")
        # デバッグ: 空港整備勘定周辺テキストを表示
        lines = text.split("\n")
        for i, l in enumerate(lines):
            if "空港整備" in l or "合計" in l:
                print(f"    L{i}: {l.strip()}")
        return None

    # 百万円→億円変換
    # 数値が100万以上なら百万円単位と判断
    if total >= 100000:
        oku = total / 100  # 百万円→億円
    else:
        oku = float(total)

    return {
        "fy": fy,
        "budget_total_oku": round(oku, 1),
        "raw_value": total,
        "source": url,
    }


# -------- メイン --------

def main():
    results: dict[str, dict] = {}

    # Step 1: 既知URLをダウンロード・解析
    print("=== Known URLs ===")
    for fy, url in sorted(KNOWN_URLS.items()):
        print(f"\n[{fy}] {url}")
        pdf_path = download_pdf(url, fy)
        if pdf_path:
            rec = process_pdf(pdf_path, fy, url)
            if rec:
                results[fy] = rec
                print(f"  => {rec['budget_total_oku']} 億円")
        time.sleep(0.5)

    # Step 2: インデックスページから歯抜け年度を探す
    missing = [
        f"FY{y}" for y in range(2012, 2027)
        if f"FY{y}" not in results
    ]
    print(f"\n=== Missing FYs: {missing} ===")

    # インデックスページを取得
    try:
        r = requests.get(INDEX_URL, headers=HEADERS, timeout=30)
        r.encoding = "utf-8"
        soup = BeautifulSoup(r.text, "html.parser")
    except Exception as e:
        print(f"Index fetch error: {e}")
        soup = None

    if soup:
        # 全PDFリンクを取得
        all_links: list[tuple[str, str]] = []
        for a in soup.find_all("a", href=True):
            text = a.get_text(strip=True)
            href = a["href"]
            if href.endswith(".pdf"):
                full = href if href.startswith("http") else f"https://www.mlit.go.jp{href}"
                all_links.append((text, full))

        print(f"Found {len(all_links)} PDF links on index page")
        for text, url in all_links[:30]:
            print(f"  {text!r} → {url}")

        # サブページリンクも確認
        sub_pages: list[tuple[str, str]] = []
        for a in soup.find_all("a", href=True):
            text = a.get_text(strip=True)
            href = a["href"]
            if not href.endswith(".pdf") and re.search(r"(予算|budget|航空)", text, re.I):
                full = href if href.startswith("http") else f"https://www.mlit.go.jp{href}"
                sub_pages.append((text, full))

        print(f"\nSub-pages found: {len(sub_pages)}")
        for text, url in sub_pages[:20]:
            print(f"  {text!r} → {url}")

        # サブページを辿る
        for text, sub_url in sub_pages[:10]:
            print(f"\n  Fetching sub-page: {sub_url}")
            try:
                sr = requests.get(sub_url, headers=HEADERS, timeout=30)
                sr.encoding = "utf-8"
                ssoup = BeautifulSoup(sr.text, "html.parser")
                for a in ssoup.find_all("a", href=True):
                    atext = a.get_text(strip=True)
                    ahref = a["href"]
                    if ahref.endswith(".pdf") and "航空" in atext:
                        full = ahref if ahref.startswith("http") else f"https://www.mlit.go.jp{ahref}"
                        # 年号推定
                        fy_m = re.search(r"令和\s*(\d+)", atext)
                        if fy_m:
                            fy_candidate = f"FY{2018 + int(fy_m.group(1))}"
                        else:
                            fy_m = re.search(r"平成\s*(\d+)", atext)
                            if fy_m:
                                fy_candidate = f"FY{1988 + int(fy_m.group(1))}"
                            else:
                                continue
                        if fy_candidate not in results:
                            print(f"    Found: {atext!r} → {fy_candidate} {full}")
                            pdf_path = download_pdf(full, fy_candidate)
                            if pdf_path:
                                rec = process_pdf(pdf_path, fy_candidate, full)
                                if rec:
                                    results[fy_candidate] = rec
                                    print(f"    => {rec['budget_total_oku']} 億円")
                            time.sleep(0.5)
            except Exception as e:
                print(f"  sub-page error: {e}")

    # Step 3: 出力
    print("\n=== Results ===")
    output = {}
    for fy in sorted(results.keys()):
        rec = results[fy]
        output[fy] = {
            "budget_total": rec["budget_total_oku"],
            "source": rec["source"],
        }
        print(f"  {fy}: {rec['budget_total_oku']} 億円")

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"\nSaved: {OUTPUT_FILE} ({len(output)} records)")


if __name__ == "__main__":
    main()
