#!/usr/bin/env python3
"""
ATC FY2011 (H23) + FY2012 (H24) 収集スクリプト

ソース:
  1. 本局XLSX: FY2013から開始のため存在しない → スキップ
  2. TCAB: h23_*/h24_* PDFs via WARP (06_kekka_pdf + 05_zui_pdf)
  3. WCAB: ocab.mlit.go.jp/contract/con_6/23,24/ PDFs via WARP (旧ドメイン)
  4. PAS:  旧URL (http://www.pas.ysk.nilim.go.jp/KekkaKohyo/) via WARP

WARPスナップショット:
  TCAB H24:  coll=20201031, ts=20201001151609 (H24〜R2を収録)
  TCAB H23:  coll=20130610, ts=20130604044002 (fallback: 20201031)
  WCAB H24:  coll=20140611, ts=20140601042445
  WCAB H23:  coll=20130610, ts=20130604044002
  PAS FY2012/2011: coll=20130610, ts=20130604044002

Usage:
    python collect_atc_fy2011_2012.py [--dry-run] [--source tcab|wcab|pas|all]
"""

import re
import sys
import time
import argparse
import sqlite3
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    print("ERROR: PyMuPDF not installed. Run: pip install pymupdf")
    sys.exit(1)

try:
    import xlrd
except ImportError:
    import subprocess
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'xlrd==1.2.0'], check=True)
    import xlrd

# ============================================================
# Paths / Constants
# ============================================================
PROJECT  = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR  = PROJECT / 'data/pdfs/atc'
XLS_DIR  = PROJECT / 'data/raw/pas_kekka'
PDF_DIR.mkdir(parents=True, exist_ok=True)
XLS_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

HEISEI_BASE = 1988   # 平成N年 = (1988+N)年

# WARP snapshots
TCAB_WARP_SNAPS_H24 = [('20201031', '20201001151609')]
TCAB_WARP_SNAPS_H23 = [('20130610', '20130604044002'), ('20201031', '20201001151609')]

WCAB_H24_WARP = [('20140611', '20140601042445')]
WCAB_H23_WARP = [('20130610', '20130604044002')]

PAS_WARP_SNAPS = [('20130610', '20130604044002')]
OLD_PAS_BASE  = 'http://www.pas.ysk.nilim.go.jp'

TCAB_BASE   = 'https://www.cab.mlit.go.jp/tcab/img/contract'
WCAB_OCAB_BASE = 'http://ocab.mlit.go.jp/contract/con_6'

AIRPORT_KW = [
    '空港', '滑走路', '誘導路', 'エプロン', '航空灯火', '航空保安', '空港整備',
    '空港護岸', '空港埋立', '着陸帯', '旅客搭乗橋', '除雪機庫', '航空局',
]

PAS_BUREAUS = [
    ('Tohoku',   '東北'),
    ('Kanto',    '関東'),
    ('Hokuriku', '北陸'),
    ('Chubu',    '中部'),
    ('Kinki',    '近畿'),
    ('Chugoku',  '中国'),
    ('Shikoku',  '四国'),
    ('Kyushu',   '九州'),
]

# ============================================================
# Date utilities (平成 + 令和)
# ============================================================
RE_HEISEI_DATE      = re.compile(r'^平成(\d+)年(\d+)月(\d+)日$')
RE_HEISEI_DATE_FULL = re.compile(r'平成(\d{1,2})年(\d{1,2})月(\d{1,2})日')
RE_REIWA_DATE       = re.compile(r'^令和(\d+)年(\d+)月(\d+)日$')
RE_REIWA_DATE_FULL  = re.compile(r'令和(\d{1,2})年(\d{1,2})月(\d{1,2})日')


def parse_era_date_str(text):
    """平成・令和 どちらでも YYYYMMDD 文字列に変換する。"""
    text = text.strip()
    m = RE_HEISEI_DATE.match(text)
    if m:
        hy, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= hy <= 31 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{HEISEI_BASE + hy}{mo:02d}{dd:02d}'
    m = RE_REIWA_DATE.match(text)
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{2018 + ry}{mo:02d}{dd:02d}'
    return None


def search_era_date(text):
    """文字列中の平成・令和日付を YYYYMMDD で返す。なければ None。"""
    m = RE_HEISEI_DATE_FULL.search(text)
    if m:
        hy, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= hy <= 31 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{HEISEI_BASE + hy}{mo:02d}{dd:02d}'
    m = RE_REIWA_DATE_FULL.search(text)
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{2018 + ry}{mo:02d}{dd:02d}'
    return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


# ============================================================
# Download helpers
# ============================================================
def _dl(url, dest, allow_small=False):
    """URLからダウンロードして dest に保存。成功時 True。"""
    if dest.exists() and dest.stat().st_size > (500 if allow_small else 5000):
        return True
    try:
        req  = urllib.request.Request(url, headers=HEADERS)
        resp = urllib.request.urlopen(req, timeout=30)
        data = resp.read()
        min_size = 500 if allow_small else 1000
        if len(data) < min_size:
            return False
        dest.write_bytes(data)
        return True
    except urllib.error.HTTPError as e:
        if e.code != 404:
            print(f'  HTTP {e.code}: {url}')
        return False
    except Exception as e:
        print(f'  ERR: {e}  url={url}')
        return False


def download_warp(orig_url, dest, snaps):
    """WARP スナップショット一覧から順番に試してダウンロード。"""
    for coll, ts in snaps:
        warp_url = f'https://warp.ndl.go.jp/{coll}/{ts}id_/{orig_url}'
        if _dl(warp_url, dest):
            return True
    return False


# ============================================================
# PDF text extraction
# ============================================================
RE_PAGE_HEADER = re.compile(
    r'公共調達の適正化|契約の相手方の商号|公共工事の名称|物品役務の名称|'
    r'契約担当官|一般競争入札.*指名競争|又は名称及び住所|随意契約によることとした'
)
RE_CORP_NUM    = re.compile(r'^\d{13}$')
RE_AMOUNT_YEN  = re.compile(r'^[\d,]+円$')
RE_AMOUNT_NUM  = re.compile(r'^[\d,]+$')
RE_RATE_PCT    = re.compile(r'^[\d.]+%$')
RE_TWOAMOUNTS  = re.compile(r'^([\d,]+)\s+([\d,]+)$')
RE_LARGE_AMOUNT = re.compile(r'^[\d,]{5,15}$')


def is_page_header(text):
    return bool(RE_PAGE_HEADER.search(text)) or len(text) > 80


def classify_line(text):
    if parse_era_date_str(text):
        return 'date'
    if RE_CORP_NUM.match(text):
        return 'corp_num'
    if RE_AMOUNT_YEN.match(text):
        return 'amount_yen'
    if RE_TWOAMOUNTS.match(text.replace(',', '')):
        return 'two_amounts'
    if RE_AMOUNT_NUM.match(text.replace(',', '')) and len(text.replace(',', '')) >= 4:
        try:
            v = float(text.replace(',', ''))
            if v >= 100:
                return 'amount_plain'
        except Exception:
            pass
    if RE_RATE_PCT.match(text):
        return 'rate'
    try:
        v = float(text)
        if 0.0 <= v <= 100.0 and '.' in text:
            return 'rate'
    except Exception:
        pass
    if '競争入札' in text or '指名競争' in text:
        return 'bid_kw'
    if '随意契約' in text and len(text) < 30:
        return 'bid_kw'
    if is_page_header(text):
        return 'header'
    return 'other'


def extract_pdf_lines(pdf_path):
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f'  ERROR opening PDF: {e}')
        return []
    result = []
    for page_num, page in enumerate(doc):
        try:
            xml_str = page.get_text('xml')
            root = ET.fromstring(xml_str)
        except Exception:
            continue
        for line in root.findall('.//line'):
            chars_with_x = []
            for char in line.findall('.//char'):
                c = char.get('c', '')
                if not c:
                    continue
                try:
                    cx = float(char.get('x', '0'))
                    bbox = line.get('bbox', '')
                    parts = bbox.split()
                    if len(parts) >= 4:
                        y0, y1 = float(parts[1]), float(parts[3])
                    else:
                        y0 = y1 = 0.0
                    chars_with_x.append((cx, (y0 + y1) / 2, c))
                except Exception:
                    continue
            if not chars_with_x:
                text = line.get('text', '').strip()
                if not text:
                    continue
                bbox = line.get('bbox', '')
                try:
                    x0, y0, x1, y1 = [float(v) for v in bbox.split()]
                except Exception:
                    continue
                y_center = (y0 + y1) / 2
                result.append({'page': page_num, 'x_min': x0, 'x_max': x1,
                               'y_page': y_center, 'y_global': page_num * 1000 + y_center,
                               'text': text})
                continue
            COL_GAP = 12.0
            segments = []
            seg_chars = [chars_with_x[0]]
            for i in range(1, len(chars_with_x)):
                if chars_with_x[i][0] - chars_with_x[i - 1][0] > COL_GAP:
                    segments.append(seg_chars)
                    seg_chars = [chars_with_x[i]]
                else:
                    seg_chars.append(chars_with_x[i])
            segments.append(seg_chars)
            y_center = chars_with_x[0][1]
            for seg in segments:
                seg_text = ''.join(c for _, _, c in seg).strip()
                if not seg_text:
                    continue
                x_min = seg[0][0]
                result.append({'page': page_num, 'x_min': x_min,
                               'x_max': seg[-1][0] + 8,
                               'y_page': y_center,
                               'y_global': page_num * 1000 + y_center,
                               'text': seg_text})
    doc.close()
    return result


# ============================================================
# Line-based record parser (date anchor, for pre-corp_num PDFs)
# ============================================================
def parse_records_line_based(lines, procurement_type, bid_or_zui):
    data_lines = [ln for ln in lines if ln['y_page'] > 95 and not is_page_header(ln['text'])]
    if not data_lines:
        return []

    date_lines = [ln for ln in data_lines if classify_line(ln['text']) == 'date']
    if not date_lines:
        return []

    date_lines_sorted = sorted(date_lines, key=lambda l: l['y_global'])
    records = []
    for idx, anchor in enumerate(date_lines_sorted):
        y_low  = (min(l['y_global'] for l in data_lines) - 1 if idx == 0
                  else (date_lines_sorted[idx-1]['y_global'] + anchor['y_global']) / 2)
        y_high = (max(l['y_global'] for l in data_lines) + 1 if idx == len(date_lines_sorted)-1
                  else (anchor['y_global'] + date_lines_sorted[idx+1]['y_global']) / 2)

        rec_lines = sorted([ln for ln in data_lines if y_low <= ln['y_global'] <= y_high],
                           key=lambda l: (l['x_min'], l['y_global']))
        if not rec_lines:
            continue

        contract_date = parse_era_date_str(anchor['text'])
        classified = [(ln, classify_line(ln['text'])) for ln in rec_lines]

        planned_price = contract_amount = award_rate = None
        # Two-amounts first
        for ln, cls in classified:
            if cls == 'two_amounts':
                m = RE_TWOAMOUNTS.match(ln['text'].replace(',', ''))
                if m:
                    planned_price = float(m.group(1))
                    contract_amount = float(m.group(2))
                break
        if planned_price is None:
            amt_lines = [(ln, cls) for ln, cls in classified if cls in ('amount_yen', 'amount_plain')]
            amt_lines.sort(key=lambda t: t[0]['x_min'])
            for i, (ln, cls) in enumerate(amt_lines):
                try:
                    v = float(ln['text'].replace(',', '').replace('円', ''))
                    if v < 100: continue
                    if planned_price is None: planned_price = v
                    elif contract_amount is None: contract_amount = v
                except Exception:
                    pass

        rate_lines = [ln for ln, cls in classified if cls == 'rate']
        if rate_lines:
            try:
                award_rate = float(rate_lines[0]['text'].replace('%', '').strip())
            except Exception:
                pass

        bid_method = None
        for ln, cls in classified:
            if cls == 'bid_kw':
                bid_method = ln['text']
                break
        if bid_method is None:
            bid_method = '随意契約' if bid_or_zui == 'zui' else '一般競争入札'

        name_candidates = [(ln, cls) for ln, cls in classified
                           if cls == 'other' and len(ln['text']) > 6
                           and not is_page_header(ln['text'])]
        contract_name = name_candidates[0][0]['text'] if name_candidates else None

        if contract_amount is None:
            continue

        records.append({
            'contract_name':    contract_name,
            'contract_date':    contract_date,
            'vendor_name':      None,
            'corporate_number': None,
            'bid_method':       bid_method,
            'contract_basis':   None,
            'planned_price':    planned_price,
            'contract_amount':  contract_amount,
            'award_rate':       award_rate,
            'procurement_type': procurement_type,
        })
    return records


# ============================================================
# Block-based legacy parser (for dense PDFs where line parser fails)
# ============================================================
def _parse_amount(s):
    t = s.replace(',', '').replace('円', '').strip()
    try:
        v = float(t)
        return v if v >= 1000 else None
    except Exception:
        return None


def parse_pdf_block_legacy(pdf_path, bid_or_zui, year_hint, month_hint):
    """
    PyMuPDF block モードで抽出。各ブロックが1レコードを含む前提。
    平成・令和 日付を検索。なければ year_hint+month_hint から推定。
    """
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f'  ERROR opening PDF (block): {e}')
        return []

    bid_method_default = '随意契約' if bid_or_zui == 'zui' else '一般競争入札'
    records = []

    for page in doc:
        d = page.get_text('dict')
        page_text = page.get_text()
        ptype = '建設工事' if '公共工事' in page_text else '物品役務'

        for block in d.get('blocks', []):
            spans = []
            for line in block.get('lines', []):
                for span in line.get('spans', []):
                    t = span.get('text', '').strip()
                    if t:
                        spans.append(t)
            if not spans:
                continue

            amounts = [v for s in spans for v in [_parse_amount(s)] if v and v > 100000]
            if len(amounts) < 2:
                continue

            contract_date = None
            for s in spans:
                contract_date = search_era_date(s)
                if contract_date:
                    break
            if not contract_date:
                contract_date = f'{year_hint}{month_hint:02d}01'

            amounts.sort(reverse=True)
            planned_price   = amounts[0]
            contract_amount = amounts[1] if len(amounts) > 1 else None
            if planned_price and contract_amount and planned_price < contract_amount:
                planned_price, contract_amount = contract_amount, planned_price

            award_rate = None
            for s in spans:
                if RE_LARGE_AMOUNT.match(s.replace(',', '')):
                    continue
                try:
                    v = float(s.replace('%', '').strip())
                    if 50 < v <= 100:
                        award_rate = v
                        break
                except Exception:
                    pass

            bid_method = bid_method_default
            for s in spans:
                if '随意契約' in s and len(s) < 20:
                    bid_method = '随意契約'
                    break
                if '競争入札' in s or '指名競争' in s:
                    bid_method = '一般競争入札'
                    break

            contract_name = None
            for s in spans:
                if len(s) < 8: continue
                if search_era_date(s): continue
                if RE_LARGE_AMOUNT.match(s.replace(',', '')): continue
                try: float(s.replace(',', '')); continue
                except ValueError: pass
                contract_name = s
                break

            if contract_amount is None:
                continue

            records.append({
                'contract_name':    contract_name,
                'contract_date':    contract_date,
                'vendor_name':      None,
                'corporate_number': None,
                'bid_method':       bid_method,
                'contract_basis':   None,
                'planned_price':    planned_price,
                'contract_amount':  contract_amount,
                'award_rate':       award_rate,
                'procurement_type': ptype,
            })
    doc.close()
    return records


def parse_pdf(pdf_path, bid_or_zui, procurement_type, year_hint, month_hint):
    """
    まず line-based パーサーを試す。
    レコードが取れなければ block-based にフォールバック。
    """
    lines = extract_pdf_lines(pdf_path)
    records = []
    if lines:
        records = parse_records_line_based(lines, procurement_type, bid_or_zui)
    if not records:
        records = parse_pdf_block_legacy(pdf_path, bid_or_zui, year_hint, month_hint)
    return records


# ============================================================
# DB helpers
# ============================================================
def get_existing_source_files(conn):
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT source_file FROM contracts WHERE source_file IS NOT NULL")
    return {r[0] for r in cur.fetchall()}


def insert_records_db(conn, records, source, source_file, target_fy, dry_run=False):
    cur = conn.cursor()
    inserted = skipped = 0
    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy != target_fy:
            skipped += 1
            continue
        if dry_run:
            inserted += 1
            continue
        try:
            cur.execute("""
                INSERT INTO contracts (
                    fiscal_year, procurement_type, bid_method,
                    contract_name, contracting_officer, contract_date,
                    vendor_name, vendor_address, corporate_number,
                    contract_basis, planned_price, contract_amount, award_rate,
                    notes, source_file, source
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                fy,
                rec.get('procurement_type', '物品役務'),
                rec.get('bid_method', ''),
                rec.get('contract_name'),
                rec.get('contracting_officer'),
                rec.get('contract_date'),
                rec.get('vendor_name'),
                rec.get('vendor_address'),
                rec.get('corporate_number'),
                rec.get('contract_basis'),
                rec.get('planned_price'),
                rec.get('contract_amount'),
                rec.get('award_rate'),
                None, source_file, source,
            ))
            inserted += 1
        except sqlite3.Error as e:
            print(f'  DB error: {e}')
            skipped += 1
    if not dry_run:
        conn.commit()
    return inserted, skipped


# ============================================================
# TCAB: H23 / H24
# ============================================================
def _tcab_fy_months(fy):
    """FY の 12ヶ月を (h_year, month) として返す。h_year は平成年数。"""
    months = []
    # April - December in fiscal year start
    for mm in range(4, 13):
        months.append((fy - 1988, mm))   # 平成年 = fy - 1988
    # January - March of next calendar year (still same FY)
    for mm in range(1, 4):
        months.append((fy + 1 - 1988, mm))
    return months


def run_tcab(conn, dry_run=False):
    print('\n=== TCAB FY2011/FY2012 ===')
    existing = get_existing_source_files(conn)
    stats = {'inserted': 0, 'skipped': 0, 'failed': 0}

    for fy in [2011, 2012]:
        months = _tcab_fy_months(fy)
        warp_snaps = TCAB_WARP_SNAPS_H23 if fy == 2011 else TCAB_WARP_SNAPS_H24
        fy_ins = 0
        print(f'\n  FY{fy}:')
        for h_year, mm in months:
            for folder, sfx in [('06_kekka_pdf', 'bid'), ('05_zui_pdf', 'zui')]:
                fname = f'h{h_year:02d}_{mm:02d}_{sfx}.pdf'
                if fname in existing:
                    stats['skipped'] += 1
                    continue

                orig_url = f'{TCAB_BASE}/{folder}/{fname}'
                dest = PDF_DIR / fname
                if not download_warp(orig_url, dest, warp_snaps):
                    stats['failed'] += 1
                    continue
                time.sleep(0.2)

                # procurement_type from folder
                ptype = '物品役務'  # TCAB bid/zui are both 物品役務
                cal_year = HEISEI_BASE + h_year
                recs = parse_pdf(dest, sfx, ptype, cal_year, mm)
                ins, sk = insert_records_db(conn, recs, 'tcab', fname, fy, dry_run)
                if ins:
                    print(f'    {fname}: {ins}件')
                    fy_ins += ins
                stats['inserted'] += ins
                stats['skipped']  += sk

        print(f'  FY{fy} TCAB: {fy_ins}件')

    print(f'  合計 inserted={stats["inserted"]} skipped={stats["skipped"]} failed={stats["failed"]}')


# ============================================================
# WCAB (旧 ocab 形式): H23 / H24
# ============================================================
WCAB_TYPES = [
    ('kk', '物品役務', 'bid'),
    ('kz', '物品役務', 'zui'),
    ('bk', '建設工事', 'bid'),
    ('bz', '建設工事', 'zui'),
]

WCAB_MONTHS = ['04', '05', '06', '07', '08', '09', '10', '11', '12', '01', '02', '03']


def run_wcab(conn, dry_run=False):
    print('\n=== WCAB (ocab) FY2011/FY2012 ===')
    existing = get_existing_source_files(conn)
    stats = {'inserted': 0, 'skipped': 0, 'failed': 0}

    for fy, fy_dir, warp_snaps in [
        (2011, '23', WCAB_H23_WARP),
        (2012, '24', WCAB_H24_WARP),
    ]:
        # 月→カレンダー年の変換
        def cal_year_from_mm(fy, mm_str):
            mm = int(mm_str)
            return fy if mm >= 4 else fy + 1

        fy_ins = 0
        print(f'\n  FY{fy} (con_6/{fy_dir}/):')
        for mm_str in WCAB_MONTHS:
            for ttype, ptype, bid_or_zui in WCAB_TYPES:
                orig_url = f'{WCAB_OCAB_BASE}/{fy_dir}/{mm_str}/{ttype}.pdf'
                fname = f'ocab_h{fy_dir}_{mm_str}_{ttype}.pdf'
                if fname in existing:
                    stats['skipped'] += 1
                    continue

                dest = PDF_DIR / fname
                if not download_warp(orig_url, dest, warp_snaps):
                    stats['failed'] += 1
                    continue
                time.sleep(0.15)

                cal_year = cal_year_from_mm(fy, mm_str)
                recs = parse_pdf(dest, bid_or_zui, ptype, cal_year, int(mm_str))
                ins, sk = insert_records_db(conn, recs, 'wcab', fname, fy, dry_run)
                if ins:
                    print(f'    {fname}: {ins}件')
                    fy_ins += ins
                stats['inserted'] += ins
                stats['skipped']  += sk

        print(f'  FY{fy} WCAB: {fy_ins}件')

    print(f'  合計 inserted={stats["inserted"]} skipped={stats["skipped"]} failed={stats["failed"]}')


# ============================================================
# PAS: FY2011 / FY2012
# ============================================================
def _fy_months(fy):
    months = []
    for m in range(4, 13):
        months.append(f'{fy}{m:02d}')
    for m in range(1, 4):
        months.append(f'{fy + 1}{m:02d}')
    return months


def is_airport_related(name):
    return bool(name) and any(kw in name for kw in AIRPORT_KW)


def serial_to_ymd(serial, datemode=0):
    try:
        v = float(serial)
        if v <= 0: return None
        t = xlrd.xldate_as_tuple(v, datemode)
        if t[0] == 0: return None
        return f'{t[0]:04d}{t[1]:02d}{t[2]:02d}'
    except Exception:
        return None


def parse_xls(fpath, bureau_ja, yyyymm, notes_tag, target_fy):
    try:
        wb = xlrd.open_workbook(str(fpath))
    except Exception as e:
        print(f'  ERROR opening {fpath.name}: {e}')
        return []
    ws = wb.sheet_by_index(0)
    dm = wb.datemode
    records = []
    for r in range(4, ws.nrows):
        row = [ws.cell_value(r, c) if c < ws.ncols else '' for c in range(19)]
        name_raw = str(row[1]).strip()
        if not name_raw or name_raw in ('None', '0.0', ''):
            continue
        if not is_airport_related(name_raw):
            continue
        bid_date = serial_to_ymd(row[2], dm)
        if not bid_date:
            bid_date = f'{yyyymm[:4]}{yyyymm[4:]}01'
        y, mo = int(yyyymm[:4]), int(yyyymm[4:])
        fy = y if mo >= 4 else y - 1
        if fy != target_fy:
            continue

        def safe_float(v):
            try:
                f = float(v)
                return f if f > 0 else None
            except Exception:
                return None

        work_type  = str(row[4]).strip() or None
        bid_method = str(row[5]).strip() or None
        vendor_raw = str(row[7]).strip()
        records.append({
            'fiscal_year':   fy,
            'bureau':        bureau_ja,
            'file_name':     fpath.name,
            'file_type':     'koji',
            'contract_name': name_raw,
            'bid_date':      bid_date,
            'award_date':    serial_to_ymd(row[3], dm),
            'work_type':     work_type if work_type != 'None' else None,
            'bid_method':    bid_method if bid_method != 'None' else None,
            'vendor_name':   vendor_raw if vendor_raw and vendor_raw not in ('None', '') else None,
            'planned_price': safe_float(row[8]),
            'bid_amount':    safe_float(row[9]),
            'award_amount':  safe_float(row[11]),
            'notes':         notes_tag,
        })
    return records


def insert_pas_records(conn, records, dry_run=False):
    if not records: return 0
    if dry_run: return len(records)
    conn.executemany("""
        INSERT INTO pas_airport_contracts
          (fiscal_year, bureau, file_name, file_type, contract_name,
           bid_date, award_date, work_type, bid_method, vendor_name,
           planned_price, bid_amount, award_amount, notes)
        VALUES
          (:fiscal_year, :bureau, :file_name, :file_type, :contract_name,
           :bid_date, :award_date, :work_type, :bid_method, :vendor_name,
           :planned_price, :bid_amount, :award_amount, :notes)
    """, records)
    conn.commit()
    return len(records)


def get_pas_existing(conn):
    try:
        rows = conn.execute(
            "SELECT bureau || '/' || file_name || '/' || CAST(fiscal_year AS TEXT) "
            "FROM pas_airport_contracts WHERE fiscal_year <= 2012"
        ).fetchall()
        return {r[0] for r in rows}
    except Exception:
        return set()


def run_pas(conn, dry_run=False):
    print('\n=== PAS FY2011/FY2012 ===')
    existing_pas = get_pas_existing(conn)
    stats = {'inserted': 0, 'skipped': 0, 'failed': 0}

    for fy in [2011, 2012]:
        months = _fy_months(fy)
        fy_ins = 0
        print(f'\n  FY{fy}:')
        for bureau_en, bureau_ja in PAS_BUREAUS:
            bureau_ins = 0
            for yyyymm in months:
                fname    = f'koji{yyyymm}.xls'
                dedup_key = f'{bureau_ja}/{fname}/{fy}'
                if dedup_key in existing_pas:
                    stats['skipped'] += 1
                    continue

                orig_url = f'{OLD_PAS_BASE}/KekkaKohyo/{bureau_en}/{fname}'
                dest = XLS_DIR / f'old_{bureau_en}_{fname}'
                if not download_warp(orig_url, dest, PAS_WARP_SNAPS):
                    stats['failed'] += 1
                    continue
                time.sleep(0.1)

                tag  = 'warp:20130610'
                recs = parse_xls(dest, bureau_ja, yyyymm, tag, fy)
                if recs:
                    n = insert_pas_records(conn, recs, dry_run)
                    bureau_ins += n
                    stats['inserted'] += n
                    existing_pas.add(dedup_key)
                else:
                    stats['skipped'] += 1
            if bureau_ins:
                print(f'    {bureau_ja}: {bureau_ins}件')
            fy_ins += bureau_ins
        print(f'  FY{fy} PAS: {fy_ins}件')

    print(f'  合計 inserted={stats["inserted"]} skipped={stats["skipped"]} failed={stats["failed"]}')


# ============================================================
# Main
# ============================================================
def main():
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser()
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--source', default='all', choices=['tcab', 'wcab', 'pas', 'all'])
    args = parser.parse_args()

    conn = sqlite3.connect(str(DB_PATH))

    if args.source in ('tcab', 'all'):
        run_tcab(conn, args.dry_run)
    if args.source in ('wcab', 'all'):
        run_wcab(conn, args.dry_run)
    if args.source in ('pas', 'all'):
        run_pas(conn, args.dry_run)

    # 最終集計
    print('\n=== FY別件数・金額 ===')
    print('--- contracts テーブル ---')
    for row in conn.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8, 1)
        FROM contracts WHERE fiscal_year IN (2011, 2012)
        GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall():
        print(f'  FY{row[0]}: {row[1]}件 / {row[2]}億円')

    print('--- pas_airport_contracts テーブル ---')
    for row in conn.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(award_amount,0))/1e8, 1)
        FROM pas_airport_contracts WHERE fiscal_year IN (2011, 2012)
        GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall():
        print(f'  FY{row[0]}: {row[1]}件 / {row[2]}億円')

    conn.close()


if __name__ == '__main__':
    main()
