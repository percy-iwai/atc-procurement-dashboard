import sqlite3, json, re
from collections import defaultdict

conn = sqlite3.connect("data/db/atc_procurement.db")
conn.row_factory = sqlite3.Row
cur = conn.cursor()

result = {}

# ==== 1. NULL contracting_officer by source ====
cur.execute("""
    SELECT COALESCE(source, 'NULL/不明') as src,
           COUNT(*) as cnt,
           COALESCE(SUM(contract_amount), 0) as total_amt
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL
    GROUP BY source
    ORDER BY cnt DESC
""")
result["1_null_officer_by_source"] = [dict(r) for r in cur.fetchall()]

# ==== 2. Organization inference ====

# TCAB vendor patterns
cur.execute("""
    SELECT vendor_name, COUNT(*) as cnt, SUM(contract_amount) as total
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL AND source='tcab'
    GROUP BY vendor_name
    ORDER BY cnt DESC
""")
tcab_vendor_patterns = [dict(r) for r in cur.fetchall()]

# WCAB contract_name analysis
cur.execute("""
    SELECT contract_name, vendor_name, source_file, contract_amount
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL AND source='wcab'
        AND contract_name IS NOT NULL
    LIMIT 200
""")
wcab_orgs = defaultdict(lambda: {"count": 0, "amount": 0.0, "airports": set()})
for r in cur.fetchall():
    cn = r["contract_name"] or ""
    if "大阪航空局" in cn:
        org = "大阪航空局"
    elif "東京航空局" in cn:
        org = "東京航空局"
    elif "航空局" in cn:
        org = "航空局"
    else:
        org = "不明"
    airports = re.findall(r"[\u4e00-\u9fff]{2,5}空港", cn)
    wcab_orgs[org]["count"] += 1
    wcab_orgs[org]["amount"] += r["contract_amount"] or 0
    wcab_orgs[org]["airports"].update(airports)

wcab_org_summary = {}
for org, d in wcab_orgs.items():
    wcab_org_summary[org] = {
        "count": d["count"],
        "amount": d["amount"],
        "airports_mentioned": sorted(d["airports"])[:20]
    }

# Keyword hits
cur.execute("""
    SELECT contract_name, source, source_file, contract_amount
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL
        AND contract_name IS NOT NULL
""")
keyword_counts = defaultdict(lambda: {"count": 0, "amount": 0.0})
keywords = ["東京航空局", "大阪航空局", "航空局", "空港", "管制", "航空保安",
            "那覇", "福岡", "関西", "大阪", "神戸", "千歳", "羽田", "成田"]
for r in cur.fetchall():
    cn = r["contract_name"] or ""
    for kw in keywords:
        if kw in cn:
            keyword_counts[kw]["count"] += 1
            keyword_counts[kw]["amount"] += r["contract_amount"] or 0

result["2_organization_inference"] = {
    "tcab_null_vendor_name_patterns": {
        "interpretation": "vendor_nameに「支出負担行為担当官」等の役職名が格納 → パーサーの列ずれによりcontract_name/contracting_officerが取れていない",
        "root_org": "東京航空局",
        "patterns": tcab_vendor_patterns[:10]
    },
    "wcab_null_org_from_contract_name": {
        "interpretation": "contract_nameに担当官名+組織名+件名が混在 → 列ずれによりcontracting_officerがNULL化",
        "root_org": "大阪航空局",
        "org_breakdown": wcab_org_summary
    },
    "keyword_hits_in_contract_name": dict(keyword_counts)
}

# ==== 3. source_file breakdown ====
cur.execute("""
    SELECT COALESCE(source_file, 'NULL') as sf,
           COALESCE(source, 'NULL') as src,
           COUNT(*) as cnt,
           COALESCE(SUM(contract_amount), 0) as total_amt
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL
    GROUP BY source_file, source
    ORDER BY cnt DESC
""")
result["3_source_file_breakdown"] = [dict(r) for r in cur.fetchall()]

tcab_files = {}
wcab_files = {}
cur.execute("""
    SELECT source_file, COUNT(*) as cnt, SUM(contract_amount) as total
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL AND source='tcab'
    GROUP BY source_file ORDER BY source_file
""")
for r in cur.fetchall():
    sf = r["source_file"]
    m = re.match(r"r(\d+)_(\d+)_(bid|zui)\.pdf", sf or "")
    if m:
        ry, mo, typ = m.group(1), m.group(2), m.group(3)
        label = f"令和{ry}年{int(mo)}月 {'競争入札' if typ=='bid' else '随意契約'}"
    else:
        label = sf
    tcab_files[sf] = {"label": label, "count": r["cnt"], "amount": r["total"]}

cur.execute("""
    SELECT source_file, COUNT(*) as cnt, SUM(contract_amount) as total
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL AND source='wcab'
    GROUP BY source_file ORDER BY source_file
""")
for r in cur.fetchall():
    sf = r["source_file"]
    m = re.match(r"(bk|kk|kz|bz)_(\d{6})\.pdf", sf or "")
    if m:
        typ, dt = m.group(1), m.group(2)
        typ_label = {"bk": "物品役務・競争入札", "kk": "工事・競争入札",
                     "kz": "工事・随意契約", "bz": "物品役務・随意契約"}.get(typ, typ)
        mo = int(dt[4:6])
        label = f"令和6年{mo}月 {typ_label}"
    elif re.match(r"(bk|kk|kz|bz)_(\d{4})\.pdf", sf or ""):
        m2 = re.match(r"(bk|kk|kz|bz)_(\d{4})\.pdf", sf)
        typ = m2.group(1)
        ym = m2.group(2)
        typ_label = {"bk": "物品役務・競争入札", "kk": "工事・競争入札",
                     "kz": "工事・随意契約", "bz": "物品役務・随意契約"}.get(typ, typ)
        label = f"令和6/7年 {ym} {typ_label}"
    else:
        label = sf
    wcab_files[sf] = {"label": label, "count": r["cnt"], "amount": r["total"]}

result["3_source_file_breakdown_labeled"] = {
    "tcab_files_東京航空局月次PDF": tcab_files,
    "wcab_files_大阪航空局月次PDF": wcab_files
}

# ==== 4. Top vendors ====
OFFICER_NAMES = {
    "支出負担行為担当官", "分任支出負担行為担当官",
    "石井　靖男", "村田　有", "涌元　一", "森島　隆広",
    "局の名称及び所在地", "契約を締結した日", "にその所属する部局の名",
    "古堅　厚弘", "野村　伸一", "永藤　成明"
}

cur.execute("""
    SELECT vendor_name, source, COUNT(*) as cnt, SUM(contract_amount) as total
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL
    GROUP BY vendor_name
    ORDER BY total DESC NULLS LAST
    LIMIT 50
""")
all_vendors = []
for r in cur.fetchall():
    vn = r["vendor_name"] or ""
    if vn in OFFICER_NAMES:
        continue
    if any(x in vn for x in ["負担行為", "担当官", "令和", "の名称", "役務等"]):
        continue
    if re.search(r"[都道府県].*[市区町村]", vn):
        continue
    all_vendors.append(dict(r))
    if len(all_vendors) >= 30:
        break

result["4_top_actual_vendors"] = all_vendors

# WCAB vendors specifically
cur.execute("""
    SELECT vendor_name, COUNT(*) as cnt, SUM(contract_amount) as total
    FROM contracts
    WHERE fiscal_year=2024 AND contracting_officer IS NULL AND source='wcab'
    GROUP BY vendor_name
    ORDER BY total DESC NULLS LAST
    LIMIT 50
""")
wcab_vendors = []
skip_names = OFFICER_NAMES | {"大阪府大阪市中央区大手"}
for r in cur.fetchall():
    vn = r["vendor_name"] or ""
    if vn in skip_names:
        continue
    if any(x in vn for x in ["の名称", "締結", "役務等"]):
        continue
    if re.search(r"[都道府県].*[市区町村]", vn):
        continue
    wcab_vendors.append(dict(r))
    if len(wcab_vendors) >= 20:
        break

result["4_top_vendors_wcab_大阪航空局"] = wcab_vendors

# TCAB actual vendors from non-NULL records
cur.execute("""
    SELECT vendor_name, COUNT(*) as cnt, SUM(contract_amount) as total
    FROM contracts
    WHERE fiscal_year=2024 AND source='tcab' AND contracting_officer IS NOT NULL
    GROUP BY vendor_name
    ORDER BY total DESC NULLS LAST
    LIMIT 20
""")
result["4_top_vendors_tcab_reference_non_null"] = [dict(r) for r in cur.fetchall()]

# ==== 0. Summary ====
result["0_summary"] = {
    "total_null_officer_fy2024": {
        "count": 836,
        "amount_jpy": 50021177708,
        "amount_oku": round(50021177708 / 1e8, 1)
    },
    "breakdown": {
        "tcab_東京航空局": {
            "count": 223,
            "amount_jpy": 32317886581,
            "amount_oku": round(32317886581 / 1e8, 1),
            "root_cause": "PDFパーサーの列ずれ: contracting_officerとcontract_nameが取得できていない。vendor_nameに役職名「支出負担行為担当官」が混入",
            "org_identified": "東京航空局（支出負担行為担当官: 今井和哉 局長）",
            "offices": ["東京航空局本局（九段南）", "東京空港事務所（羽田）",
                        "新千歳空港事務所", "仙台空港事務所", "成田空港事務所", "新潟空港事務所"]
        },
        "wcab_大阪航空局": {
            "count": 557,
            "amount_jpy": 17703291127,
            "amount_oku": round(17703291127 / 1e8, 1),
            "root_cause": "PDFパーサーの列ずれ: contract_nameに担当官名・組織名・契約件名が混在。contracting_officerがNULL化",
            "org_identified": "大阪航空局（大阪府大阪市中央区大手前３－１－４１）",
            "officers_found_in_data": [
                "石井　靖男（大阪航空局長）",
                "村田　有（大阪航空局）",
                "涌元　一（大阪空港事務所）",
                "古堅　厚弘（那覇空港事務所）",
                "森島　隆広（福岡空港事務所）",
                "渡邉　智史（中部空港事務所）",
                "永藤　成明（鹿児島空港事務所）"
            ],
            "airports_covered": [
                "大阪国際空港", "関西国際空港", "神戸空港", "中部（セントレア）",
                "福岡空港", "北九州空港", "長崎空港", "鹿児島空港", "熊本空港",
                "高知空港", "松山空港", "小松空港", "那覇空港", "久米島空港",
                "宮古島（ARSR）", "航空交通管理センター", "神戸航空交通管制部"
            ]
        },
        "source_null_国土交通省航空局": {
            "count": 56,
            "amount_jpy": 0,
            "amount_oku": 0,
            "root_cause": "source_file=fy2024.xlsx から読み込んだレコード。contract_amountがNULL（金額未記載）",
            "org_identified": "国土交通省航空局（霞が関２－１－３）",
            "officer_from_xlsx": "支出負担行為担当官: 平岡 成哲（航空局）",
            "note": "このグループはcontracting_officerがNULL。実際のofficeはfy2024.xlsxの別行にあった可能性"
        }
    },
    "diagnosis": {
        "tcab_issue": "東京航空局PDFのテーブルレイアウトが他と異なり、contract_name/contracting_officerが列ずれで取れていない。再収集要。223件・323億円が未分類",
        "wcab_issue": "大阪航空局PDFでcontracting_officerセルが複数行にまたがっており、パーサーが先頭セルをcontract_nameに誤マップ。557件・177億円が未分類",
        "recommendation": "tcab/wcabのPDFパーサーを修正してcontracting_officerを正しく抽出すること。データはDBに存在するが構造化が不完全"
    }
}

out_path = "data/output/atc_unknown_org_analysis.json"
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2, default=str)

print(f"Saved to {out_path}")
print(f"\n=== Summary ===")
print(f"TCAB NULL: 223件 / {32317886581/1e8:.0f}億円 → 東京航空局（パース失敗）")
print(f"WCAB NULL: 557件 / {17703291127/1e8:.0f}億円 → 大阪航空局（パース失敗）")
print(f"source=NULL: 56件 / 0円 → 国土交通省航空局（金額なし）")
conn.close()
