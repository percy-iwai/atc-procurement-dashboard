#!/usr/bin/env python3
"""
WCAB (大阪航空局) H25/H26 (FY2013/FY2014) 収集・パーススクリプト

H25/H26 era uses different domain: ocab.mlit.go.jp
URL pattern: http://ocab.mlit.go.jp/contract/con_6/{YY}/{MM}/{type}.pdf
  YY = 平成年号 (25=2013, 26=2014, 27=2015)
  MM = 月 (01-12)
  type = kk, kz, bk, bz

WARP snapshots (both from same day 2015-04-02):
  H25 index ts: 20150402070410  (confirmed 45 links for H25 year data)
  H26 index ts: 20150402070405  (confirmed 38 links for H26 year data)

FY2013: H25/04 - H25/12, H26/01 - H26/03
FY2014: H26/04 - H26/12, H27/01 - H27/03 (H27 jan-mar may be partial/missing)

Usage:
    python collect_wcab_h25_h26.py [--dry-run] [--fy 2013]
"""

import re
import sys
import time
import sqlite3
import argparse
import urllib.request
import urllib.error
from pathlib import Path

try:
    import fitz
except ImportError:
    print("ERROR: PyMuPDF not installed")
    sys.exit(1)

PROJECT  = Path('C:/Users/Percy Iwai/Documents/JAXA_procurement')
DB_PATH  = PROJECT / 'data/db/atc_procurement.db'
PDF_DIR  = PROJECT / 'data/pdfs/wcab_historical'
PDF_DIR.mkdir(parents=True, exist_ok=True)

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

HEISEI_BASE = 1988
REIWA_BASE  = 2018
TARGET_FY   = {2013, 2014}

OCAB_BASE = 'http://ocab.mlit.go.jp/contract/con_6/'

# WARP snapshots — both captured on same crawl date (2015-04-02)
WARP_SNAPSHOTS = [
    ('20150402', '20150402070410'),  # primary H25 snapshot
    ('20150402', '20150402070405'),  # primary H26 snapshot
    ('20150422', '20150404001946'),  # fallback (different coll seen in FY2020/2021 work)
]

FILE_TYPES = ['kk', 'kz', 'bk', 'bz']

# Date patterns
RE_HEISEI_DATE = re.compile(r'平成(\d{1,2})年(\d{1,2})月(\d{1,2})日')
RE_REIWA_DATE  = re.compile(r'令和(\d{1,2})年(\d{1,2})月(\d{1,2})日')
RE_LARGE_AMOUNT = re.compile(r'^[\d,]{5,15}$')

# Type → procurement + bid method
TYPE_MAP = {
    'kk': ('物品役務', '一般競争入札'),
    'kz': ('物品役務', '随意契約'),
    'bk': ('建設工事', '一般競争入札'),
    'bz': ('建設工事', '随意契約'),
}


def hm_date_to_ymd(text):
    m = RE_HEISEI_DATE.search(text)
    if m:
        hy, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= hy <= 64 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{HEISEI_BASE + hy}{mo:02d}{dd:02d}'
    m = RE_REIWA_DATE.search(text)
    if m:
        ry, mo, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= ry <= 20 and 1 <= mo <= 12 and 1 <= dd <= 31:
            return f'{REIWA_BASE + ry}{mo:02d}{dd:02d}'
    return None


def date_to_fy(ds):
    if not ds or len(ds) < 6:
        return None
    y, mo = int(ds[:4]), int(ds[4:6])
    return y if mo >= 4 else y - 1


def heisei_year_month_to_cal(hy, mm):
    """Convert 平成年+月 to calendar year + month."""
    return HEISEI_BASE + hy, mm


def generate_file_list():
    """
    Generate (local_fname, orig_url, hy, mm, ftype) for H25-H27 files.

    WCAB URL structure: con_6/{fiscal_year_num}/{calendar_month}/
    e.g. con_6/25/04/ = 平成25年4月 (April 2013, FY2013)
         con_6/26/01/ = 平成26年1月 (January 2014, BUT actual data = Jan 2015 due to rolling window)

    Rolling-window issue: by the April-2015 WARP crawl, the h26 folder's 01-03 entries
    already contain FY2014 data (Jan-Mar 2015), NOT FY2013 data (Jan-Mar 2014).
    So we collect all months of h25 and h26, and let the contract date determine FY at insert time.
    """
    files = []
    # H25: months 01-12 (all months of 平成25年 folder)
    for mm in range(1, 13):
        for ftype in FILE_TYPES:
            orig_url    = f'{OCAB_BASE}25/{mm:02d}/{ftype}.pdf'
            local_fname = f'wcab_h25_{mm:02d}_{ftype}.pdf'
            files.append((local_fname, orig_url, 25, mm, ftype))

    # H26: months 01-12 (all months of 平成26年 folder)
    for mm in range(1, 13):
        for ftype in FILE_TYPES:
            orig_url    = f'{OCAB_BASE}26/{mm:02d}/{ftype}.pdf'
            local_fname = f'wcab_h26_{mm:02d}_{ftype}.pdf'
            files.append((local_fname, orig_url, 26, mm, ftype))

    # H27: months 01-03 only (Jan-Mar 2016 = FY2015 end, possibly not archived)
    for mm in range(1, 4):
        for ftype in FILE_TYPES:
            orig_url    = f'{OCAB_BASE}27/{mm:02d}/{ftype}.pdf'
            local_fname = f'wcab_h27_{mm:02d}_{ftype}.pdf'
            files.append((local_fname, orig_url, 27, mm, ftype))

    return files


def download_from_warp(orig_url, dest_path):
    """Try multiple WARP snapshots to download the file."""
    if dest_path.exists() and dest_path.stat().st_size > 500:
        return True

    for warp_coll, warp_ts in WARP_SNAPSHOTS:
        warp_url = f'https://warp.ndl.go.jp/{warp_coll}/{warp_ts}id_/{orig_url}'
        for attempt in range(2):
            try:
                req  = urllib.request.Request(warp_url, headers=HEADERS)
                resp = urllib.request.urlopen(req, timeout=30)
                data = resp.read()
                if len(data) < 500:
                    break
                if not data.startswith(b'%PDF'):
                    break
                dest_path.write_bytes(data)
                return True
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    break
                if attempt < 1:
                    time.sleep(2)
            except Exception:
                if attempt < 1:
                    time.sleep(2)

    return False


RE_AMOUNT_YEN = re.compile(r'^[\d,]+円$')
RE_RATE_PCT   = re.compile(r'^[\d.]+%$')


def _parse_amount_yen(s):
    """Parse amount like '27,862,992円' or '27,862,992'."""
    t = s.replace(',', '').replace('円', '').strip()
    try:
        v = float(t)
        return v if v >= 1 else None
    except Exception:
        return None


def _parse_rate(s):
    t = s.strip().rstrip('%')
    try:
        v = float(t)
        return v if 0 < v <= 100 else None
    except Exception:
        return None


def _block_spans(block):
    """Extract all non-empty span texts from a block."""
    spans = []
    for line in block.get('lines', []):
        for span in line.get('spans', []):
            t = span.get('text', '').strip()
            if t:
                spans.append(t)
    return spans


SKIP_KEYWORDS = ('公共調達の適正化', '物品役務等の名称及び数量', '公共工事の名称',
                  '契約担当官等の氏名', 'の名称及び所在地', '契約を締結した日',
                  '契約の相手方の商号', '又は名称及び住所', '一般競争入札・指名',
                  '競争入札の別', '総合評価の実施', '予定価格', '契約金額', '落札率', '備考',
                  '随意契約によること')


def is_header_block(spans):
    return any(any(kw in s for kw in SKIP_KEYWORDS) for s in spans)


def parse_wcab_pdf_heisei(pdf_path, ftype, fy_hint, mm):
    """
    Parse WCAB PDF (H25/H26 era).

    Block structure per record (repeating):
      Block N  : contract_name (e.g. '平成２５年度広島空港警備業務請負')
      Block N+1: contracting_officer + address
      Block N+2: contract_date ('平成25年4月1日')
      Block N+3: vendor_name + vendor_address
      Block N+4: bid_method + planned_price円 + contract_amount円 + rate%

    Strategy: find "amount blocks" (have ≥2 円-suffixed amounts), then look
    back up to 5 blocks for the other fields.
    """
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as e:
        print(f"  ERROR opening {pdf_path.name}: {e}")
        return []

    ptype, bid_method_default = TYPE_MAP.get(ftype, ('物品役務', '一般競争入札'))
    records = []

    for page in doc:
        page_text = page.get_text()
        if not page_text.strip():
            continue

        d = page.get_text('dict')
        all_blocks = [_block_spans(b) for b in d.get('blocks', [])]

        for i, spans in enumerate(all_blocks):
            if not spans:
                continue

            # Identify "amount block": ≥2 円-suffixed numbers + a percentage
            yen_amounts = [s for s in spans if RE_AMOUNT_YEN.match(s)]
            rates       = [s for s in spans if RE_RATE_PCT.match(s)]
            if len(yen_amounts) < 2 or not rates:
                continue

            planned_price   = _parse_amount_yen(yen_amounts[0])
            contract_amount = _parse_amount_yen(yen_amounts[1])
            if planned_price and contract_amount and planned_price < contract_amount:
                planned_price, contract_amount = contract_amount, planned_price
            if contract_amount is None or contract_amount < 100:
                continue

            award_rate = _parse_rate(rates[0])
            bid_method = bid_method_default
            for s in spans:
                if '随意契約' in s and len(s) < 25:
                    bid_method = '随意契約'
                    break
                if '競争入札' in s or '指名競争' in s:
                    bid_method = '一般競争入札'
                    break

            # Scan backwards up to 6 blocks for date, vendor, officer, name
            contract_date  = None
            vendor_name    = None
            contract_name  = None
            contracting_officer = None

            for j in range(i - 1, max(i - 7, -1), -1):
                prev = all_blocks[j]
                if not prev or is_header_block(prev):
                    break

                # Date?
                if contract_date is None:
                    for s in prev:
                        d_str = hm_date_to_ymd(s)
                        if d_str:
                            contract_date = d_str
                            break

                # Vendor block: first non-header, non-date block just before the amount block
                if vendor_name is None and contract_date is None:
                    # This block is between amount block and date block → vendor
                    non_header = [s for s in prev if len(s) > 2
                                  and not any(kw in s for kw in SKIP_KEYWORDS)]
                    if non_header:
                        vendor_name = non_header[0]

                # Contract name: block with 年度 or 事業名
                if contract_name is None:
                    for s in prev:
                        if len(s) > 8 and ('年度' in s or '事業' in s or '業務' in s or '工事' in s):
                            if not is_header_block([s]):
                                contract_name = s
                                break

            # Fallback date
            if not contract_date:
                cal_year = fy_hint if mm >= 4 else fy_hint + 1
                contract_date = f'{cal_year}{mm:02d}01'

            records.append({
                'contract_name':       contract_name,
                'contracting_officer': contracting_officer,
                'contract_date':       contract_date,
                'vendor_name':         vendor_name,
                'vendor_address':      None,
                'corporate_number':    None,
                'bid_method':          bid_method,
                'contract_basis':      None,
                'planned_price':       planned_price,
                'contract_amount':     contract_amount,
                'award_rate':          award_rate,
                'procurement_type':    ptype,
            })

    doc.close()
    return records


def setup_db(conn):
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(contracts)")
    cols = [r[1] for r in cur.fetchall()]
    if 'source' not in cols:
        cur.execute("ALTER TABLE contracts ADD COLUMN source TEXT")
        conn.commit()


def get_existing_source_files(conn):
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT source_file FROM contracts WHERE source_file IS NOT NULL")
    return {r[0] for r in cur.fetchall()}


def insert_records(conn, records, source_file, allowed_fy, dry_run=False):
    """Insert records whose fiscal year is in allowed_fy (a set)."""
    cur = conn.cursor()
    ins = skip = 0
    for rec in records:
        fy = date_to_fy(rec.get('contract_date'))
        if fy not in allowed_fy:
            skip += 1
            continue
        if dry_run:
            ins += 1
            continue
        try:
            cur.execute("""
                INSERT INTO contracts (
                    fiscal_year, procurement_type, bid_method,
                    contract_name, contracting_officer, contract_date,
                    vendor_name, vendor_address, corporate_number,
                    contract_basis, planned_price, contract_amount, award_rate,
                    notes, source_file, source
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                fy,
                rec.get('procurement_type', '物品役務'),
                rec.get('bid_method', ''),
                rec.get('contract_name'),
                rec.get('contracting_officer'),
                rec.get('contract_date'),
                rec.get('vendor_name'),
                rec.get('vendor_address'),
                rec.get('corporate_number'),
                rec.get('contract_basis'),
                rec.get('planned_price'),
                rec.get('contract_amount'),
                rec.get('award_rate'),
                None,
                source_file,
                'wcab',
            ))
            ins += 1
        except sqlite3.Error as e:
            print(f"  DB error: {e}")
            skip += 1
    if not dry_run:
        conn.commit()
    return ins, skip


def main():
    ap = argparse.ArgumentParser(description='WCAB H25/H26 FY2013/2014 収集')
    ap.add_argument('--dry-run',       action='store_true')
    ap.add_argument('--fy',            type=int, help='特定FYのみ (2013 or 2014)')
    ap.add_argument('--skip-download', action='store_true')
    args = ap.parse_args()

    sys.stdout.reconfigure(encoding='utf-8')

    conn = sqlite3.connect(str(DB_PATH))
    setup_db(conn)
    existing = get_existing_source_files(conn)

    file_list = generate_file_list()
    if args.fy:
        # Filter to only heisei years relevant to the requested FY
        # FY2013 → hy=25 (Apr-Dec 2013) + hy=26 (Jan-Mar 2014, but overwritten)
        # FY2014 → hy=26 (Apr-Dec 2014 + Jan-Mar 2015) + hy=27 (Jan-Mar 2016)
        fy_to_hy = {2013: {25, 26}, 2014: {26, 27}}
        allowed_hy = fy_to_hy.get(args.fy, {25, 26, 27})
        file_list = [(f, u, hy, mm, t) for f, u, hy, mm, t in file_list if hy in allowed_hy]

    total_dl = total_parsed = total_inserted = total_404 = total_skip_db = 0

    for local_fname, orig_url, hy, mm, ftype in file_list:
        if local_fname in existing:
            total_skip_db += 1
            continue

        dest_path = PDF_DIR / local_fname

        if not args.skip_download:
            ok = download_from_warp(orig_url, dest_path)
            if not ok:
                total_404 += 1
                continue
            total_dl += 1
            time.sleep(0.3)
        else:
            if not dest_path.exists():
                total_404 += 1
                continue

        # hy/mm are used for fallback date only; FY is determined by contract_date
        fy_hint = HEISEI_BASE + hy  # calendar year of the folder
        records = parse_wcab_pdf_heisei(dest_path, ftype, fy_hint, mm)
        total_parsed += len(records)

        if not records:
            continue  # silent — many months simply won't exist in WARP

        ins, skp = insert_records(conn, records, local_fname, TARGET_FY, args.dry_run)
        total_inserted += ins

        amt_in_target = sum(r.get('contract_amount', 0) or 0 for r in records
                            if date_to_fy(r.get('contract_date')) in TARGET_FY)
        if ins > 0:
            print(f"  {local_fname}: {len(records)}件  {amt_in_target/1e8:.2f}億  → inserted={ins}  fy_skip={skp}")

    conn.close()

    print(f"\n=== 完了 ===")
    print(f"  downloaded:  {total_dl}")
    print(f"  parsed:      {total_parsed}")
    print(f"  inserted:    {total_inserted}")
    print(f"  not_found:   {total_404}")
    print(f"  skipped_db:  {total_skip_db}")

    conn = sqlite3.connect(str(DB_PATH))
    print("\n=== DB summary (WCAB source, FY2013-2014) ===")
    for row in conn.execute("""
        SELECT fiscal_year, COUNT(*), ROUND(SUM(COALESCE(contract_amount,0))/1e8,1)
        FROM contracts WHERE source='wcab' AND fiscal_year BETWEEN 2013 AND 2014
        GROUP BY fiscal_year ORDER BY fiscal_year
    """).fetchall():
        print(f"  FY{row[0]}: {row[1]}件  {row[2]}億")
    conn.close()


if __name__ == '__main__':
    main()
